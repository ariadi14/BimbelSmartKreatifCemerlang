package com.bimbelsmartkreatifcemerlang

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import android.content.SharedPreferences
import java.security.MessageDigest
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import androidx.core.content.FileProvider
import java.io.File
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.ui.graphics.Brush
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.room.*
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.*

@Entity(tableName = "students")
data class Student(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val className: String,
    val parentPhone: String,
    val program: String,
    val monthlyFee: Long,
    val birthDate: String = "",
    val schoolOrigin: String = "",
    val note: String = "",
    val active: Boolean = true,
    val avatarPath: String = ""
)
@Entity(tableName = "payments", indices = [Index(value = ["studentId", "month"], unique = true)])
data class Payment(@PrimaryKey(autoGenerate = true) val id: Long = 0, val studentId: Long, val month: String, val amount: Long, val method: String, val date: String, val note: String, val receiptNo: String = "")
@Entity(tableName = "programs")
data class Program(@PrimaryKey(autoGenerate = true) val id: Long = 0, val name: String, val fee: Long, val iconKey: String = "school")
@Entity(tableName = "expenses")
data class Expense(@PrimaryKey(autoGenerate = true) val id: Long = 0, val month: String, val date: String, val title: String, val category: String, val amount: Long, val note: String = "")
@Entity(tableName = "incomes")
data class Income(@PrimaryKey(autoGenerate = true) val id: Long = 0, val month: String, val date: String, val title: String, val category: String, val amount: Long, val note: String = "")

@Dao interface StudentDao { @Query("SELECT * FROM students WHERE active = 1 ORDER BY program, name") fun active(): Flow<List<Student>>; @Insert suspend fun insert(s: Student): Long; @Update suspend fun update(s: Student); @Delete suspend fun delete(s: Student) }
@Dao interface PaymentDao { @Query("SELECT * FROM payments ORDER BY id DESC") fun all(): Flow<List<Payment>>; @Query("SELECT * FROM payments WHERE studentId=:studentId AND month=:month LIMIT 1") suspend fun find(studentId:Long,month:String):Payment?; @Query("DELETE FROM payments WHERE studentId=:studentId") suspend fun deleteByStudent(studentId:Long); @Insert suspend fun insert(p:Payment):Long; @Update suspend fun update(p:Payment); @Delete suspend fun delete(p:Payment) }
@Dao interface ProgramDao { @Query("SELECT * FROM programs ORDER BY name") fun all():Flow<List<Program>>; @Insert suspend fun insert(p:Program); @Delete suspend fun delete(p:Program) }
@Dao interface ExpenseDao { @Query("SELECT * FROM expenses ORDER BY id DESC") fun all():Flow<List<Expense>>; @Insert suspend fun insert(e:Expense):Long; @Update suspend fun update(e:Expense); @Delete suspend fun delete(e:Expense) }
@Dao interface IncomeDao { @Query("SELECT * FROM incomes ORDER BY id DESC") fun all():Flow<List<Income>>; @Insert suspend fun insert(i:Income):Long; @Update suspend fun update(i:Income); @Delete suspend fun delete(i:Income) }

@Database(entities=[Student::class,Payment::class,Program::class,Expense::class,Income::class],version=7,exportSchema=false)
abstract class AppDb:RoomDatabase(){ abstract fun students():StudentDao; abstract fun payments():PaymentDao; abstract fun programs():ProgramDao; abstract fun expenses():ExpenseDao; abstract fun incomes():IncomeDao
 companion object { @Volatile private var INSTANCE:AppDb?=null; fun get(c:Context):AppDb=INSTANCE?: synchronized(this){ INSTANCE?:Room.databaseBuilder(c.applicationContext,AppDb::class.java,"bimbel.db").addMigrations(MIGRATION_2_3, MIGRATION_3_4, MIGRATION_4_5, MIGRATION_5_6, MIGRATION_6_7).build().also{INSTANCE=it} } }
}
val MIGRATION_3_4=object:Migration(3,4){override fun migrate(db:SupportSQLiteDatabase){db.execSQL("CREATE TABLE IF NOT EXISTS incomes (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, month TEXT NOT NULL, date TEXT NOT NULL, title TEXT NOT NULL, category TEXT NOT NULL, amount INTEGER NOT NULL, note TEXT NOT NULL)")}}
val MIGRATION_4_5=object:Migration(4,5){override fun migrate(db:SupportSQLiteDatabase){db.execSQL("ALTER TABLE students ADD COLUMN avatarPath TEXT NOT NULL DEFAULT ''")}}
val MIGRATION_5_6=object:Migration(5,6){override fun migrate(db:SupportSQLiteDatabase){db.execSQL("ALTER TABLE programs ADD COLUMN iconKey TEXT NOT NULL DEFAULT 'school'")}}
val MIGRATION_6_7=object:Migration(6,7){override fun migrate(db:SupportSQLiteDatabase){db.execSQL("ALTER TABLE students ADD COLUMN birthDate TEXT NOT NULL DEFAULT ''");db.execSQL("ALTER TABLE students ADD COLUMN schoolOrigin TEXT NOT NULL DEFAULT ''");db.execSQL("ALTER TABLE students ADD COLUMN note TEXT NOT NULL DEFAULT ''")}}
val MIGRATION_2_3=object:Migration(2,3){override fun migrate(db:SupportSQLiteDatabase){db.execSQL("CREATE TABLE IF NOT EXISTS expenses (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, month TEXT NOT NULL, date TEXT NOT NULL, title TEXT NOT NULL, category TEXT NOT NULL, amount INTEGER NOT NULL, note TEXT NOT NULL)");db.execSQL("CREATE TEMP TABLE payment_keep AS SELECT MIN(p.id) AS id,p.studentId,p.month,CASE WHEN SUM(p.amount)>COALESCE(s.monthlyFee,SUM(p.amount)) THEN COALESCE(s.monthlyFee,SUM(p.amount)) ELSE SUM(p.amount) END AS amount,MAX(p.method) AS method,MAX(p.date) AS date,MAX(p.note) AS note,MAX(p.receiptNo) AS receiptNo FROM payments p LEFT JOIN students s ON s.id=p.studentId GROUP BY p.studentId,p.month");db.execSQL("DELETE FROM payments");db.execSQL("INSERT INTO payments(id,studentId,month,amount,method,date,note,receiptNo) SELECT id,studentId,month,amount,method,date,note,receiptNo FROM payment_keep");db.execSQL("DROP TABLE payment_keep");db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_payments_studentId_month ON payments(studentId,month)")}}

fun rupiah(n:Long)=NumberFormat.getCurrencyInstance(Locale("id","ID")).format(n).replace(",00","")
fun monthNow()=SimpleDateFormat("MMMM yyyy",Locale("id","ID")).format(Date())
fun shiftMonth(month:String,delta:Int):String{val f=SimpleDateFormat("MMMM yyyy",Locale("id","ID"));val c=Calendar.getInstance();runCatching{c.time=f.parse(month)?:Date()}.getOrElse{c.time=Date()};c.add(Calendar.MONTH,delta);return f.format(c.time)}
fun today()=SimpleDateFormat("dd/MM/yyyy",Locale("id","ID")).format(Date())
fun normalizePhone(raw:String):String{val p=raw.filter(Char::isDigit);return when{p.startsWith("62")->p;p.startsWith("0")->"62"+p.drop(1);else->p}}
fun daysRemainingInMonth():Int{val c=Calendar.getInstance();return c.getActualMaximum(Calendar.DAY_OF_MONTH)-c.get(Calendar.DAY_OF_MONTH)}
fun isMonthWarning()=daysRemainingInMonth() in 0..7

class MainVm(ctx:Context):ViewModel(){private val db=AppDb.get(ctx);val students=db.students().active();val payments=db.payments().all();val programs=db.programs().all();val expenses=db.expenses().all();val incomes=db.incomes().all()
 init{viewModelScope.launch{if(db.programs().all().first().isEmpty())listOf(Program(name="Calistung",fee=150000),Program(name="Calistung 2",fee=150000),Program(name="Iqro / Al-Qur'an",fee=100000),Program(name="Bimbel",fee=150000),Program(name="English",fee=150000)).forEach{db.programs().insert(it)}}}
 fun addStudent(s:Student)=viewModelScope.launch{db.students().insert(s)};fun updateStudent(s:Student)=viewModelScope.launch{db.students().update(s)};fun deleteStudent(s:Student)=viewModelScope.launch{db.payments().deleteByStudent(s.id);db.students().delete(s)}
 fun recordPayment(s:Student,month:String,amount:Long,method:String,note:String,onDone:()->Unit={})=viewModelScope.launch{val old=db.payments().find(s.id,month);if(old==null){db.payments().insert(Payment(studentId=s.id,month=month,amount=amount,method=method,date=today(),note=note,receiptNo="KUI/"+SimpleDateFormat("yyyy/MM",Locale.US).format(Date())+"/"+String.format(Locale.US,"%04d",(System.currentTimeMillis()%10000))))}else{val total=(old.amount+amount).coerceAtMost(s.monthlyFee);if(total<=old.amount)return@launch;db.payments().update(old.copy(amount=total,method=method,date=today(),note=note))};onDone()}
 fun updatePayment(p:Payment)=viewModelScope.launch{db.payments().update(p)};fun deletePayment(p:Payment)=viewModelScope.launch{db.payments().delete(p)};fun addIncome(i:Income)=viewModelScope.launch{db.incomes().insert(i)};fun updateIncome(i:Income)=viewModelScope.launch{db.incomes().update(i)};fun deleteIncome(i:Income)=viewModelScope.launch{db.incomes().delete(i)};fun addProgram(p:Program)=viewModelScope.launch{db.programs().insert(p)};fun deleteProgram(p:Program)=viewModelScope.launch{db.programs().delete(p)};fun addExpense(e:Expense)=viewModelScope.launch{db.expenses().insert(e)};fun updateExpense(e:Expense)=viewModelScope.launch{db.expenses().update(e)};fun deleteExpense(e:Expense)=viewModelScope.launch{db.expenses().delete(e)}
 fun exportJson(onDone:(String)->Unit)=viewModelScope.launch{val ss=db.students().activeOnce();val ps=db.payments().allOnce();val gs=db.programs().allOnce();val es=db.expenses().allOnce();val ins=db.incomes().allOnce();val o=JSONObject().put("version",6).put("exportedAt",today());o.put("students",JSONArray().apply{ss.forEach{put(JSONObject().put("id",it.id).put("name",it.name).put("className",it.className).put("parentPhone",it.parentPhone).put("program",it.program).put("monthlyFee",it.monthlyFee).put("birthDate",it.birthDate).put("schoolOrigin",it.schoolOrigin).put("note",it.note).put("active",it.active).put("avatarPath",it.avatarPath))}});o.put("payments",JSONArray().apply{ps.forEach{put(JSONObject().put("id",it.id).put("studentId",it.studentId).put("month",it.month).put("amount",it.amount).put("method",it.method).put("date",it.date).put("note",it.note).put("receiptNo",it.receiptNo))}});o.put("programs",JSONArray().apply{gs.forEach{put(JSONObject().put("id",it.id).put("name",it.name).put("fee",it.fee).put("iconKey",it.iconKey))}});o.put("expenses",JSONArray().apply{es.forEach{put(JSONObject().put("id",it.id).put("month",it.month).put("date",it.date).put("title",it.title).put("category",it.category).put("amount",it.amount).put("note",it.note))}});o.put("incomes",JSONArray().apply{ins.forEach{put(JSONObject().put("id",it.id).put("month",it.month).put("date",it.date).put("title",it.title).put("category",it.category).put("amount",it.amount).put("note",it.note))}});onDone(o.toString(2))}
 suspend fun restoreJson(text:String){val o=JSONObject(text);val ss=o.optJSONArray("students")?:JSONArray();val gs=o.optJSONArray("programs")?:JSONArray();val ps=o.optJSONArray("payments")?:JSONArray();val es=o.optJSONArray("expenses")?:JSONArray();val ins=o.optJSONArray("incomes")?:JSONArray();for(i in 0 until gs.length()){val x=gs.getJSONObject(i);db.programs().insert(Program(x.optLong("id",0),x.optString("name"),x.optLong("fee"),x.optString("iconKey","school")))};for(i in 0 until ss.length()){val x=ss.getJSONObject(i);db.students().insert(Student(id=x.optLong("id",0),name=x.optString("name"),className=x.optString("className"),parentPhone=x.optString("parentPhone"),program=x.optString("program"),monthlyFee=x.optLong("monthlyFee"),birthDate=x.optString("birthDate",""),schoolOrigin=x.optString("schoolOrigin",""),note=x.optString("note",""),active=x.optBoolean("active",true),avatarPath=x.optString("avatarPath")))};for(i in 0 until ps.length()){val x=ps.getJSONObject(i);runCatching{db.payments().insert(Payment(x.optLong("id",0),x.optLong("studentId"),x.optString("month"),x.optLong("amount"),x.optString("method"),x.optString("date"),x.optString("note"),x.optString("receiptNo")))}};for(i in 0 until es.length()){val x=es.getJSONObject(i);db.expenses().insert(Expense(x.optLong("id",0),x.optString("month"),x.optString("date"),x.optString("title"),x.optString("category"),x.optLong("amount"),x.optString("note")))};for(i in 0 until ins.length()){val x=ins.getJSONObject(i);db.incomes().insert(Income(x.optLong("id",0),x.optString("month"),x.optString("date"),x.optString("title"),x.optString("category"),x.optLong("amount"),x.optString("note")))}}
}
suspend fun StudentDao.activeOnce()=active().first();suspend fun PaymentDao.allOnce()=all().first();suspend fun ProgramDao.allOnce()=all().first();suspend fun ExpenseDao.allOnce()=all().first();suspend fun IncomeDao.allOnce()=all().first()

private val Navy=Color(0xFF124D86);private val Navy2=Color(0xFF0B6FBA);private val Green=Color(0xFF18A66A);private val Yellow=Color(0xFFF2B632);private val Red=Color(0xFFE44747);private val Bg=Color(0xFFF3F7FC);private val SoftBlue=Color(0xFFE7F2FC);private val SoftGreen=Color(0xFFE5F8F0);private val SoftRed=Color(0xFFFFECEC);private val SoftYellow=Color(0xFFFFF6DD);private val SoftPurple=Color(0xFFF1EAFE)

private val navItems=listOf(Triple(Icons.Default.Home,"Beranda",0),Triple(Icons.Default.People,"Siswa",1),Triple(Icons.Default.Payments,"Bayar",2),Triple(Icons.Default.BarChart,"Laporan",3),Triple(Icons.Default.MoreHoriz,"Lainnya",4))

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun App(){
    val context=androidx.compose.ui.platform.LocalContext.current.applicationContext
    val vm:MainVm=viewModel(factory=object:androidx.lifecycle.ViewModelProvider.Factory{override fun<T:ViewModel>create(c:Class<T>):T=MainVm(context) as T})
    var tab by remember{mutableIntStateOf(0)};var route by remember{mutableStateOf("home")};var selectedProgram by remember{mutableStateOf("")};var selectedStudent by remember{mutableStateOf<Student?>(null)};var editingStudent by remember{mutableStateOf<Student?>(null)};var payStudent by remember{mutableStateOf<Student?>(null)}
    var paymentFilter by remember{mutableStateOf("Semua")};var activeMonth by remember{mutableStateOf(monthNow())};var dashboardDateOffset by remember{mutableIntStateOf(0)};var dashboardClock by remember{mutableStateOf(Date())};var showSplash by remember{mutableStateOf(true)};var authenticated by remember{mutableStateOf(false)}
    val students by vm.students.collectAsState(emptyList());val payments by vm.payments.collectAsState(emptyList());val programs by vm.programs.collectAsState(emptyList());val expenses by vm.expenses.collectAsState(emptyList());val incomes by vm.incomes.collectAsState(emptyList())
    LaunchedEffect(Unit){kotlinx.coroutines.delay(1400);showSplash=false};LaunchedEffect(Unit){while(true){dashboardClock=Date();kotlinx.coroutines.delay(1000)}}
    MaterialTheme(colorScheme=lightColorScheme(primary=Navy,secondary=Green,background=Bg,surface=Color.White,error=Red)){
        if(showSplash){Splash()} else if(!authenticated){PinGate(context,!pinIsSet(context)){authenticated=true}} else {
            val sub=route!="home"
            val title=when(route){"studentProgram"->selectedProgram;"studentDetail"->"Biodata Siswa";"paymentProgram"->selectedProgram;"addStudent"->if(editingStudent==null)"Tambah Siswa" else "Edit Siswa";"addProgram"->"Tambah Program";"paymentDetail"->"Pembayaran";"notifications"->"Pemberitahuan";"programManagement"->"Program & Tarif";"security"->"Keamanan Aplikasi";"backup"->"Backup & Restore";"about"->"Tentang Aplikasi";else->when(tab){1->"Data Siswa";2->"Pembayaran";3->"Laporan";else->"Lainnya"}}
            val hideTopBar = route=="studentProgram" || route=="studentDetail" || route=="paymentProgram" || route=="paymentDetail" || (route=="home" && tab in 0..4)
            Scaffold(containerColor=Bg,topBar={if(!hideTopBar)BlueprintTopBar(title,onBack={route="home";selectedStudent=null;editingStudent=null})},bottomBar={BottomNav(tab){tab=it;route="home"}}){pad->
                Box(Modifier.padding(pad).fillMaxSize()){
                    when{
                        route=="studentProgram"->StudentProgramPage(selectedProgram,students.filter{it.program.equals(selectedProgram,true)},programs.firstOrNull{it.name.equals(selectedProgram,true)}?.fee,{s->selectedStudent=s;route="studentDetail"},{route="home";tab=1})
                        route=="studentDetail"&&selectedStudent!=null->StudentDetailPage(selectedStudent!!,{editingStudent=selectedStudent;route="addStudent"},{vm.deleteStudent(selectedStudent!!);selectedStudent=null;route="home";tab=1},{route="home";tab=1})
                        route=="paymentProgram"->PaymentProgramPage(selectedProgram,students.filter{it.program.equals(selectedProgram,true)},payments,activeMonth,{route="home";tab=2},{s->selectedStudent=s;route="paymentDetail"})
                        route=="addStudent"->StudentFormPage(context,programs,editingStudent,onBack={route=if(editingStudent!=null)"studentDetail" else "home"}){st->val wasEdit=st.id!=0L;if(wasEdit)vm.updateStudent(st)else vm.addStudent(st);selectedProgram=st.program;if(wasEdit){selectedStudent=st;editingStudent=null;route="studentDetail"}else{editingStudent=null;route="studentProgram"}}
                        route=="addProgram"->ProgramFormPage(onBack={route="home"}){name,fee,icon->vm.addProgram(Program(name=name,fee=fee,iconKey=icon));route="home"}
                        route=="paymentDetail"&&selectedStudent!=null->PaymentDetailPage(selectedStudent!!,payments.filter{it.studentId==selectedStudent!!.id},activeMonth,{activeMonth=it},{payStudent=selectedStudent},{payStudent=selectedStudent},{route="home";selectedStudent=null})
                        route=="notifications"->NotificationSettingsPage(context)
                        route=="programManagement"->ProgramManagementPage(programs,vm,{route="addProgram"})
                        route=="security"->SecurityPage(context,{authenticated=false})
                        route=="backup"->BackupPage(vm)
                        route=="about"->AboutPage()
                        tab==0->Dashboard(students,payments,expenses,incomes,activeMonth,dashboardClock,dashboardDateOffset,{dashboardDateOffset--},{dashboardDateOffset++},{status->paymentFilter=status;tab=2},{route="notifications"})
                        tab==1->StudentsScreen(students,programs,{editingStudent=it;selectedProgram=it.program;route="addStudent"},{editingStudent=null;route="addStudent"},{selectedProgram=it;route="studentProgram"})
                        tab==2->PaymentsScreen(students,programs,payments,paymentFilter,activeMonth,{activeMonth=shiftMonth(activeMonth,-1)},{activeMonth=shiftMonth(activeMonth,1)},{paymentFilter="Semua"},{status->paymentFilter=status},{s->selectedStudent=s;route="paymentDetail"},{vm.deletePayment(it)},{s->payStudent=s}){selectedProgram=it;route="paymentProgram"}
                        tab==3->ReportsScreen(students,programs,payments,expenses,incomes,vm,activeMonth,{activeMonth=it})
                        else->MoreScreen(programs,vm,activeMonth,{activeMonth=it},{route="programManagement"},{route="notifications"},{route="security"},{route="backup"},{route="about"},{authenticated=false})
                    }
                }
            }
        }
        payStudent?.let{s->PaymentDialog(s,payments.find{it.studentId==s.id&&it.month.equals(activeMonth,true)},activeMonth,{payStudent=null}){updated->if(updated.id==0L)vm.recordPayment(s,activeMonth,updated.amount,updated.method,updated.note){payStudent=null}else{vm.updatePayment(updated);payStudent=null}}}
    }
}

@Composable fun BottomNav(selected:Int,onSelected:(Int)->Unit){
    NavigationBar(containerColor=Color.White,tonalElevation=0.dp,modifier=Modifier.padding(horizontal=8.dp,vertical=7.dp).clip(RoundedCornerShape(24.dp))){
        navItems.forEach{(icon,label,index)->NavigationBarItem(selected=selected==index,onClick={onSelected(index)},icon={
            Surface(color=if(selected==index)SoftBlue else Color.Transparent,shape=RoundedCornerShape(14.dp)){Icon(icon,null,modifier=Modifier.padding(horizontal=12.dp,vertical=6.dp).size(22.dp))}
        },label={Text(label,fontSize=9.sp,fontWeight=if(selected==index)FontWeight.ExtraBold else FontWeight.SemiBold)},colors=NavigationBarItemDefaults.colors(selectedIconColor=Navy,selectedTextColor=Navy,indicatorColor=Color.Transparent,unselectedIconColor=Color(0xFF687386),unselectedTextColor=Color(0xFF687386)))}
    }
}

private fun pinPrefs(context:Context)=context.getSharedPreferences("bimbel_security",Context.MODE_PRIVATE)
private fun hashPin(pin:String):String=MessageDigest.getInstance("SHA-256").digest(pin.toByteArray()).joinToString(""){String.format("%02x",it)}
private fun pinIsSet(context:Context)=pinPrefs(context).getString("pin_hash",null)!=null
private fun savePin(context:Context,pin:String){pinPrefs(context).edit().putString("pin_hash",hashPin(pin)).apply()}
private fun checkPin(context:Context,pin:String)=pinPrefs(context).getString("pin_hash","")==hashPin(pin)

@Composable fun PinGate(context:Context,firstSetup:Boolean,onSuccess:()->Unit){
    var pin by remember{mutableStateOf("")};var confirm by remember{mutableStateOf("")};var error by remember{mutableStateOf("")}
    fun addDigit(d:String){if(pin.length<6)pin+=d;error=""};fun backspace(){if(pin.isNotEmpty())pin=pin.dropLast(1);error=""}
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFFBFE8FF),Color(0xFFF7FBFF),Color(0xFFEAF9F2)))),contentAlignment=Alignment.Center){
        Column(Modifier.fillMaxSize().padding(horizontal=28.dp,vertical=22.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.Center){
            Image(painterResource(R.drawable.logo_bimbel),"Logo",Modifier.size(112.dp));Spacer(Modifier.height(10.dp))
            Text("Bimbel Smart",fontSize=30.sp,fontWeight=FontWeight.ExtraBold,color=Navy);Text("Kreatif Cemerlang",fontSize=27.sp,fontWeight=FontWeight.ExtraBold,color=Green)
            Spacer(Modifier.height(12.dp));Text(if(firstSetup)"Buat PIN Admin" else "Masukkan PIN Admin",fontSize=24.sp,fontWeight=FontWeight.ExtraBold,color=Navy)
            Text(if(firstSetup)"Buat PIN 6 digit untuk mengamankan data" else "Data siswa dan keuangan dilindungi dengan aman",fontSize=11.sp,color=Color.Gray)
            Spacer(Modifier.height(14.dp));Row(horizontalArrangement=Arrangement.spacedBy(11.dp)){repeat(6){i->Surface(color=if(i<pin.length)Navy else Color.White.copy(alpha=.8f),shape=CircleShape,shadowElevation=1.dp){Box(Modifier.size(16.dp))}}}
            Spacer(Modifier.height(14.dp));Column(Modifier.widthIn(max=350.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
                listOf(listOf("1","2","3"),listOf("4","5","6"),listOf("7","8","9"),listOf("","0","⌫")).forEach{row->Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){row.forEach{d->if(d.isBlank())Spacer(Modifier.weight(1f))else OutlinedButton(onClick={if(d=="⌫")backspace()else addDigit(d)},modifier=Modifier.weight(1f).height(54.dp),shape=RoundedCornerShape(16.dp),colors=ButtonDefaults.outlinedButtonColors(containerColor=Color.White.copy(alpha=.82f),contentColor=Navy)){Text(d,fontSize=21.sp,fontWeight=FontWeight.ExtraBold)}}}}
            }
            if(firstSetup){Spacer(Modifier.height(8.dp));OutlinedTextField(confirm,{if(it.length<=6&&it.all(Char::isDigit))confirm=it},label={Text("Ulangi PIN 6 digit")},visualTransformation=androidx.compose.ui.text.input.PasswordVisualTransformation(),keyboardOptions=androidx.compose.foundation.text.KeyboardOptions(keyboardType=androidx.compose.ui.text.input.KeyboardType.NumberPassword),singleLine=true,modifier=Modifier.fillMaxWidth().widthIn(max=350.dp),shape=RoundedCornerShape(15.dp))}
            if(error.isNotBlank()){Spacer(Modifier.height(5.dp));Text(error,color=Red,fontSize=11.sp,fontWeight=FontWeight.Bold)}
            Spacer(Modifier.height(10.dp));Button(onClick={if(pin.length!=6)error="PIN harus 6 digit" else if(firstSetup&&pin!=confirm)error="PIN tidak sama" else if(!firstSetup&&!checkPin(context,pin))error="PIN salah" else {if(firstSetup)savePin(context,pin);onSuccess()}},enabled=pin.length==6&&(firstSetup||pin.isNotBlank()),modifier=Modifier.fillMaxWidth().widthIn(max=350.dp).height(48.dp),shape=RoundedCornerShape(15.dp),colors=ButtonDefaults.buttonColors(Navy)){Text(if(firstSetup)"Simpan & Masuk" else "Masuk",fontWeight=FontWeight.ExtraBold,fontSize=15.sp)}
        }
    }
}

@Composable fun Splash(){Box(Modifier.fillMaxSize().background(Color.White)){Image(painterResource(R.drawable.blueprint_splash_v2_exact),"Splash Bimbel Smart Kreatif Cemerlang",Modifier.fillMaxSize(),contentScale=androidx.compose.ui.layout.ContentScale.FillBounds)}}

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun BlueprintTopBar(title:String,onBack:()->Unit){CenterAlignedTopAppBar(title={Text(title,fontWeight=FontWeight.ExtraBold,color=Navy,fontSize=21.sp)},navigationIcon={IconButton(onClick=onBack){Icon(Icons.Default.ArrowBack,"Kembali",tint=Navy,modifier=Modifier.size(27.dp))}},actions={Surface(color=SoftBlue,shape=CircleShape,modifier=Modifier.padding(end=10.dp)){IconButton(onClick={}){Icon(Icons.Default.NotificationsNone,null,tint=Navy,modifier=Modifier.size(22.dp))}}},colors=TopAppBarDefaults.centerAlignedTopAppBarColors(containerColor=Color.White))}

@Composable fun Dashboard(students:List<Student>,payments:List<Payment>,expenses:List<Expense>,incomes:List<Income>,activeMonth:String,clock:Date,dateOffset:Int,onPreviousDate:()->Unit,onNextDate:()->Unit,onStatus:(String)->Unit,onNotification:()->Unit={} ){
    val mp=payments.filter{it.month.equals(activeMonth,true)}; val me=expenses.filter{it.month.equals(activeMonth,true)}; val mi=incomes.filter{it.month.equals(activeMonth,true)}
    fun paid(id:Long)=mp.filter{it.studentId==id}.sumOf{it.amount}
    val lunas=students.count{paid(it.id)>=it.monthlyFee}; val kurang=students.count{val x=paid(it.id);x>0&&x<it.monthlyFee}; val belum=students.count{paid(it.id)==0L}
    val dateCalendar=Calendar.getInstance().apply{time=Date();add(Calendar.DAY_OF_MONTH,dateOffset)}
    val activeDate=dateCalendar.time
    val clockText=SimpleDateFormat("HH.mm.ss",Locale("id","ID")).format(clock)
    val dateText=SimpleDateFormat("EEEE, dd MMMM yyyy",Locale("id","ID")).format(activeDate)
    LazyColumn(Modifier.fillMaxSize().background(Bg),contentPadding=PaddingValues(bottom=18.dp)){
        item{DashboardFinalHero(dateText,onNotification)}
        item{DatePill(clockText,dateText)}
        item{Row(Modifier.fillMaxWidth().padding(horizontal=18.dp),horizontalArrangement=Arrangement.spacedBy(10.dp)){StatCard("Total Siswa",students.size.toString(),Icons.Default.Groups,Navy,SoftBlue){onStatus("Semua")};StatCard("Sudah Bayar",lunas.toString(),Icons.Default.CheckCircle,Green,SoftGreen){onStatus("Lunas")}}}
        item{Row(Modifier.fillMaxWidth().padding(horizontal=18.dp),horizontalArrangement=Arrangement.spacedBy(10.dp)){StatCard("Kurang Bayar",kurang.toString(),Icons.Default.Schedule,Yellow,SoftYellow){onStatus("Kurang Bayar")};StatCard("Belum Bayar",belum.toString(),Icons.Default.Cancel,Red,SoftRed){onStatus("Belum Bayar")}}}
        item{WarningCard(belum,kurang,activeMonth){onStatus("Belum Bayar")}}
        item{DashboardQuote()}
    }
}

@Composable
fun DashboardFinalHero(now:String,onNotification:()->Unit={} ){
    Box(Modifier.fillMaxWidth().height(250.dp).clip(RoundedCornerShape(bottomStart=30.dp,bottomEnd=30.dp))){
        Image(painterResource(R.drawable.final_dashboard_header),"Blueprint Dashboard",Modifier.fillMaxSize(),contentScale=androidx.compose.ui.layout.ContentScale.FillBounds)
        // Keep the notification function without covering the blueprint artwork.
        Box(Modifier.align(Alignment.TopEnd).size(70.dp).clickable(onClick=onNotification))
    }
}
@Composable fun DashboardHeader(onNotification:()->Unit={}){
    Box(Modifier.fillMaxWidth().height(155.dp).clip(RoundedCornerShape(bottomStart=28.dp,bottomEnd=28.dp))){
        Image(painterResource(id = LocalContext.current.resources.getIdentifier("background_header_2", "drawable", LocalContext.current.packageName)),"Background dashboard",Modifier.fillMaxSize(),contentScale=androidx.compose.ui.layout.ContentScale.Crop)
        Box(Modifier.fillMaxSize().background(Brush.horizontalGradient(listOf(Color.White.copy(alpha=.93f),Color.White.copy(alpha=.48f),Color.Transparent))))
        Row(Modifier.fillMaxSize().padding(horizontal=18.dp,vertical=14.dp),verticalAlignment=Alignment.CenterVertically){
            Surface(color=Color.White.copy(alpha=.92f),shape=CircleShape,shadowElevation=4.dp){Image(painterResource(R.drawable.logo_bimbel),"Logo Bimbel",Modifier.size(68.dp).padding(5.dp))}
            Spacer(Modifier.width(10.dp));Column(Modifier.weight(1f)){Text("Bimbel Smart",fontSize=20.sp,fontWeight=FontWeight.ExtraBold,color=Navy);Text("Kreatif Cemerlang",fontSize=18.sp,fontWeight=FontWeight.ExtraBold,color=Green);Text("Cerdas • Kreatif • Berkarakter • Berprestasi",fontSize=8.sp,color=Navy,fontWeight=FontWeight.Bold)}
            Surface(color=Color.White.copy(alpha=.95f),shape=CircleShape,shadowElevation=4.dp,modifier=Modifier.clickable(onClick=onNotification)){Icon(Icons.Default.NotificationsActive,"Pemberitahuan",tint=Navy,modifier=Modifier.padding(12.dp).size(25.dp))}
        }
    }
}

@Composable fun DatePill(clockText:String,dateText:String){
    Card(Modifier.fillMaxWidth().padding(horizontal=18.dp,vertical=9.dp),shape=RoundedCornerShape(24.dp),colors=CardDefaults.cardColors(Color.White),elevation=CardDefaults.cardElevation(3.dp)){
        Column(Modifier.fillMaxWidth().padding(horizontal=10.dp,vertical=10.dp),horizontalAlignment=Alignment.CenterHorizontally){
            Text(clockText,fontWeight=FontWeight.ExtraBold,color=Navy,fontSize=24.sp,maxLines=1)
            Spacer(Modifier.height(2.dp))
            Text(dateText,fontWeight=FontWeight.ExtraBold,color=Navy,fontSize=16.sp,maxLines=1,softWrap=false,modifier=Modifier.fillMaxWidth(),textAlign=androidx.compose.ui.text.style.TextAlign.Center)
        }
    }
}

@Composable fun MonthPill(month:String,onPrevious:()->Unit,onNext:()->Unit){Card(Modifier.fillMaxWidth().padding(horizontal=18.dp,vertical=9.dp),shape=RoundedCornerShape(24.dp),colors=CardDefaults.cardColors(Color.White),elevation=CardDefaults.cardElevation(3.dp)){Row(Modifier.fillMaxWidth().padding(8.dp),verticalAlignment=Alignment.CenterVertically){IconButton(onClick=onPrevious){Icon(Icons.Default.ChevronLeft,"Bulan sebelumnya",tint=Navy,modifier=Modifier.size(30.dp))};Surface(color=SoftBlue,shape=CircleShape){Icon(Icons.Default.CalendarMonth,null,tint=Navy,modifier=Modifier.padding(10.dp).size(24.dp))};Column(Modifier.weight(1f).padding(horizontal=10.dp),horizontalAlignment=Alignment.CenterHorizontally){Text("BULAN AKTIF",fontSize=9.sp,color=Color.Gray,fontWeight=FontWeight.ExtraBold);Text(month,fontWeight=FontWeight.ExtraBold,color=Navy,fontSize=20.sp)};IconButton(onClick=onNext){Icon(Icons.Default.ChevronRight,"Bulan berikutnya",tint=Navy,modifier=Modifier.size(30.dp))}}}}

@Composable fun MonthPill(month:String,onMonthChange:(String)->Unit){MonthPill(month,{onMonthChange(shiftMonth(month,-1))},{onMonthChange(shiftMonth(month,1))})}

@Composable fun DashboardSectionTitle(title:String,subtitle:String){
    Column(Modifier.fillMaxWidth().padding(horizontal=18.dp,vertical=5.dp)){Text(title,fontWeight=FontWeight.ExtraBold,color=Navy,fontSize=17.sp);Text(subtitle,fontSize=10.sp,color=Color.Gray)}
}

@Composable fun WarningCard(belum:Int,kurang:Int,month:String,onStatus:()->Unit){
    Card(Modifier.fillMaxWidth().padding(horizontal=18.dp,vertical=9.dp).clickable(onClick=onStatus),shape=RoundedCornerShape(22.dp),colors=CardDefaults.cardColors(Color(0xFFFFE8EF)),elevation=CardDefaults.cardElevation(2.dp)){
        Row(Modifier.padding(horizontal=16.dp,vertical=13.dp),verticalAlignment=Alignment.CenterVertically){
            Surface(color=Color(0xFFFFD4DF),shape=CircleShape){Icon(Icons.Default.NotificationsActive,null,tint=Red,modifier=Modifier.padding(11.dp).size(25.dp))}
            Spacer(Modifier.width(11.dp))
            Column(Modifier.weight(1f)){
                Text("PERINGATAN",fontSize=9.sp,fontWeight=FontWeight.ExtraBold,color=Red)
                Text("${daysRemainingInMonth()} Hari Lagi Ganti Bulan",fontSize=18.sp,fontWeight=FontWeight.ExtraBold,color=Red)
                Text("Pastikan semua pembayaran bulan $month sudah selesai.",fontSize=10.sp,color=Color(0xFF704B55),maxLines=2)
            }
            Icon(Icons.Default.ChevronRight,null,tint=Red,modifier=Modifier.size(27.dp))
        }
    }
}

@Composable fun DashboardWelcome(now:String){Box(Modifier.fillMaxWidth().height(172.dp).clip(RoundedCornerShape(bottomStart=26.dp,bottomEnd=26.dp)).background(Color(0xFFDDF3FF))){Image(painterResource(R.drawable.background_header),"Background header dashboard",Modifier.fillMaxSize(),contentScale=androidx.compose.ui.layout.ContentScale.Crop);Box(Modifier.fillMaxSize().background(Brush.horizontalGradient(listOf(Color.White.copy(alpha=.96f),Color.White.copy(alpha=.20f),Color.Transparent))));Column(Modifier.padding(start=20.dp,top=16.dp,end=135.dp)){Text("Semangat Mengelola Bimbel!",fontSize=24.sp,lineHeight=28.sp,fontWeight=FontWeight.ExtraBold,color=Navy);Text("Langkah kecil hari ini, hasil besar untuk masa depan.",fontSize=11.sp,color=Navy,lineHeight=16.sp,fontWeight=FontWeight.Bold);Spacer(Modifier.height(12.dp));Surface(color=Color.White.copy(alpha=.94f),shape=RoundedCornerShape(16.dp),shadowElevation=2.dp){Row(Modifier.padding(horizontal=10.dp,vertical=7.dp),verticalAlignment=Alignment.CenterVertically){Icon(Icons.Default.CalendarMonth,null,tint=Navy,modifier=Modifier.size(17.dp));Spacer(Modifier.width(5.dp));Text(now,fontSize=9.sp,fontWeight=FontWeight.Bold,color=Navy)}}}}}
@Composable fun DashboardQuote(){
    Image(painterResource(R.drawable.final_dashboard_quote),"Blueprint dashboard quote",Modifier.fillMaxWidth().padding(horizontal=18.dp,vertical=8.dp).height(54.dp),contentScale=androidx.compose.ui.layout.ContentScale.FillBounds)
}

@Composable fun FinanceHero(income:Long,expense:Long,net:Long,month:String){Card(Modifier.fillMaxWidth().padding(horizontal=14.dp,vertical=7.dp),shape=RoundedCornerShape(27.dp),colors=CardDefaults.cardColors(Navy),elevation=CardDefaults.cardElevation(5.dp)){Column(Modifier.padding(18.dp)){Row(verticalAlignment=Alignment.CenterVertically){Surface(color=Color.White.copy(alpha=.13f),shape=CircleShape){Icon(Icons.Default.AccountBalanceWallet,null,tint=Color.White,modifier=Modifier.padding(9.dp))};Spacer(Modifier.width(9.dp));Column{Text("RINGKASAN KEUANGAN",color=Color.White.copy(alpha=.72f),fontSize=9.sp,fontWeight=FontWeight.Bold);Text(month,color=Color.White.copy(alpha=.75f),fontSize=10.sp)}};Spacer(Modifier.height(12.dp));Text("Pendapatan bersih",color=Color.White.copy(alpha=.75f),fontSize=11.sp);Text(rupiah(net),color=Color.White,fontSize=32.sp,fontWeight=FontWeight.ExtraBold);Spacer(Modifier.height(12.dp));Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){FinanceMini("Pemasukan",rupiah(income),Green,Modifier.weight(1f));FinanceMini("Pengeluaran",rupiah(expense),Red,Modifier.weight(1f))}}}}

@Composable fun FinanceMini(label:String,value:String,accent:Color,modifier:Modifier){Surface(color=Color.White.copy(alpha=.10f),shape=RoundedCornerShape(14.dp),modifier=modifier){Column(Modifier.padding(10.dp)){Text(label,color=Color.White.copy(alpha=.72f),fontSize=10.sp);Text(value,color=Color.White,fontWeight=FontWeight.ExtraBold,fontSize=16.sp)}}}
@Composable fun RowScope.StatCard(title:String,value:String,icon:ImageVector,accent:Color,bg:Color,onClick:()->Unit){
    val cardBg=when(title){"Total Siswa"->Color(0xFFE6F3FF);"Sudah Bayar"->Color(0xFFE2F9EC);"Kurang Bayar"->Color(0xFFFFF3CF);else->Color(0xFFFFE4EC)}
    val titleColor=when(title){"Sudah Bayar"->Color(0xFF08764F);"Kurang Bayar"->Color(0xFF78510D);"Belum Bayar"->Color(0xFF5B315F);else->Navy}
    val subtitle=when(title){"Total Siswa"->"Semangat terus\nmembimbing generasi hebat";"Sudah Bayar"->"Terima kasih\natas kepercayaannya";"Kurang Bayar"->"Ayo selesaikan pembayaran\ntepat waktu";else->"Segera lakukan pembayaran\nagar proses belajar tetap lancar"}
    Card(Modifier.weight(1f).height(136.dp).clickable(onClick=onClick),shape=RoundedCornerShape(22.dp),colors=CardDefaults.cardColors(cardBg),elevation=CardDefaults.cardElevation(defaultElevation=5.dp, pressedElevation=3.dp)){
        Box(Modifier.fillMaxSize()){
            Canvas(Modifier.fillMaxSize()){
                val path=androidx.compose.ui.graphics.Path().apply{
                    moveTo(0f,size.height-42f);quadraticBezierTo(size.width*.28f,size.height-68f,size.width*.52f,size.height-38f);quadraticBezierTo(size.width*.78f,size.height-8f,size.width,size.height-38f);lineTo(size.width,size.height);lineTo(0f,size.height);close()
                }
                drawPath(path,accent.copy(alpha=.18f))
            }
            Row(Modifier.fillMaxSize().padding(11.dp),verticalAlignment=Alignment.CenterVertically){
                Surface(color=Color.White.copy(alpha=.72f),shape=CircleShape,modifier=Modifier.size(54.dp)){Box(contentAlignment=Alignment.Center){Icon(icon,null,tint=accent,modifier=Modifier.size(30.dp))}}
                Spacer(Modifier.width(9.dp));Column(Modifier.weight(1f)){Text(title,fontSize=10.sp,color=titleColor,fontWeight=FontWeight.ExtraBold,maxLines=2);Text(value,fontSize=27.sp,lineHeight=29.sp,fontWeight=FontWeight.ExtraBold,color=accent,maxLines=1,softWrap=false);Text(subtitle,fontSize=8.sp,lineHeight=11.sp,color=titleColor,maxLines=2,fontWeight=FontWeight.SemiBold)}
                Icon(Icons.Default.ChevronRight,null,tint=accent,modifier=Modifier.size(21.dp))
            }
        }
    }
}

@Composable fun VisualSectionHeader(title:String,subtitle:String,icon:ImageVector=Icons.Default.AutoAwesome){Row(Modifier.fillMaxWidth().padding(horizontal=18.dp,vertical=8.dp),verticalAlignment=Alignment.CenterVertically){Surface(color=SoftPurple,shape=CircleShape){Icon(icon,null,tint=Navy,modifier=Modifier.padding(8.dp).size(20.dp))};Spacer(Modifier.width(9.dp));Column{Text(title,fontSize=18.sp,fontWeight=FontWeight.ExtraBold,color=Navy);Text(subtitle,fontSize=10.sp,color=Color.Gray)}}}
data class ProgramColors(val bg:Color,val accent:Color,val iconBg:Color)
fun programColors(name:String):ProgramColors{val n=name.lowercase(Locale.getDefault());return when{n.contains("bimbel")->ProgramColors(Color(0xFFE3F6EA),Color(0xFF2E9B61),Color(0xFFCDEFD9));n.contains("calistung")->ProgramColors(Color(0xFFFFF2CC),Color(0xFFB98200),Color(0xFFFFE6A3));n.contains("iqro")||n.contains("qur")||n.contains("al-qur")->ProgramColors(Color(0xFFE0F2FF),Color(0xFF2184C5),Color(0xFFC8E8FA));n.contains("english")->ProgramColors(Color(0xFFFCE4F1),Color(0xFFC44D91),Color(0xFFF7C9E2));n.contains("komputer")||n.contains("computer")->ProgramColors(Color(0xFFEDE4FF),Color(0xFF7551B5),Color(0xFFDCCEFF));else->{val palette=listOf(ProgramColors(Color(0xFFE8F5E9),Color(0xFF3A8F5D),Color(0xFFD2EEDB)),ProgramColors(Color(0xFFFFF3D6),Color(0xFFB68116),Color(0xFFFFE5A3)),ProgramColors(Color(0xFFE4F3FB),Color(0xFF2B82B8),Color(0xFFC9E8F7)),ProgramColors(Color(0xFFFBE5F2),Color(0xFFC24D8C),Color(0xFFF5CBE1)),ProgramColors(Color(0xFFEDE5FB),Color(0xFF7453AD),Color(0xFFDCD0F5)));palette[kotlin.math.abs(name.hashCode())%palette.size]}}}
@Composable fun SectionTitle(title:String,action:String?=null){val c=programColors(title);Card(Modifier.fillMaxWidth().padding(horizontal=12.dp,vertical=5.dp),shape=RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(c.bg)){Row(Modifier.padding(horizontal=14.dp,vertical=10.dp),verticalAlignment=Alignment.CenterVertically){Surface(color=c.iconBg,shape=CircleShape){Icon(Icons.Default.Groups,null,tint=c.accent,modifier=Modifier.padding(7.dp).size(17.dp))};Spacer(Modifier.width(9.dp));Text(title,fontWeight=FontWeight.Bold,color=Navy,fontSize=16.sp,modifier=Modifier.weight(1f));if(action!=null)Text(action,color=c.accent,fontSize=11.sp,fontWeight=FontWeight.Bold)}}}
@Composable fun ProgramCard(name:String,total:Int,lunas:Int,kurang:Int,belum:Int){val c=programColors(name);val icon=when{name.contains("English",true)->Icons.Default.Language;name.contains("Iqro",true)->Icons.Default.MenuBook;else->Icons.Default.Groups};Card(Modifier.fillMaxWidth().padding(horizontal=12.dp,vertical=5.dp),shape=RoundedCornerShape(19.dp),colors=CardDefaults.cardColors(c.bg),elevation=CardDefaults.cardElevation(1.dp)){Row(Modifier.padding(13.dp),verticalAlignment=Alignment.CenterVertically){Surface(color=c.iconBg,shape=CircleShape){Icon(icon,null,tint=c.accent,modifier=Modifier.padding(10.dp))};Spacer(Modifier.width(11.dp));Column(Modifier.weight(1f)){Text(name,fontWeight=FontWeight.Bold,color=Navy);Text("$total siswa",fontSize=11.sp,color=Color.Gray);Spacer(Modifier.height(4.dp));Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){TinyStatus("$lunas Lunas",Green);if(kurang>0)TinyStatus("$kurang Kurang",Yellow);if(belum>0)TinyStatus("$belum Belum",Red)}};Icon(Icons.Default.ChevronRight,null,tint=c.accent)}}}
@Composable fun TinyStatus(text:String,color:Color){Surface(color=color.copy(alpha=.12f),shape=RoundedCornerShape(20.dp)){Text(text,color=color,fontSize=9.sp,fontWeight=FontWeight.Bold,modifier=Modifier.padding(horizontal=7.dp,vertical=3.dp))}}

@Composable
fun StudentsScreen(
    students:List<Student>, programs:List<Program>, onEdit:(Student)->Unit, onAdd:()->Unit, onProgram:(String)->Unit
){
    var q by remember{mutableStateOf("")}
    val programNames=programs.map{it.name}.distinct().sortedWith(String.CASE_INSENSITIVE_ORDER)
    val visiblePrograms=programNames.filter{q.isBlank()||it.contains(q,true)||students.any{s->s.program.equals(it,true)&&s.name.contains(q,true)}}
    LazyColumn(Modifier.fillMaxSize().background(Bg),contentPadding=PaddingValues(bottom=20.dp)){
        item{
            Image(painterResource(R.drawable.final_siswa_header),"Blueprint Data Siswa",Modifier.fillMaxWidth().height(250.dp),contentScale=androidx.compose.ui.layout.ContentScale.FillBounds)
        }
        item{
            Row(Modifier.fillMaxWidth().padding(horizontal=18.dp,vertical=8.dp),horizontalArrangement=Arrangement.spacedBy(8.dp),verticalAlignment=Alignment.CenterVertically){
                OutlinedTextField(q,{q=it},modifier=Modifier.weight(1f).height(58.dp),placeholder={Text("Cari program / nama siswa...",fontSize=11.sp)},leadingIcon={Icon(Icons.Default.Search,null,tint=Navy)},singleLine=true,shape=RoundedCornerShape(18.dp),colors=OutlinedTextFieldDefaults.colors(unfocusedContainerColor=Color.White,focusedContainerColor=Color.White,unfocusedBorderColor=Color(0xFFD3DCE8),focusedBorderColor=Navy))
                Button(onClick=onAdd,modifier=Modifier.width(122.dp).height(58.dp),shape=RoundedCornerShape(18.dp),colors=ButtonDefaults.buttonColors(Navy),contentPadding=PaddingValues(horizontal=10.dp)){Icon(Icons.Default.Add,null,modifier=Modifier.size(20.dp));Spacer(Modifier.width(4.dp));Text("Tambah",fontSize=13.sp,fontWeight=FontWeight.ExtraBold,color=Color.White)}
            }
        }
        item{Text("Daftar Program",fontSize=23.sp,fontWeight=FontWeight.ExtraBold,color=Navy,modifier=Modifier.padding(start=18.dp,top=10.dp,bottom=6.dp))}
        items(visiblePrograms,key={it}){program->
            ProgramListCard(name=program,count=students.count{it.program.equals(program,true)},fee=programs.firstOrNull{it.name.equals(program,true)}?.fee,iconKey=programs.firstOrNull{it.name.equals(program,true)}?.iconKey ?: programsIconKey(program),matchedNames=if(q.isBlank()) emptyList() else students.filter{it.program.equals(program,true)&&it.name.contains(q,true)}.sortedBy{it.name.lowercase(Locale.getDefault())}.map{it.name},onClick={onProgram(program)})
        }
        if(visiblePrograms.isEmpty())item{EmptyFinanceCard("Program tidak ditemukan.",Navy)}
    }
}
@Composable fun ProgramQuickCard(name:String,count:Int,fee:Long?,selected:Boolean,onClick:()->Unit){val c=if(name=="Semua")ProgramColors(SoftBlue,Navy,Color(0xFFD7E9FA)) else programColors(name);Card(Modifier.width(148.dp).height(94.dp).clickable(onClick=onClick),shape=RoundedCornerShape(20.dp),colors=CardDefaults.cardColors(c.bg),elevation=CardDefaults.cardElevation(if(selected)4.dp else 2.dp)){Column(Modifier.padding(11.dp),verticalArrangement=Arrangement.spacedBy(4.dp)){Row(verticalAlignment=Alignment.CenterVertically){Surface(color=c.iconBg,shape=CircleShape){if(name=="Semua")Icon(Icons.Default.Groups,null,tint=c.accent,modifier=Modifier.padding(7.dp).size(22.dp))else ProgramIcon3D(programsIconKey(name),modifier=Modifier.padding(4.dp).size(28.dp))};Spacer(Modifier.width(7.dp));Text(name,fontWeight=FontWeight.ExtraBold,color=Navy,fontSize=12.sp,maxLines=2,overflow=TextOverflow.Ellipsis)}};Text("$count siswa",fontSize=10.sp,color=Color.Gray,fontWeight=FontWeight.Bold);if(fee!=null)Text(rupiah(fee)+" / bln",fontSize=9.sp,color=c.accent,fontWeight=FontWeight.ExtraBold)}}

@Composable fun ProgramListCard(name:String,count:Int,fee:Long?,iconKey:String,matchedNames:List<String> = emptyList(),onClick:()->Unit){val c=programColors(name);Card(Modifier.fillMaxWidth().padding(horizontal=18.dp,vertical=4.dp).clickable(onClick=onClick),shape=RoundedCornerShape(20.dp),colors=CardDefaults.cardColors(c.bg),elevation=CardDefaults.cardElevation(2.dp)){Row(Modifier.padding(13.dp),verticalAlignment=Alignment.CenterVertically){Surface(color=c.iconBg,shape=CircleShape){ProgramIcon3D(iconKey,modifier=Modifier.padding(5.dp).size(42.dp))};Spacer(Modifier.width(11.dp));Column(Modifier.weight(1f)){Text("$name ($count)",fontWeight=FontWeight.ExtraBold,color=Navy,fontSize=16.sp);Text(if(fee!=null)"${rupiah(fee)} / bulan" else "Tarif belum diatur",fontSize=10.sp,color=Color.Gray);if(matchedNames.isNotEmpty())Text(matchedNames.joinToString(", "),fontSize=11.sp,color=Navy,fontWeight=FontWeight.ExtraBold,maxLines=2,overflow=TextOverflow.Ellipsis);Text("Tekan untuk melihat siswa",fontSize=9.sp,color=c.accent,fontWeight=FontWeight.Bold)};Icon(Icons.Default.ChevronRight,null,tint=c.accent,modifier=Modifier.size(25.dp))}}}

@Composable fun ModernFilter(text:String,selected:Boolean,onClick:()->Unit){Surface(color=if(selected)Navy else Color.White,shape=RoundedCornerShape(18.dp),border=if(selected)null else androidx.compose.foundation.BorderStroke(1.dp,Color(0xFFD3DCE8)),shadowElevation=if(selected)2.dp else 0.dp,modifier=Modifier.clickable(onClick=onClick)){Text(text,color=if(selected)Color.White else Navy,fontSize=10.sp,fontWeight=FontWeight.Bold,modifier=Modifier.padding(horizontal=13.dp,vertical=8.dp),maxLines=1)}}

@Composable fun StudentProgramHeader(program:String,students:List<Student>,fee:Long?,open:Boolean,iconKey:String=program,onClick:()->Unit){val c=programColors(program);Card(Modifier.fillMaxWidth().padding(horizontal=18.dp,vertical=5.dp).clickable(onClick=onClick),shape=RoundedCornerShape(22.dp),colors=CardDefaults.cardColors(c.bg),elevation=CardDefaults.cardElevation(2.dp)){Row(Modifier.padding(14.dp),verticalAlignment=Alignment.CenterVertically){Surface(color=c.iconBg,shape=CircleShape,modifier=Modifier.size(60.dp)){Box(contentAlignment=Alignment.Center){ProgramIcon3D(iconKey,modifier=Modifier.size(48.dp))}};Spacer(Modifier.width(12.dp));Column(Modifier.weight(1f)){Text("$program (${students.size})",fontWeight=FontWeight.ExtraBold,color=Navy,fontSize=19.sp);Text("${rupiah(fee ?: students.firstOrNull()?.monthlyFee ?: 0)} / bulan",fontSize=12.sp,color=Color.Gray);Text(students.joinToString(", "){it.name}.let{if(it.length>44)it.take(41)+"..." else it},fontSize=10.sp,color=Color.Gray,maxLines=1)};Surface(color=c.iconBg,shape=CircleShape){Icon(Icons.Default.ChevronRight,null,tint=c.accent,modifier=Modifier.padding(7.dp).size(25.dp))}}}}

fun programIcon(program:String):ImageVector=when{
    program.equals("language",true)||program.contains("English",true)->Icons.Default.Language
    program.equals("menu",true)||program.contains("Iqro",true)||program.contains("Qur",true)->Icons.Default.MenuBook
    program.equals("computer",true)||program.contains("Komputer",true)->Icons.Default.Computer
    program.equals("abc",true)||program.contains("Calistung",true)->Icons.Default.AutoStories
    program.equals("school",true)||program.contains("Bimbel",true)->Icons.Default.School
    program.equals("palette",true)||program.contains("Seni",true)->Icons.Default.Palette
    program.equals("music",true)->Icons.Default.MusicNote
    program.equals("science",true)->Icons.Default.Science
    program.equals("math",true)->Icons.Default.Calculate
    program.equals("brain",true)->Icons.Default.Psychology
    program.equals("creative",true)->Icons.Default.Lightbulb
    program.equals("achievement",true)->Icons.Default.EmojiEvents
    program.equals("writing",true)->Icons.Default.Create
    program.equals("world",true)->Icons.Default.Public
    program.equals("sports",true)->Icons.Default.SportsSoccer
    program.equals("library",true)->Icons.Default.LocalLibrary
    program.equals("star",true)->Icons.Default.Star
    program.equals("kids",true)->Icons.Default.ChildCare
    else->Icons.Default.Groups
}

fun programsIconKey(program:String):String{val n=program.lowercase(Locale.getDefault());return when{n.contains("english")->"language";n.contains("iqro")||n.contains("qur")->"menu";n.contains("calistung")->"abc";n.contains("matematika")->"math";n.contains("ipa")->"science";n.contains("komputer")->"computer";n.contains("seni")->"palette";n.contains("musik")->"music";n.contains("olahraga")->"sports";n.contains("bahasa")->"world";n.contains("bimbel")->"school";else->"groups"}}

@Composable fun PaymentProgramHeader(program:String,students:List<Student>,payments:List<Payment>,month:String,open:Boolean,onClick:()->Unit){val c=programColors(program);val paidFor={s:Student->payments.firstOrNull{it.studentId==s.id&&it.month.equals(month,true)}?.amount?:0L};val lunas=students.count{paidFor(it)>=it.monthlyFee};val kurang=students.count{val a=paidFor(it);a>0&&a<it.monthlyFee};val belum=students.count{paidFor(it)==0L};Card(Modifier.fillMaxWidth().padding(horizontal=12.dp,vertical=5.dp).clickable(onClick=onClick),shape=RoundedCornerShape(20.dp),colors=CardDefaults.cardColors(c.bg),elevation=CardDefaults.cardElevation(1.dp)){Row(Modifier.padding(12.dp),verticalAlignment=Alignment.CenterVertically){Surface(color=c.iconBg,shape=CircleShape){ProgramIcon3D(programsIconKey(program),modifier=Modifier.padding(4.dp).size(36.dp))};Spacer(Modifier.width(10.dp));Column(Modifier.weight(1f)){Text("$program (${students.size})",fontWeight=FontWeight.ExtraBold,color=Navy,fontSize=16.sp);Row(horizontalArrangement=Arrangement.spacedBy(5.dp)){if(lunas>0)TinyStatus("$lunas Lunas",Green);if(kurang>0)TinyStatus("$kurang Kurang",Yellow);if(belum>0)TinyStatus("$belum Belum",Red)}};Icon(if(open)Icons.Default.ExpandLess else Icons.Default.ChevronRight,null,tint=c.accent)}}}

@Composable fun ProgramGroupHeader(program:String,total:Int,open:Boolean,iconKey:String=program,onClick:()->Unit){val c=programColors(program);val icon=programIcon(iconKey);Card(Modifier.fillMaxWidth().padding(horizontal=14.dp,vertical=5.dp).clickable(onClick=onClick),shape=RoundedCornerShape(22.dp),colors=CardDefaults.cardColors(c.bg),elevation=CardDefaults.cardElevation(2.dp)){Row(Modifier.padding(13.dp),verticalAlignment=Alignment.CenterVertically){Surface(color=c.iconBg,shape=CircleShape){Icon(icon,null,tint=c.accent,modifier=Modifier.padding(11.dp).size(23.dp))};Spacer(Modifier.width(11.dp));Column(Modifier.weight(1f)){Text(program,fontWeight=FontWeight.ExtraBold,color=Navy,fontSize=16.sp);Text("$total siswa • tekan untuk melihat daftar",fontSize=11.sp,color=Color.Gray)}};Surface(color=c.iconBg,shape=CircleShape){Icon(if(open)Icons.Default.ExpandLess else Icons.Default.ExpandMore,null,tint=c.accent,modifier=Modifier.padding(6.dp).size(20.dp))}}}

@Composable fun StudentDataCard(s:Student,onEdit:(Student)->Unit){val c=programColors(s.program);Card(Modifier.fillMaxWidth().padding(horizontal=16.dp,vertical=4.dp),shape=RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(Color.White),elevation=CardDefaults.cardElevation(1.dp)){Row(Modifier.padding(10.dp),verticalAlignment=Alignment.CenterVertically){Avatar(s);Spacer(Modifier.width(10.dp));Column(Modifier.weight(1f)){Text(s.name,fontWeight=FontWeight.ExtraBold,color=Navy,fontSize=16.sp);Text(s.className,fontSize=11.sp,color=Color.Gray)};Surface(color=c.bg,shape=CircleShape){IconButton(onClick={onEdit(s)}){Icon(Icons.Default.MoreVert,"Edit",tint=c.accent)}}}}}

@Composable fun Avatar(s:Student){val path=s.avatarPath;val preset=when{path.startsWith("builtin_avatar_")->path.substringAfterLast('_').toIntOrNull()?.coerceIn(1,20);path=="builtin_male"->1;path=="builtin_female"->11;else->null};if(preset!=null){AvatarIllustration(preset);return};if(path.isNotBlank()){val bmp=remember(path){BitmapFactory.decodeFile(path)};if(bmp!=null){Image(bmp.asImageBitmap(),"Foto siswa",Modifier.size(58.dp).clip(CircleShape),contentScale=androidx.compose.ui.layout.ContentScale.Crop);return}};AvatarIllustration(1)}
@Composable fun AvatarIllustration(index:Int){val ctx=androidx.compose.ui.platform.LocalContext.current;val id=ctx.resources.getIdentifier("avatar_3d_${index.coerceIn(1,20)}","drawable",ctx.packageName);if(id!=0)Image(painterResource(id),"Avatar siswa",Modifier.size(58.dp).clip(RoundedCornerShape(16.dp)),contentScale=androidx.compose.ui.layout.ContentScale.Crop)else Surface(color=SoftBlue,shape=CircleShape,modifier=Modifier.size(58.dp)){Icon(Icons.Default.Person,null,tint=Navy,modifier=Modifier.padding(13.dp))}}

@Composable fun ProgramIcon3D(key:String,contentDescription:String?=null,modifier:Modifier=Modifier.size(30.dp)){val ctx=androidx.compose.ui.platform.LocalContext.current;val map=mapOf("school" to 1,"abc" to 2,"menu" to 3,"language" to 4,"math" to 5,"science" to 6,"world" to 12,"palette" to 8,"music" to 9,"computer" to 10,"sports" to 11,"writing" to 16,"brain" to 14,"creative" to 18,"achievement" to 20,"library" to 13,"star" to 20,"kids" to 15,"groups" to 15,"robotik" to 17,"keagamaan" to 19,"ips" to 7);val n=map[key.lowercase(Locale.getDefault())] ?: 20;val id=ctx.resources.getIdentifier("program_icon_3d_$n","drawable",ctx.packageName);if(id!=0)Image(painterResource(id),contentDescription,modifier.clip(RoundedCornerShape(14.dp)),contentScale=androidx.compose.ui.layout.ContentScale.Crop)else Icon(programIcon(key),contentDescription,tint=Navy,modifier=modifier)}

@Composable fun StatusChip(status:String){val(c,bg)=when(status){"LUNAS"->Green to SoftGreen;"KURANG"->Yellow to SoftYellow;else->Red to SoftRed};Surface(color=bg,shape=RoundedCornerShape(20.dp)){Text(status,color=c,fontWeight=FontWeight.Bold,fontSize=10.sp,modifier=Modifier.padding(horizontal=9.dp,vertical=5.dp))}}

@Composable
fun PaymentsScreen(students:List<Student>,programs:List<Program>,payments:List<Payment>,filter:String,month:String,onPreviousMonth:()->Unit,onNextMonth:()->Unit,onClearFilter:()->Unit,onFilterChange:(String)->Unit,onPay:(Student)->Unit,onDelete:(Payment)->Unit,onEditStatus:(Student)->Unit,onProgram:(String)->Unit){
    val groups=students.groupBy{it.program}; var q by remember{mutableStateOf("")}
    LazyColumn(Modifier.fillMaxSize().background(Bg),contentPadding=PaddingValues(bottom=20.dp)){
        item{Image(painterResource(R.drawable.final_bayar_header),"Background Pembayaran",Modifier.fillMaxWidth().height(250.dp),contentScale=androidx.compose.ui.layout.ContentScale.FillBounds)}
        item{
            OutlinedTextField(q,{q=it},modifier=Modifier.fillMaxWidth().padding(horizontal=18.dp,vertical=8.dp).height(58.dp),placeholder={Text("Cari nama siswa...",fontSize=12.sp)},leadingIcon={Icon(Icons.Default.Search,null,tint=Navy)},singleLine=true,shape=RoundedCornerShape(17.dp),colors=OutlinedTextFieldDefaults.colors(unfocusedContainerColor=Color.White,focusedContainerColor=Color.White,unfocusedBorderColor=Color(0xFFD3DCE8),focusedBorderColor=Navy))
        }
        item{Row(Modifier.fillMaxWidth().padding(horizontal=18.dp,vertical=8.dp),horizontalArrangement=Arrangement.spacedBy(7.dp)){listOf("Semua","Lunas","Kurang Bayar","Belum Bayar").forEach{st->ModernFilter(st,filter==st){if(st=="Semua")onClearFilter() else onFilterChange(st)}}}}
        groups.toSortedMap(String.CASE_INSENSITIVE_ORDER).forEach{(program,list)->
            val visible=list.filter{s->val paid=payments.firstOrNull{it.studentId==s.id&&it.month.equals(month,true)}?.amount?:0L;val status=when{paid>=s.monthlyFee->"Lunas";paid>0->"Kurang Bayar";else->"Belum Bayar"};(q.isBlank()||s.name.contains(q,true))&&(filter=="Semua"||status==filter)}
            if(visible.isNotEmpty()){val sorted=visible.sortedBy{it.name.trim().lowercase(Locale.getDefault())};item{PaymentProgramHeaderModern(program,sorted.size,programs.firstOrNull{it.name.equals(program,true)}?.fee,matchedNames=if(q.isBlank()) emptyList() else sorted.map{it.name}){onProgram(program)}}}
        }
    }
}
@Composable fun PaymentProgramHeaderModern(program:String,total:Int,fee:Long?,matchedNames:List<String> = emptyList(),onClick:()->Unit){val c=programColors(program);Card(Modifier.fillMaxWidth().padding(horizontal=18.dp,vertical=5.dp).clickable(onClick=onClick),shape=RoundedCornerShape(22.dp),colors=CardDefaults.cardColors(c.bg),elevation=CardDefaults.cardElevation(4.dp)){Row(Modifier.padding(14.dp),verticalAlignment=Alignment.CenterVertically){Surface(color=c.iconBg,shape=CircleShape){ProgramIcon3D(programsIconKey(program),modifier=Modifier.padding(5.dp).size(42.dp))};Spacer(Modifier.width(12.dp));Column(Modifier.weight(1f)){Text("$program ($total)",fontWeight=FontWeight.ExtraBold,color=Navy,fontSize=18.sp);Text("${rupiah(fee ?: 0)} / bulan",fontSize=11.sp,color=Color.Gray);if(matchedNames.isNotEmpty())Text(matchedNames.joinToString(", "),fontSize=11.sp,color=Navy,fontWeight=FontWeight.ExtraBold,maxLines=2,overflow=TextOverflow.Ellipsis)};Surface(color=c.iconBg,shape=CircleShape){Icon(Icons.Default.ChevronRight,null,tint=c.accent,modifier=Modifier.padding(8.dp).size(24.dp))}}}}

@Composable
fun PaymentStudentCard(
    s:Student, payment:Payment?, onPay:(Student)->Unit, onDelete:(Payment)->Unit, onEditStatus:(Student)->Unit
){
    val ctx=androidx.compose.ui.platform.LocalContext.current
    val pc=programColors(s.program)
    val paid=payment?.amount?:0L
    val status=when{paid>=s.monthlyFee->"LUNAS";paid>0->"KURANG BAYAR";else->"BELUM BAYAR"}
    val accent=when(status){"LUNAS"->Green;"KURANG BAYAR"->Yellow;else->Red}
    val bg=when(status){"LUNAS"->SoftGreen;"KURANG BAYAR"->SoftYellow;else->SoftRed}
    Card(
        Modifier.fillMaxWidth().padding(horizontal=18.dp,vertical=4.dp),
        shape=RoundedCornerShape(21.dp),
        colors=CardDefaults.cardColors(Color.White),
        elevation=CardDefaults.cardElevation(2.dp)
    ){
        Column(Modifier.padding(12.dp)){
            Row(verticalAlignment=Alignment.CenterVertically){
                Surface(color=pc.iconBg,shape=CircleShape){Avatar(s)}
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)){
                    Text(s.name,fontWeight=FontWeight.ExtraBold,color=Navy,fontSize=15.sp)
                    Text("${s.className} • ${s.program}",fontSize=10.sp,color=Color.Gray)
                }
                StatusChip(status)
                IconButton(onClick={onEditStatus(s)}){Icon(Icons.Default.MoreVert,"Ubah status pembayaran",tint=accent)}
            }
            Spacer(Modifier.height(10.dp))
            Surface(color=bg,shape=RoundedCornerShape(15.dp),modifier=Modifier.fillMaxWidth()){
                Row(Modifier.fillMaxWidth().padding(10.dp),horizontalArrangement=Arrangement.SpaceBetween){
                    Column{Text("TAGIHAN",fontSize=8.sp,color=Color.Gray);Text(rupiah(s.monthlyFee),fontWeight=FontWeight.Bold,color=Navy,fontSize=11.sp)}
                    Column{Text("DIBAYAR",fontSize=8.sp,color=Color.Gray);Text(rupiah(paid),fontWeight=FontWeight.Bold,color=Navy,fontSize=11.sp)}
                    Column(horizontalAlignment=Alignment.End){Text("SISA",fontSize=8.sp,color=Color.Gray);Text(rupiah((s.monthlyFee-paid).coerceAtLeast(0)),fontWeight=FontWeight.ExtraBold,color=accent,fontSize=12.sp)}
                }
            }
            Spacer(Modifier.height(7.dp))
            Text("Tekan ⋮ untuk mengubah status dan mengelola kuitansi.",fontSize=9.sp,color=Color.Gray,fontWeight=FontWeight.SemiBold)
        }
    }
}

@Composable
fun StudentDetailPage(s:Student,onEdit:()->Unit,onDelete:()->Unit,onBack:()->Unit){
    var confirmDelete by remember{mutableStateOf(false)}
    val c=programColors(s.program)
    LazyColumn(Modifier.fillMaxSize().background(Bg),contentPadding=PaddingValues(bottom=24.dp)){
        item{
            Card(Modifier.fillMaxWidth().padding(18.dp),shape=RoundedCornerShape(26.dp),colors=CardDefaults.cardColors(Color.White),elevation=CardDefaults.cardElevation(3.dp)){
                Column(Modifier.padding(18.dp)){
                    Row(verticalAlignment=Alignment.CenterVertically){
                        IconButton(onClick=onBack){Icon(Icons.Default.ArrowBack,"Kembali",tint=Navy)}
                        Spacer(Modifier.width(4.dp));Text("Biodata Siswa",fontSize=23.sp,fontWeight=FontWeight.ExtraBold,color=Navy)
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(verticalAlignment=Alignment.CenterVertically){Avatar(s);Spacer(Modifier.width(14.dp));Column(Modifier.weight(1f)){Text(s.name,fontSize=22.sp,fontWeight=FontWeight.ExtraBold,color=Navy);Surface(color=c.bg,shape=RoundedCornerShape(20.dp)){Text(s.program,color=c.accent,fontWeight=FontWeight.ExtraBold,fontSize=11.sp,modifier=Modifier.padding(horizontal=12.dp,vertical=6.dp))}}}
                }
            }
        }
        item{
            Card(Modifier.fillMaxWidth().padding(horizontal=18.dp,vertical=4.dp),shape=RoundedCornerShape(24.dp),colors=CardDefaults.cardColors(Color.White),elevation=CardDefaults.cardElevation(2.dp)){
                Column(Modifier.padding(18.dp)){
                    Text("Informasi Pribadi",fontSize=20.sp,fontWeight=FontWeight.ExtraBold,color=Navy);Spacer(Modifier.height(8.dp))
                    BiodataLine("Nama Lengkap",s.name,Icons.Default.Person);BiodataLine("Kelas",s.className.ifBlank{"-"},Icons.Default.School);BiodataLine("Sekolah Asal",s.schoolOrigin.ifBlank{"-"},Icons.Default.AccountBalance);BiodataLine("Tanggal Lahir",s.birthDate.ifBlank{"-"},Icons.Default.CalendarMonth);BiodataLine("Umur",calculateAge(s.birthDate),Icons.Default.Cake);BiodataLine("Program",s.program,Icons.Default.Groups);BiodataLine("Tarif per Bulan",rupiah(s.monthlyFee),Icons.Default.Payments);BiodataLine("No HP",s.parentPhone.ifBlank{"-"},Icons.Default.Phone);BiodataLine("Catatan",s.note.ifBlank{"-"},Icons.Default.Notes)
                }
            }
        }
        item{Row(Modifier.fillMaxWidth().padding(18.dp),horizontalArrangement=Arrangement.spacedBy(10.dp)){Button(onClick=onEdit,modifier=Modifier.weight(1f).height(52.dp),shape=RoundedCornerShape(15.dp),colors=ButtonDefaults.buttonColors(Navy)){Icon(Icons.Default.Edit,null);Spacer(Modifier.width(6.dp));Text("Edit Data",fontWeight=FontWeight.ExtraBold)};Button(onClick={confirmDelete=true},modifier=Modifier.weight(1f).height(52.dp),shape=RoundedCornerShape(15.dp),colors=ButtonDefaults.buttonColors(Red)){Icon(Icons.Default.Delete,null);Spacer(Modifier.width(6.dp));Text("Hapus Siswa",fontWeight=FontWeight.ExtraBold)}}}
    }
    if(confirmDelete)AlertDialog(onDismissRequest={confirmDelete=false},title={Text("Hapus siswa?",fontWeight=FontWeight.ExtraBold,color=Navy)},text={Text("Data ${s.name} akan dihapus dari halaman Siswa dan pembayaran siswa tersebut juga akan dihapus.")},confirmButton={Button(onClick={confirmDelete=false;onDelete()},colors=ButtonDefaults.buttonColors(Red)){Text("Hapus")}},dismissButton={TextButton(onClick={confirmDelete=false}){Text("Batal",color=Navy)}})
}

@Composable fun BiodataLine(label:String,value:String,icon:ImageVector){Row(Modifier.fillMaxWidth().padding(vertical=7.dp),verticalAlignment=Alignment.Top){Surface(color=SoftBlue,shape=CircleShape){Icon(icon,null,tint=Navy,modifier=Modifier.padding(8.dp).size(19.dp))};Spacer(Modifier.width(10.dp));Text(label,fontSize=11.sp,color=Color.Gray,modifier=Modifier.width(105.dp).padding(top=4.dp));Text(":",fontSize=12.sp,color=Color.Gray,modifier=Modifier.padding(top=4.dp));Spacer(Modifier.width(8.dp));Text(value,fontSize=13.sp,fontWeight=FontWeight.Bold,color=Navy,modifier=Modifier.weight(1f))}}

@Composable fun StudentProgramPage(program:String,students:List<Student>,fee:Long?,onStudentClick:(Student)->Unit,onBack:()->Unit){
    val list=students.sortedBy{it.name.trim().lowercase(Locale.getDefault())}
    LazyColumn(Modifier.fillMaxSize().background(Bg),contentPadding=PaddingValues(bottom=20.dp)){
        item{Box(Modifier.fillMaxWidth().height(180.dp).clip(RoundedCornerShape(bottomStart=28.dp,bottomEnd=28.dp))){Image(painterResource(R.drawable.background_bayar),"Background program",Modifier.fillMaxSize(),contentScale=androidx.compose.ui.layout.ContentScale.Crop);Box(Modifier.fillMaxSize().background(Brush.horizontalGradient(listOf(Color.White.copy(alpha=.94f),Color.White.copy(alpha=.40f),Color.Transparent))));Column(Modifier.align(Alignment.BottomStart).padding(12.dp,0.dp,18.dp,18.dp)){Row(verticalAlignment=Alignment.CenterVertically){IconButton(onClick=onBack){Icon(Icons.Default.ArrowBack,"Kembali",tint=Navy,modifier=Modifier.size(28.dp))};Spacer(Modifier.width(2.dp));Column{Text(program,fontSize=25.sp,fontWeight=FontWeight.ExtraBold,color=Navy);Text("${rupiah(fee ?: students.firstOrNull()?.monthlyFee ?: 0)} / bulan",fontSize=12.sp,color=Navy,fontWeight=FontWeight.Bold)}}}}}
        item{Text("Daftar Siswa",fontSize=20.sp,fontWeight=FontWeight.ExtraBold,color=Navy,modifier=Modifier.padding(18.dp,15.dp,18.dp,6.dp))}
        itemsIndexed(list){index,s->Card(Modifier.fillMaxWidth().padding(horizontal=18.dp,vertical=4.dp).clickable{onStudentClick(s)},shape=RoundedCornerShape(19.dp),colors=CardDefaults.cardColors(Color.White),elevation=CardDefaults.cardElevation(3.dp)){Row(Modifier.padding(11.dp),verticalAlignment=Alignment.CenterVertically){Text("${index+1}",fontWeight=FontWeight.ExtraBold,color=Navy,fontSize=14.sp,modifier=Modifier.width(25.dp));Avatar(s);Spacer(Modifier.width(12.dp));Column(Modifier.weight(1f)){Text(s.name,fontWeight=FontWeight.ExtraBold,color=Navy,fontSize=16.sp);Text("${s.className} • ${s.program}",fontSize=10.sp,color=Color.Gray)};Icon(Icons.Default.ChevronRight,null,tint=programColors(s.program).accent)}}}
    }
}

@Composable fun StudentProgramRow(s:Student,onEdit:(Student)->Unit,onDelete:()->Unit){var menu by remember{mutableStateOf(false)};Card(Modifier.fillMaxWidth().padding(horizontal=18.dp,vertical=4.dp),shape=RoundedCornerShape(19.dp),colors=CardDefaults.cardColors(Color.White),elevation=CardDefaults.cardElevation(2.dp)){Row(Modifier.padding(11.dp),verticalAlignment=Alignment.CenterVertically){Avatar(s);Spacer(Modifier.width(12.dp));Column(Modifier.weight(1f)){Text(s.name,fontWeight=FontWeight.ExtraBold,color=Navy,fontSize=17.sp);Text(s.className,fontSize=11.sp,color=Color.Gray)};Box{IconButton(onClick={menu=true}){Icon(Icons.Default.MoreVert,"Menu siswa",tint=Navy)};DropdownMenu(expanded=menu,onDismissRequest={menu=false}){DropdownMenuItem(text={Text("Edit siswa")},onClick={menu=false;onEdit(s)});DropdownMenuItem(text={Text("Hapus siswa",color=Red)},onClick={menu=false;onDelete()})}}}}}

@Composable fun PaymentProgramPage(program:String,students:List<Student>,payments:List<Payment>,month:String,onBack:()->Unit,onEdit:(Student)->Unit){
    val list=students.sortedBy{it.name.trim().lowercase(Locale.getDefault())}
    val fee=students.firstOrNull()?.monthlyFee?:0L
    LazyColumn(Modifier.fillMaxSize().background(Bg),contentPadding=PaddingValues(bottom=20.dp)){
        item{Box(Modifier.fillMaxWidth().height(180.dp).clip(RoundedCornerShape(bottomStart=28.dp,bottomEnd=28.dp))){Image(painterResource(R.drawable.background_bayar),"Background program pembayaran",Modifier.fillMaxSize(),contentScale=androidx.compose.ui.layout.ContentScale.Crop);Box(Modifier.fillMaxSize().background(Brush.horizontalGradient(listOf(Color.White.copy(alpha=.94f),Color.White.copy(alpha=.38f),Color.Transparent))));Column(Modifier.align(Alignment.BottomStart).padding(12.dp,0.dp,18.dp,18.dp)){Row(verticalAlignment=Alignment.CenterVertically){IconButton(onClick=onBack){Icon(Icons.Default.ArrowBack,"Kembali",tint=Navy,modifier=Modifier.size(28.dp))};Spacer(Modifier.width(2.dp));Column{Text(program,fontSize=25.sp,fontWeight=FontWeight.ExtraBold,color=Navy);Text("${rupiah(fee)} / bulan",fontSize=12.sp,color=Navy,fontWeight=FontWeight.Bold)}}}}}
        item{Text("Daftar Siswa",fontSize=20.sp,fontWeight=FontWeight.ExtraBold,color=Navy,modifier=Modifier.padding(18.dp,15.dp,18.dp,6.dp))}
        itemsIndexed(list){index,s->val paid=payments.firstOrNull{it.studentId==s.id&&it.month.equals(month,true)}?.amount?:0L;val status=when{paid>=s.monthlyFee->"LUNAS";paid>0->"KURANG BAYAR";else->"BELUM BAYAR"};val accent=when(status){"LUNAS"->Green;"KURANG BAYAR"->Yellow;else->Red};Card(Modifier.fillMaxWidth().padding(horizontal=18.dp,vertical=4.dp),shape=RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(Color.White),elevation=CardDefaults.cardElevation(3.dp)){Row(Modifier.padding(11.dp),verticalAlignment=Alignment.CenterVertically){Text("${index+1}",fontWeight=FontWeight.ExtraBold,color=Navy,fontSize=14.sp,modifier=Modifier.width(25.dp));Avatar(s);Spacer(Modifier.width(11.dp));Text(s.name,fontWeight=FontWeight.ExtraBold,color=Navy,fontSize=16.sp,modifier=Modifier.weight(1f));Surface(color=accent.copy(alpha=.13f),shape=RoundedCornerShape(20.dp)){Text(status,color=accent,fontWeight=FontWeight.ExtraBold,fontSize=9.sp,modifier=Modifier.padding(horizontal=9.dp,vertical=6.dp))};IconButton(onClick={onEdit(s)}){Icon(Icons.Default.MoreVert,"Kelola pembayaran",tint=accent)}}}}
    }
}

@Composable
fun PaymentDetailPage(s:Student,payments:List<Payment>,month:String,onMonthChange:(String)->Unit,onPay:()->Unit,onEdit:()->Unit,onBack:()->Unit){
    val context=LocalContext.current
    val p=payments.firstOrNull{it.studentId==s.id&&it.month.equals(month,true)}
    val paid=p?.amount?:0L
    val status=when{paid>=s.monthlyFee->"LUNAS";paid>0->"KURANG BAYAR";else->"BELUM BAYAR"}
    val editable=month.equals(monthNow(),true)
    val statusColor=when(status){"LUNAS"->Green;"KURANG BAYAR"->Yellow;else->Red}
    LazyColumn(Modifier.fillMaxSize().background(Bg),contentPadding=PaddingValues(bottom=22.dp)){
        item{
            Row(Modifier.fillMaxWidth().padding(horizontal=18.dp,vertical=12.dp),verticalAlignment=Alignment.CenterVertically){
                IconButton(onClick=onBack){Icon(Icons.Default.ArrowBack,"Kembali",tint=Navy,modifier=Modifier.size(27.dp))}
                Spacer(Modifier.width(3.dp));Text("Pembayaran",fontSize=25.sp,fontWeight=FontWeight.ExtraBold,color=Navy,modifier=Modifier.weight(1f))
                Surface(color=SoftBlue,shape=CircleShape){IconButton(onClick={}){Icon(Icons.Default.NotificationsNone,null,tint=Navy)}}
            }
            Row(Modifier.padding(horizontal=28.dp,vertical=4.dp),verticalAlignment=Alignment.CenterVertically){Avatar(s);Spacer(Modifier.width(12.dp));Column{Text(s.name,fontSize=22.sp,fontWeight=FontWeight.ExtraBold,color=Navy);Text("• ${s.program}",fontSize=13.sp,color=Color.Gray)}}
        }
        item{MonthPill(month,{onMonthChange(shiftMonth(month,-1))},{onMonthChange(shiftMonth(month,1))})}
        if(!editable)item{Card(Modifier.fillMaxWidth().padding(horizontal=18.dp,vertical=4.dp),shape=RoundedCornerShape(15.dp),colors=CardDefaults.cardColors(SoftYellow)){Row(Modifier.padding(12.dp),verticalAlignment=Alignment.CenterVertically){Icon(Icons.Default.Lock,null,tint=Yellow);Spacer(Modifier.width(8.dp));Text("Pembayaran bulan $month terkunci.",fontSize=10.sp,color=Navy,fontWeight=FontWeight.Bold)}}}
        item{Card(Modifier.fillMaxWidth().padding(horizontal=18.dp,vertical=8.dp),shape=RoundedCornerShape(24.dp),colors=CardDefaults.cardColors(Color.White),elevation=CardDefaults.cardElevation(2.dp)){Column(Modifier.padding(18.dp),verticalArrangement=Arrangement.spacedBy(13.dp)){DetailLine("Tagihan",rupiah(s.monthlyFee));DetailLine("Sudah Dibayar",rupiah(paid));DetailLine("Sisa",rupiah((s.monthlyFee-paid).coerceAtLeast(0)),if(paid>=s.monthlyFee)Green else Red);DetailLine("Status",status,statusColor)}}}
        item{Button(onClick=onPay,enabled=editable,modifier=Modifier.fillMaxWidth().padding(horizontal=18.dp,vertical=2.dp).height(54.dp),shape=RoundedCornerShape(16.dp),colors=ButtonDefaults.buttonColors(Navy)){Icon(Icons.Default.Edit,null);Spacer(Modifier.width(8.dp));Text("Edit Pembayaran",fontWeight=FontWeight.ExtraBold,fontSize=16.sp)}}
        if(p!=null)item{Button(onClick={shareReceiptImage(context,p,s)},modifier=Modifier.fillMaxWidth().padding(horizontal=18.dp,vertical=7.dp).height(54.dp),shape=RoundedCornerShape(16.dp),colors=ButtonDefaults.buttonColors(Green)){Icon(Icons.Default.Share,null);Spacer(Modifier.width(8.dp));Text("Bagikan Kuitansi",fontWeight=FontWeight.ExtraBold,fontSize=16.sp)}}
        item{Text("Riwayat Pembayaran",fontSize=23.sp,fontWeight=FontWeight.ExtraBold,color=Navy,modifier=Modifier.padding(start=18.dp,top=12.dp,bottom=7.dp))}
        if(payments.isEmpty())item{EmptyFinanceCard("Belum ada transaksi.",Navy)}else items(payments.sortedByDescending{it.date}){pay->Card(Modifier.fillMaxWidth().padding(horizontal=18.dp,vertical=4.dp),shape=RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(Color.White),elevation=CardDefaults.cardElevation(1.dp)){Row(Modifier.padding(13.dp),verticalAlignment=Alignment.CenterVertically){Surface(color=SoftBlue,shape=CircleShape){Icon(Icons.Default.Schedule,null,tint=Navy,modifier=Modifier.padding(9.dp).size(22.dp))};Spacer(Modifier.width(10.dp));Column(Modifier.weight(1f)){Text(pay.date,fontWeight=FontWeight.ExtraBold,color=Navy,fontSize=16.sp);Text("${rupiah(pay.amount)} • ${pay.method}",fontSize=11.sp,color=Color.Gray)};Text(rupiah(pay.amount),fontWeight=FontWeight.ExtraBold,color=Green,fontSize=16.sp)}}}
    }
}

@Composable fun DetailLine(label:String,value:String,color:Color=Navy){Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Text(label,fontSize=13.sp,color=Color.Gray,modifier=Modifier.width(125.dp));Text(":",fontSize=13.sp,color=Color.Gray);Spacer(Modifier.width(8.dp));Text(value,fontSize=14.sp,fontWeight=FontWeight.Bold,color=color)}}
@OptIn(ExperimentalMaterial3Api::class)
@Composable fun StudentFormPage(context:Context,programs:List<Program>,existing:Student?,onBack:()->Unit,onSave:(Student)->Unit){
    var name by remember{mutableStateOf(existing?.name?:"")}
    var cls by remember{mutableStateOf(existing?.className?:"")}
    var phone by remember{mutableStateOf(existing?.parentPhone?:"")}
    var school by remember{mutableStateOf(existing?.schoolOrigin?:"")}
    var birthDate by remember{mutableStateOf(existing?.birthDate?:"")}
    var note by remember{mutableStateOf(existing?.note?:"")}
    var selectedProgram by remember{mutableStateOf(existing?.program?:programs.firstOrNull()?.name.orEmpty())}
    var fee by remember{mutableStateOf(existing?.monthlyFee?.toString()?:programs.firstOrNull()?.fee?.toString().orEmpty())}
    val ageText=calculateAge(birthDate)
    var avatarPath by remember{mutableStateOf(existing?.avatarPath?:"")}
    var avatarMenu by remember{mutableStateOf(false)}
    var avatarPicker by remember{mutableStateOf(false)}
    var programMenu by remember{mutableStateOf(false)}
    var cameraFile by remember{mutableStateOf<File?>(null)}
    val gallery=rememberLauncherForActivityResult(ActivityResultContracts.GetContent()){uri->
        if(uri!=null){
            val file=File(context.filesDir,"student_${System.currentTimeMillis()}.jpg")
            context.contentResolver.openInputStream(uri)?.use{input->file.outputStream().use{out->input.copyTo(out)}}
            avatarPath=file.absolutePath
        }
    }
    val camera=rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()){ok->if(ok)avatarPath=cameraFile?.absolutePath.orEmpty()}
    LazyColumn(Modifier.fillMaxSize().background(Color.White),contentPadding=PaddingValues(bottom=24.dp)){
        item{
            Column(Modifier.padding(18.dp)){
                Row(verticalAlignment=Alignment.CenterVertically){
                    IconButton(onClick=onBack){Icon(Icons.Default.ArrowBack,"Kembali",tint=Navy,modifier=Modifier.size(27.dp))}
                    Spacer(Modifier.width(4.dp))
                    Text(if(existing==null)"Tambah Siswa" else "Edit Siswa",fontSize=26.sp,fontWeight=FontWeight.ExtraBold,color=Navy)
                }
                Spacer(Modifier.height(8.dp))
                Box(Modifier.fillMaxWidth(),contentAlignment=Alignment.Center){
                    AvatarPreview(avatarPath)
                    IconButton(onClick={avatarMenu=true},modifier=Modifier.offset(x=34.dp,y=30.dp)){
                        Surface(color=Navy,shape=CircleShape){Icon(Icons.Default.CameraAlt,null,tint=Color.White,modifier=Modifier.padding(7.dp).size(18.dp))}
                    }
                    DropdownMenu(expanded=avatarMenu,onDismissRequest={avatarMenu=false}){
                        DropdownMenuItem(text={Text("Ambil dari kamera")},onClick={
                            avatarMenu=false
                            val f=File(context.cacheDir,"student_camera_${System.currentTimeMillis()}.jpg")
                            cameraFile=f
                            camera.launch(FileProvider.getUriForFile(context,"${context.packageName}.fileprovider",f))
                        })
                        DropdownMenuItem(text={Text("Pilih dari file ponsel")},onClick={avatarMenu=false;gallery.launch("image/*")})
                        DropdownMenuItem(text={Text("Pilih Avatar Siswa")},onClick={avatarMenu=false;avatarPicker=true})
                        DropdownMenuItem(text={Text("Avatar laki-laki")},onClick={avatarMenu=false;avatarPath="builtin_male"})
                        DropdownMenuItem(text={Text("Avatar perempuan")},onClick={avatarMenu=false;avatarPath="builtin_female"})
                    }
                }
                FormLabel("Nama Lengkap")
                OutlinedTextField(value=name,onValueChange={name=it},placeholder={Text("Masukkan nama siswa")},modifier=Modifier.fillMaxWidth(),singleLine=true,shape=RoundedCornerShape(14.dp))
                FormLabel("Kelas")
                OutlinedTextField(value=cls,onValueChange={cls=it},placeholder={Text("Contoh: Kelas 5")},modifier=Modifier.fillMaxWidth(),singleLine=true,shape=RoundedCornerShape(14.dp))
                FormLabel("Sekolah Asal")
                OutlinedTextField(value=school,onValueChange={school=it},placeholder={Text("Masukkan nama sekolah asal")},modifier=Modifier.fillMaxWidth(),singleLine=true,shape=RoundedCornerShape(14.dp))
                FormLabel("Tanggal Lahir")
                OutlinedTextField(value=birthDate,onValueChange={birthDate=it},placeholder={Text("dd/MM/yyyy")},leadingIcon={Icon(Icons.Default.CalendarMonth,null,tint=Navy)},modifier=Modifier.fillMaxWidth(),singleLine=true,shape=RoundedCornerShape(14.dp))
                FormLabel("Umur")
                OutlinedTextField(value=ageText,onValueChange={},readOnly=true,placeholder={Text("Otomatis dari tanggal lahir")},leadingIcon={Icon(Icons.Default.Cake,null,tint=Navy)},modifier=Modifier.fillMaxWidth(),singleLine=true,shape=RoundedCornerShape(14.dp))
                FormLabel("Program")
                ExposedDropdownMenuBox(expanded=programMenu,onExpandedChange={programMenu=!programMenu}){
                    OutlinedTextField(value=selectedProgram,onValueChange={},readOnly=true,placeholder={Text("Pilih program")},trailingIcon={ExposedDropdownMenuDefaults.TrailingIcon(expanded=programMenu)},modifier=Modifier.menuAnchor().fillMaxWidth(),singleLine=true,shape=RoundedCornerShape(14.dp))
                    ExposedDropdownMenu(expanded=programMenu,onDismissRequest={programMenu=false}){
                        programs.forEach{p->DropdownMenuItem(text={Text(p.name)},onClick={selectedProgram=p.name;fee=p.fee.toString();programMenu=false})}
                    }
                }
                FormLabel("Tarif per Bulan")
                OutlinedTextField(value=rupiah(fee.toLongOrNull()?:0L),onValueChange={},readOnly=true,modifier=Modifier.fillMaxWidth(),singleLine=true,shape=RoundedCornerShape(14.dp),leadingIcon={Text("Rp",fontWeight=FontWeight.Bold,color=Navy)})
                FormLabel("No. HP")
                OutlinedTextField(value=phone,onValueChange={phone=it.filter(Char::isDigit)},placeholder={Text("Masukkan nomor HP")},modifier=Modifier.fillMaxWidth(),singleLine=true,shape=RoundedCornerShape(14.dp))
                FormLabel("Catatan")
                OutlinedTextField(value=note,onValueChange={note=it},placeholder={Text("Catatan tambahan tentang siswa")},modifier=Modifier.fillMaxWidth().heightIn(min=90.dp),minLines=3,shape=RoundedCornerShape(14.dp))
                Spacer(Modifier.height(14.dp))
                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(10.dp)){
                    OutlinedButton(onClick=onBack,modifier=Modifier.weight(1f).height(50.dp),shape=RoundedCornerShape(14.dp)){Text("Batal",fontWeight=FontWeight.ExtraBold)}
                    Button(onClick={onSave(Student(id=existing?.id?:0L,name=name.trim(),className=cls.trim(),parentPhone=phone,program=selectedProgram,monthlyFee=fee.toLongOrNull()?:0L,birthDate=birthDate.trim(),schoolOrigin=school.trim(),note=note.trim(),active=existing?.active?:true,avatarPath=avatarPath))},enabled=name.isNotBlank()&&selectedProgram.isNotBlank()&&fee.toLongOrNull()?.let{it>0}==true,modifier=Modifier.weight(1f).height(50.dp),shape=RoundedCornerShape(14.dp),colors=ButtonDefaults.buttonColors(Navy)){Text("Simpan",fontWeight=FontWeight.ExtraBold)}
                }
            }
        }
    }
    if(avatarPicker)AvatarPickerDialog(avatarPath,{avatarPicker=false}){avatarPath=it}
}

@Composable fun AvatarPickerDialog(selected:String,onDismiss:()->Unit,onSelect:(String)->Unit){
    var gender by remember{mutableStateOf("Semua")}
    val all=(1..20).map{"builtin_avatar_$it"}
    val options=all.filter{key->val i=key.substringAfterLast('_').toIntOrNull()?:1;gender=="Semua"||(gender=="Laki-laki"&&i<=10)||(gender=="Perempuan"&&i>=11)}
    AlertDialog(onDismissRequest=onDismiss,containerColor=Color(0xFFF7FAFE),shape=RoundedCornerShape(28.dp),title={Text("Pilih Avatar Siswa",fontSize=21.sp,fontWeight=FontWeight.ExtraBold,color=Navy)},text={Column{Text("Pilih avatar anak yang paling sesuai.",fontSize=10.sp,color=Color.Gray);Spacer(Modifier.height(8.dp));Row(horizontalArrangement=Arrangement.spacedBy(7.dp)){listOf("Semua","Laki-laki","Perempuan").forEach{g->ModernFilter(g,gender==g){gender=g}}};Spacer(Modifier.height(10.dp));androidx.compose.foundation.lazy.grid.LazyVerticalGrid(columns=androidx.compose.foundation.lazy.grid.GridCells.Fixed(4),modifier=Modifier.height(260.dp),horizontalArrangement=Arrangement.spacedBy(8.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){items(options.size){i->val k=options[i];AvatarOption(k,selected==k){onSelect(k);onDismiss()}}}}},confirmButton={TextButton(onClick=onDismiss){Text("Batal",color=Navy,fontWeight=FontWeight.Bold)}})
}

@Composable fun AvatarOption(key:String,selected:Boolean,onClick:()->Unit){val idx=key.substringAfterLast('_').toIntOrNull()?:1;Box(Modifier.size(70.dp).clickable(onClick=onClick)){AvatarIllustration(idx);if(selected)Surface(color=Navy,shape=CircleShape,modifier=Modifier.align(Alignment.TopEnd).size(19.dp)){Icon(Icons.Default.Check,null,tint=Color.White,modifier=Modifier.padding(3.dp))}}}

fun calculateAge(raw:String):String{
    if(raw.isBlank()) return "-"
    val parsed=runCatching{SimpleDateFormat("dd/MM/yyyy",Locale("id","ID")).apply{isLenient=false}.parse(raw)}.getOrNull() ?: return "-"
    val dob=Calendar.getInstance().apply{time=parsed}
    val now=Calendar.getInstance()
    var years=now.get(Calendar.YEAR)-dob.get(Calendar.YEAR)
    if(now.get(Calendar.DAY_OF_YEAR)<dob.get(Calendar.DAY_OF_YEAR)) years--
    return if(years>=0) "$years tahun" else "-"
}

@Composable fun FormLabel(text:String){Text(text,fontSize=14.sp,fontWeight=FontWeight.ExtraBold,color=Navy,modifier=Modifier.padding(top=11.dp,bottom=5.dp))}
@Composable fun AvatarPreview(path:String){Avatar(Student(name="",className="",parentPhone="",program="",monthlyFee=0,avatarPath=path))}

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun StudentDialog(programs: List<Program>, existing: Student?, onDismiss: () -> Unit, onSave: (Student) -> Unit) {
    var name by remember { mutableStateOf(existing?.name ?: "") };var cls by remember { mutableStateOf(existing?.className ?: "") };var phone by remember { mutableStateOf(existing?.parentPhone ?: "") };var selectedProgram by remember { mutableStateOf(existing?.program ?: programs.firstOrNull()?.name.orEmpty()) };var fee by remember { mutableStateOf(existing?.monthlyFee?.toString() ?: programs.firstOrNull()?.fee?.toString().orEmpty()) };var programMenu by remember { mutableStateOf(false) }
    AlertDialog(onDismissRequest=onDismiss,containerColor=Color(0xFFF4F8FD),shape=RoundedCornerShape(30.dp),title={Column(Modifier.fillMaxWidth(),horizontalAlignment=Alignment.CenterHorizontally){Surface(color=SoftBlue,shape=CircleShape){Icon(if(existing==null)Icons.Default.PersonAdd else Icons.Default.Edit,null,tint=Navy,modifier=Modifier.padding(13.dp).size(28.dp))};Spacer(Modifier.height(8.dp));Text(if(existing==null)"Tambah Siswa" else "Edit Siswa",fontSize=23.sp,fontWeight=FontWeight.ExtraBold,color=Navy);Text("Lengkapi data siswa dengan benar",fontSize=10.sp,color=Color.Gray)}},text={Column(verticalArrangement=Arrangement.spacedBy(9.dp)){
        OutlinedTextField(name,{name=it},label={Text("Nama Lengkap")},leadingIcon={Icon(Icons.Default.Person,null)},singleLine=true,modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(16.dp),colors=OutlinedTextFieldDefaults.colors(focusedBorderColor=Navy,focusedLabelColor=Navy));OutlinedTextField(cls,{cls=it},label={Text("Kelas")},leadingIcon={Icon(Icons.Default.School,null)},singleLine=true,modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(16.dp));OutlinedTextField(phone,{phone=phone.filter(Char::isDigit)},label={Text("No. HP (opsional)")},leadingIcon={Icon(Icons.Default.Phone,null)},singleLine=true,modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(16.dp));ExposedDropdownMenuBox(expanded=programMenu,onExpandedChange={programMenu=!programMenu}){OutlinedTextField(value=selectedProgram,onValueChange={},readOnly=true,label={Text("Program")},leadingIcon={Icon(Icons.Default.Groups,null)},trailingIcon={ExposedDropdownMenuDefaults.TrailingIcon(expanded=programMenu)},modifier=Modifier.menuAnchor().fillMaxWidth(),singleLine=true,shape=RoundedCornerShape(16.dp));ExposedDropdownMenu(expanded=programMenu,onDismissRequest={programMenu=false}){programs.forEach{item->DropdownMenuItem(text={Text("${item.name}  •  ${rupiah(item.fee)}/bulan",fontWeight=FontWeight.SemiBold)},onClick={selectedProgram=item.name;fee=item.fee.toString();programMenu=false})}}};OutlinedTextField(rupiah(fee.toLongOrNull()?:0L),{},readOnly=true,label={Text("Tarif per Bulan")},leadingIcon={Icon(Icons.Default.Payments,null,tint=Green)},singleLine=true,modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(16.dp))
    }},confirmButton={Button(enabled=name.isNotBlank()&&selectedProgram.isNotBlank()&&fee.toLongOrNull()?.let{it>0}==true,onClick={onSave(Student(existing?.id?:0L,name.trim(),cls.trim(),phone,selectedProgram,fee.toLong()))},modifier=Modifier.height(47.dp),shape=RoundedCornerShape(15.dp),colors=ButtonDefaults.buttonColors(Navy)){Text("Simpan",fontWeight=FontWeight.ExtraBold)}},dismissButton={TextButton(onClick=onDismiss){Text("Batal",fontWeight=FontWeight.Bold,color=Navy)}})
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun PaymentDialog(s:Student,existing:Payment?,month:String,onDismiss:()->Unit,onSave:(Payment)->Unit){
    val context = androidx.compose.ui.platform.LocalContext.current
    val current=existing
    var amount by remember{mutableStateOf(current?.amount?.toString()?:(s.monthlyFee).toString())}
    var method by remember{mutableStateOf(current?.method?:"Tunai")}
    var date by remember{mutableStateOf(current?.date?:today())}
    var note by remember{mutableStateOf(current?.note?:"")}
    val paid=amount.toLongOrNull()?.coerceAtLeast(0L)?:0L
    val status=when{paid>=s.monthlyFee->"LUNAS";paid>0->"KURANG BAYAR";else->"BELUM BAYAR"}
    val accent=when(status){"LUNAS"->Green;"KURANG BAYAR"->Yellow;else->Red}
    val pc=programColors(s.program)
    AlertDialog(onDismissRequest=onDismiss,containerColor=Color(0xFFF5F9FE),shape=RoundedCornerShape(28.dp),
        title={Column(Modifier.fillMaxWidth()){Text("Ubah Status Pembayaran",fontSize=22.sp,fontWeight=FontWeight.ExtraBold,color=Navy);Spacer(Modifier.height(8.dp));Card(colors=CardDefaults.cardColors(Color.White),shape=RoundedCornerShape(20.dp)){Row(Modifier.padding(12.dp),verticalAlignment=Alignment.CenterVertically){Avatar(s);Spacer(Modifier.width(10.dp));Column(Modifier.weight(1f)){Text(s.name,fontWeight=FontWeight.ExtraBold,color=Navy,fontSize=18.sp);Text("${s.program} • ${s.className}",fontSize=10.sp,color=Color.Gray)}}}}},
        text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){
            Text("Status Pembayaran",fontWeight=FontWeight.ExtraBold,color=Navy,fontSize=13.sp)
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(6.dp)){
                StatusChoice("LUNAS",Green,status=="LUNAS"){amount=s.monthlyFee.toString()}
                StatusChoice("KURANG",Yellow,status=="KURANG BAYAR"){amount=(s.monthlyFee/2).coerceAtLeast(1L).toString()}
                StatusChoice("BELUM",Red,status=="BELUM BAYAR"){amount="0"}
            }
            Card(colors=CardDefaults.cardColors(Color.White),shape=RoundedCornerShape(17.dp)){Column(Modifier.padding(13.dp)){Text(month,fontWeight=FontWeight.ExtraBold,color=Navy,fontSize=16.sp);Spacer(Modifier.height(6.dp));FinanceTotalLine("Tagihan",s.monthlyFee,Navy);FinanceTotalLine("Sudah Dibayar",paid,Green);FinanceTotalLine("Sisa",(s.monthlyFee-paid).coerceAtLeast(0),if(paid>=s.monthlyFee)Green else Red)}}
            OutlinedTextField(amount,{amount=it.filter(Char::isDigit)},label={Text("Nominal Dibayar")},leadingIcon={Icon(Icons.Default.Payments,null)},singleLine=true,modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(15.dp))
            OutlinedTextField(method,{method=it},label={Text("Metode Pembayaran")},leadingIcon={Icon(Icons.Default.AccountBalanceWallet,null)},singleLine=true,modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(15.dp))
            OutlinedTextField(date,{date=it},label={Text("Tanggal Pembayaran")},leadingIcon={Icon(Icons.Default.DateRange,null)},singleLine=true,modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(15.dp))
            OutlinedTextField(note,{note=it},label={Text("Catatan (Opsional)")},leadingIcon={Icon(Icons.Default.Notes,null)},singleLine=true,modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(15.dp))
            if(current!=null && paid==0L) Text("Status BELUM BAYAR akan tersimpan tanpa nominal pembayaran.",fontSize=10.sp,color=Red,fontWeight=FontWeight.SemiBold)
            OutlinedButton(onClick={if(current!=null && paid>0L) shareReceiptImage(context,current,s)},enabled=current!=null && paid>0L,modifier=Modifier.fillMaxWidth().height(44.dp),shape=RoundedCornerShape(13.dp)){Icon(Icons.Default.Share,null,modifier=Modifier.size(17.dp));Spacer(Modifier.width(6.dp));Text("Bagikan Kuitansi",fontWeight=FontWeight.Bold)}
        }},
        confirmButton={Button(enabled=paid<=s.monthlyFee,onClick={val out=current?.copy(amount=paid,method=method,date=date,note=note)?:Payment(studentId=s.id,month=month,amount=paid,method=method,date=date,note=note,receiptNo="KUI/"+SimpleDateFormat("yyyy/MM",Locale.US).format(Date())+"/"+String.format(Locale.US,"%04d",(System.currentTimeMillis()%10000)));onSave(out)},modifier=Modifier.height(47.dp),shape=RoundedCornerShape(15.dp),colors=ButtonDefaults.buttonColors(Navy)){Text("Simpan Perubahan",fontWeight=FontWeight.ExtraBold)}},
        dismissButton={TextButton(onClick=onDismiss){Text("Batal",fontWeight=FontWeight.Bold,color=Navy)}})
}

@Composable fun RowScope.StatusChoice(label:String,color:Color,selected:Boolean,onClick:()->Unit){Surface(color=if(selected)color.copy(alpha=.16f) else Color.White,shape=RoundedCornerShape(12.dp),border=androidx.compose.foundation.BorderStroke(1.dp,if(selected)color else Color(0xFFE0E5EC)),modifier=Modifier.weight(1f).clickable(onClick=onClick)){Column(Modifier.padding(vertical=8.dp),horizontalAlignment=Alignment.CenterHorizontally){Icon(if(label=="LUNAS")Icons.Default.CheckCircle else if(label=="KURANG")Icons.Default.Schedule else Icons.Default.Cancel,null,tint=color,modifier=Modifier.size(22.dp));Text(label,fontSize=8.sp,fontWeight=FontWeight.ExtraBold,color=color)}}}

@Composable fun MetricMini(label:String,value:String,color:Color){Column(horizontalAlignment=Alignment.CenterHorizontally,modifier=Modifier.widthIn(min=70.dp)){Text(label,fontSize=8.sp,color=Color.Gray);Text(value,fontSize=11.sp,fontWeight=FontWeight.ExtraBold,color=color)}}


@Composable
fun PaymentReportRow(number:Int,s:Student,p:Payment?){
    val paid=p?.amount?:0L
    val status=when{paid>=s.monthlyFee->"LUNAS";paid>0->"KURANG";else->"BELUM"}
    Card(Modifier.fillMaxWidth().padding(horizontal=12.dp,vertical=3.dp),shape=RoundedCornerShape(15.dp),colors=CardDefaults.cardColors(programColors(s.program).bg)){
        ListItem(
            headlineContent={Text("$number. ${s.name}",fontWeight=FontWeight.Bold,color=Navy)},
            supportingContent={Text("${s.className} • ${s.program} • ${rupiah(paid)} / ${rupiah(s.monthlyFee)}")},
            trailingContent={StatusChip(status)}
        )
    }
}

@Composable fun ReportsScreen(students:List<Student>,programs:List<Program>,payments:List<Payment>,expenses:List<Expense>,incomes:List<Income>,vm:MainVm,month:String,onMonthChange:(String)->Unit){val mp=payments.filter{it.month.equals(month,true)};val me=expenses.filter{it.month.equals(month,true)};val mi=incomes.filter{it.month.equals(month,true)};val monthlyIncome=mp.sumOf{it.amount}+mi.sumOf{it.amount};val monthlyExpense=me.sumOf{it.amount};val net=monthlyIncome-monthlyExpense;val ctx=androidx.compose.ui.platform.LocalContext.current;var financeTab by remember{mutableStateOf("Pemasukan")};var showExpense by remember{mutableStateOf(false)};var showIncome by remember{mutableStateOf(false)};var addExpense by remember{mutableStateOf(false)};var addIncome by remember{mutableStateOf(false)};var editExpense by remember{mutableStateOf<Expense?>(null)};var editIncome by remember{mutableStateOf<Income?>(null)};var deleteExpense by remember{mutableStateOf<Expense?>(null)};var deleteIncome by remember{mutableStateOf<Income?>(null)};LazyColumn(Modifier.fillMaxSize().background(Bg),contentPadding=PaddingValues(bottom=20.dp)){item{Box(Modifier.fillMaxWidth().height(250.dp).clip(RoundedCornerShape(bottomStart=30.dp,bottomEnd=30.dp))){Image(painterResource(R.drawable.final_laporan_header),"Background Laporan",Modifier.fillMaxSize(),contentScale=androidx.compose.ui.layout.ContentScale.FillBounds);}};item{Card(Modifier.fillMaxWidth().padding(horizontal=18.dp,vertical=9.dp),shape=RoundedCornerShape(27.dp),colors=CardDefaults.cardColors(Navy),elevation=CardDefaults.cardElevation(5.dp)){Column(Modifier.padding(18.dp)){Row(verticalAlignment=Alignment.CenterVertically){Surface(color=Color.White.copy(alpha=.15f),shape=CircleShape){Icon(Icons.Default.BarChart,null,tint=Color.White,modifier=Modifier.padding(10.dp))};Spacer(Modifier.width(9.dp));Column(Modifier.weight(1f)){Text("LAPORAN KEUANGAN",color=Color.White.copy(alpha=.75f),fontSize=9.sp,fontWeight=FontWeight.ExtraBold);Text(month,color=Color.White,fontSize=23.sp,fontWeight=FontWeight.ExtraBold)};Surface(color=Color.White.copy(alpha=.14f),shape=CircleShape){Icon(Icons.Default.CalendarMonth,null,tint=Color.White,modifier=Modifier.padding(9.dp))}};Spacer(Modifier.height(9.dp));Text("Laba Bersih",color=Color.White.copy(alpha=.75f),fontSize=11.sp);Text(rupiah(net),color=Color.White,fontSize=31.sp,fontWeight=FontWeight.ExtraBold);Spacer(Modifier.height(10.dp));Row(horizontalArrangement=Arrangement.spacedBy(8.dp),modifier=Modifier.fillMaxWidth()){ReportMini("Pemasukan",rupiah(monthlyIncome),Green,Modifier.weight(1f));ReportMini("Pengeluaran",rupiah(monthlyExpense),Red,Modifier.weight(1f))}}}};item{MonthPill(month,onMonthChange)};item{Card(Modifier.fillMaxWidth().padding(horizontal=18.dp,vertical=4.dp),shape=RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(Color.White),elevation=CardDefaults.cardElevation(2.dp)){Row(Modifier.padding(5.dp),horizontalArrangement=Arrangement.spacedBy(6.dp)){ReportTab("Pemasukan",financeTab=="Pemasukan",Green){financeTab="Pemasukan"};ReportTab("Pengeluaran",financeTab=="Pengeluaran",Red){financeTab="Pengeluaran"}}}};item{Row(Modifier.fillMaxWidth().padding(horizontal=18.dp,vertical=9.dp),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(if(financeTab=="Pemasukan")"Daftar Pemasukan" else "Daftar Pengeluaran",fontSize=21.sp,fontWeight=FontWeight.ExtraBold,color=Navy);Text("Transaksi bulan $month",fontSize=10.sp,color=Color.Gray)};Button(onClick={if(financeTab=="Pemasukan")addIncome=true else addExpense=true},shape=RoundedCornerShape(14.dp),colors=ButtonDefaults.buttonColors(if(financeTab=="Pemasukan")Green else Red)){Icon(Icons.Default.Add,null);Spacer(Modifier.width(4.dp));Text("Tambah",fontWeight=FontWeight.ExtraBold)}}};if(financeTab=="Pemasukan"){mp.sortedByDescending{it.date}.forEach{p->students.firstOrNull{s->s.id==p.studentId}?.let{st->item{FinanceTransactionCard("Pembayaran Siswa",p.date,"${st.name} • ${st.program}",p.amount,Green,Icons.Default.AccountBalanceWallet){}}};mi.sortedByDescending{it.date}.forEach{i->item{FinanceTransactionCard(i.title,i.date,i.category,i.amount,Green,Icons.Default.TrendingUp){showIncome=true}}}}}else{me.sortedByDescending{it.date}.forEach{e->item{FinanceTransactionCard(e.title,e.date,e.category,e.amount,Red,Icons.Default.TrendingDown){showExpense=true}}}};item{Card(Modifier.fillMaxWidth().padding(18.dp),shape=RoundedCornerShape(20.dp),colors=CardDefaults.cardColors(Color.White),elevation=CardDefaults.cardElevation(2.dp)){Column(Modifier.padding(15.dp),verticalArrangement=Arrangement.spacedBy(7.dp)){FinanceTotalLine("Total Pemasukan",monthlyIncome,Green);FinanceTotalLine("Total Pengeluaran",monthlyExpense,Red);HorizontalDivider();FinanceTotalLine("Laba Bersih",net,Navy)}}};item{Button(onClick={savePdfWithChooser(ctx,"laporan_keuangan_${month.replace(" ","_")}.pdf"){createFinanceReportPdf(ctx,month,mp,me,mi,monthlyIncome,monthlyExpense)}},modifier=Modifier.fillMaxWidth().padding(horizontal=18.dp).height(49.dp),shape=RoundedCornerShape(15.dp),colors=ButtonDefaults.buttonColors(Navy)){Icon(Icons.Default.PictureAsPdf,null);Spacer(Modifier.width(7.dp));Text("Buat & Bagikan Laporan PDF",fontWeight=FontWeight.Bold)}}};if(showExpense)ExpenseListDialog(me,month,{showExpense=false},{addExpense=true},{editExpense=it},{deleteExpense=it});if(showIncome)IncomeListDialog(mi,month,{showIncome=false},{addIncome=true},{editIncome=it},{deleteIncome=it});if(addExpense)ExpenseDialog(onDismiss={addExpense=false}){title,category,amount,note->vm.addExpense(Expense(month=month,date=today(),title=title,category=category,amount=amount,note=note));addExpense=false};if(addIncome)IncomeDialog(onDismiss={addIncome=false}){title,category,amount,note->vm.addIncome(Income(month=month,date=today(),title=title,category=category,amount=amount,note=note));addIncome=false};editExpense?.let{e->ExpenseEditDialog(e,{editExpense=null}){u->vm.updateExpense(u);editExpense=null}};editIncome?.let{i->IncomeEditDialog(i,{editIncome=null}){u->vm.updateIncome(u);editIncome=null}};deleteExpense?.let{e->DeleteConfirmDialog("pengeluaran",e.title,{deleteExpense=null}){vm.deleteExpense(e);deleteExpense=null}};deleteIncome?.let{i->DeleteConfirmDialog("pemasukan",i.title,{deleteIncome=null}){vm.deleteIncome(i);deleteIncome=null}}}
@Composable fun ReportMini(label:String,value:String,accent:Color,modifier:Modifier){Surface(color=Color.White,shape=RoundedCornerShape(17.dp),modifier=modifier){Column(Modifier.padding(11.dp)){Text(label,fontSize=9.sp,color=Color.Gray);Text(value,fontWeight=FontWeight.ExtraBold,fontSize=16.sp,color=accent)}}}
@Composable fun RowScope.ReportTab(label:String,selected:Boolean,color:Color,onClick:()->Unit){Surface(color=if(selected)color else Color.Transparent,shape=RoundedCornerShape(13.dp),modifier=Modifier.weight(1f).clickable(onClick=onClick)){Row(Modifier.padding(vertical=11.dp),horizontalArrangement=Arrangement.Center,verticalAlignment=Alignment.CenterVertically){Icon(if(label=="Pemasukan")Icons.Default.ArrowDownward else Icons.Default.ArrowUpward,null,tint=if(selected)Color.White else Color.Gray,modifier=Modifier.size(17.dp));Spacer(Modifier.width(5.dp));Text(label,fontWeight=FontWeight.ExtraBold,color=if(selected)Color.White else Color.DarkGray)}}}

@Composable fun EmptyFinanceCard(text:String,color:Color){Card(Modifier.fillMaxWidth().padding(horizontal=14.dp,vertical=5.dp),shape=RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(Color.White),elevation=CardDefaults.cardElevation(1.dp)){Row(Modifier.padding(18.dp),verticalAlignment=Alignment.CenterVertically){Surface(color=color.copy(alpha=.12f),shape=CircleShape){Icon(Icons.Default.Info,null,tint=color,modifier=Modifier.padding(9.dp))};Spacer(Modifier.width(10.dp));Text(text,color=Color.Gray,fontSize=11.sp)}}}
@Composable fun FinanceTransactionCard(title:String,date:String,subtitle:String,amount:Long,color:Color,icon:ImageVector,onClick:()->Unit){Card(Modifier.fillMaxWidth().padding(horizontal=14.dp,vertical=4.dp).clickable(onClick=onClick),shape=RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(Color.White),elevation=CardDefaults.cardElevation(1.dp)){Row(Modifier.padding(13.dp),verticalAlignment=Alignment.CenterVertically){Surface(color=color.copy(alpha=.12f),shape=CircleShape){Icon(icon,null,tint=color,modifier=Modifier.padding(9.dp).size(20.dp))};Spacer(Modifier.width(10.dp));Column(Modifier.weight(1f)){Text(title,fontWeight=FontWeight.Bold,color=Navy,fontSize=13.sp);Text(subtitle,fontSize=10.sp,color=Color.Gray);Text(date,fontSize=9.sp,color=Color.Gray)};Text(rupiah(amount),fontWeight=FontWeight.ExtraBold,color=color,fontSize=13.sp)}}}
@Composable fun FinanceTotalLine(label:String,value:Long,color:Color){Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text(label,fontSize=11.sp,color=Color.Gray,fontWeight=FontWeight.SemiBold);Text(rupiah(value),fontSize=13.sp,color=color,fontWeight=FontWeight.ExtraBold)}}

@Composable fun ExpenseListDialog(items:List<Expense>,month:String,onDismiss:()->Unit,onAdd:()->Unit,onEdit:(Expense)->Unit,onDelete:(Expense)->Unit){
    AlertDialog(onDismissRequest=onDismiss,title={Text("Pengeluaran $month",fontWeight=FontWeight.Bold,color=Navy)},text={
        LazyColumn{if(items.isEmpty())item{Text("Belum ada pengeluaran bulan ini.")};items(items){e->
            ListItem(headlineContent={Text(e.title,fontWeight=FontWeight.Bold)},supportingContent={Text("${e.date} • ${e.category}${if(e.note.isNotBlank())"\\n${e.note}" else ""}",fontSize=11.sp)},trailingContent={
                Column(horizontalAlignment=Alignment.End){Text(rupiah(e.amount),fontWeight=FontWeight.Bold,color=Red);Row{IconButton(onClick={onEdit(e)}){Icon(Icons.Default.Edit,"Edit pengeluaran",tint=Navy)};IconButton(onClick={onDelete(e)}){Icon(Icons.Default.Delete,"Hapus pengeluaran",tint=Red)}}}
            })
        }}
    },confirmButton={Button(onClick={onAdd();onDismiss()},colors=ButtonDefaults.buttonColors(Navy)){Text("+ Tambah Pengeluaran")}},dismissButton={TextButton(onClick=onDismiss){Text("Tutup")}})
}

@Composable fun IncomeListDialog(items:List<Income>,month:String,onDismiss:()->Unit,onAdd:()->Unit,onEdit:(Income)->Unit,onDelete:(Income)->Unit){
    AlertDialog(onDismissRequest=onDismiss,title={Text("Pemasukan $month",fontWeight=FontWeight.Bold,color=Navy)},text={
        LazyColumn{if(items.isEmpty())item{Text("Belum ada pemasukan tambahan bulan ini.")};items(items){i->
            ListItem(headlineContent={Text(i.title,fontWeight=FontWeight.Bold)},supportingContent={Text("${i.date} • ${i.category}${if(i.note.isNotBlank())"\\n${i.note}" else ""}",fontSize=11.sp)},trailingContent={
                Column(horizontalAlignment=Alignment.End){Text(rupiah(i.amount),fontWeight=FontWeight.Bold,color=Green);Row{IconButton(onClick={onEdit(i)}){Icon(Icons.Default.Edit,"Edit pemasukan",tint=Navy)};IconButton(onClick={onDelete(i)}){Icon(Icons.Default.Delete,"Hapus pemasukan",tint=Red)}}}
            })
        }}
    },confirmButton={Button(onClick={onAdd();onDismiss()},colors=ButtonDefaults.buttonColors(Navy)){Text("+ Tambah Pemasukan")}},dismissButton={TextButton(onClick=onDismiss){Text("Tutup")}})
}

@Composable fun ExpenseEditDialog(item:Expense,onDismiss:()->Unit,onSave:(Expense)->Unit){var title by remember{mutableStateOf(item.title)};var cat by remember{mutableStateOf(item.category)};var date by remember{mutableStateOf(item.date)};var amount by remember{mutableStateOf(item.amount.toString())};var note by remember{mutableStateOf(item.note)};AlertDialog(onDismissRequest=onDismiss,title={Text("Edit Pengeluaran",fontWeight=FontWeight.Bold,color=Navy)},text={Column(verticalArrangement=Arrangement.spacedBy(7.dp)){OutlinedTextField(title,{title=it},label={Text("Nama pengeluaran")},singleLine=true);OutlinedTextField(cat,{cat=it},label={Text("Kategori")},singleLine=true);OutlinedTextField(date,{date=it},label={Text("Tanggal")},singleLine=true);OutlinedTextField(amount,{amount=it.filter(Char::isDigit)},label={Text("Jumlah")},singleLine=true);OutlinedTextField(note,{note=it},label={Text("Keterangan")},singleLine=true)}},confirmButton={Button(enabled=title.isNotBlank()&&amount.toLongOrNull()?.let{it>0}==true,onClick={onSave(item.copy(date=date,title=title,category=cat,amount=amount.toLong(),note=note))},colors=ButtonDefaults.buttonColors(Navy)){Text("Simpan")}},dismissButton={TextButton(onClick=onDismiss){Text("Batal")}})}
@Composable fun IncomeEditDialog(item:Income,onDismiss:()->Unit,onSave:(Income)->Unit){var title by remember{mutableStateOf(item.title)};var cat by remember{mutableStateOf(item.category)};var date by remember{mutableStateOf(item.date)};var amount by remember{mutableStateOf(item.amount.toString())};var note by remember{mutableStateOf(item.note)};AlertDialog(onDismissRequest=onDismiss,title={Text("Edit Pemasukan",fontWeight=FontWeight.Bold,color=Navy)},text={Column(verticalArrangement=Arrangement.spacedBy(7.dp)){OutlinedTextField(title,{title=it},label={Text("Sumber pemasukan")},singleLine=true);OutlinedTextField(cat,{cat=it},label={Text("Kategori")},singleLine=true);OutlinedTextField(date,{date=it},label={Text("Tanggal")},singleLine=true);OutlinedTextField(amount,{amount=it.filter(Char::isDigit)},label={Text("Jumlah")},singleLine=true);OutlinedTextField(note,{note=it},label={Text("Keterangan")},singleLine=true)}},confirmButton={Button(enabled=title.isNotBlank()&&amount.toLongOrNull()?.let{it>0}==true,onClick={onSave(item.copy(date=date,title=title,category=cat,amount=amount.toLong(),note=note))},colors=ButtonDefaults.buttonColors(Navy)){Text("Simpan")}},dismissButton={TextButton(onClick=onDismiss){Text("Batal")}})}
@Composable fun DeleteConfirmDialog(type:String,name:String,onDismiss:()->Unit,onConfirm:()->Unit){AlertDialog(onDismissRequest=onDismiss,title={Text("Hapus $type?",fontWeight=FontWeight.Bold,color=Navy)},text={Text("Data \"$name\" akan dihapus dan tidak dapat dikembalikan.")},confirmButton={Button(onClick=onConfirm,colors=ButtonDefaults.buttonColors(Red)){Text("Hapus")}},dismissButton={TextButton(onClick=onDismiss){Text("Batal")}})}

@Composable fun ExpenseDialog(onDismiss:()->Unit,onSave:(String,String,Long,String)->Unit){var title by remember{mutableStateOf("")};var cat by remember{mutableStateOf("Operasional")};var amount by remember{mutableStateOf("")};var note by remember{mutableStateOf("")};AlertDialog(onDismissRequest=onDismiss,title={Text("Tambah Pengeluaran",fontWeight=FontWeight.Bold,color=Navy)},text={Column(verticalArrangement=Arrangement.spacedBy(7.dp)){OutlinedTextField(title,{title=it},label={Text("Nama pengeluaran")},singleLine=true);OutlinedTextField(cat,{cat=it},label={Text("Kategori")},singleLine=true);OutlinedTextField(amount,{amount=it.filter(Char::isDigit)},label={Text("Jumlah")},singleLine=true);OutlinedTextField(note,{note=it},label={Text("Keterangan")},singleLine=true)}},confirmButton={Button(enabled=title.isNotBlank()&&amount.toLongOrNull()?.let{it>0}==true,onClick={onSave(title,cat,amount.toLong(),note)},colors=ButtonDefaults.buttonColors(Navy)){Text("Simpan")}},dismissButton={TextButton(onClick=onDismiss){Text("Batal")}})}
@Composable fun IncomeDialog(onDismiss:()->Unit,onSave:(String,String,Long,String)->Unit){var title by remember{mutableStateOf("")};var cat by remember{mutableStateOf("Lainnya")};var amount by remember{mutableStateOf("")};var note by remember{mutableStateOf("")};AlertDialog(onDismissRequest=onDismiss,title={Text("Tambah Pemasukan",fontWeight=FontWeight.Bold,color=Navy)},text={Column(verticalArrangement=Arrangement.spacedBy(7.dp)){OutlinedTextField(title,{title=it},label={Text("Sumber pemasukan")},singleLine=true);OutlinedTextField(cat,{cat=it},label={Text("Kategori")},singleLine=true);OutlinedTextField(amount,{amount=it.filter(Char::isDigit)},label={Text("Jumlah")},singleLine=true);OutlinedTextField(note,{note=it},label={Text("Keterangan")},singleLine=true)}},confirmButton={Button(enabled=title.isNotBlank()&&amount.toLongOrNull()?.let{it>0}==true,onClick={onSave(title,cat,amount.toLong(),note)},colors=ButtonDefaults.buttonColors(Navy)){Text("Simpan")}},dismissButton={TextButton(onClick=onDismiss){Text("Batal")}})}
@OptIn(ExperimentalMaterial3Api::class)
@Composable fun ProgramFormPage(onBack:()->Unit,onSave:(String,Long,String)->Unit){var name by remember{mutableStateOf("")};var fee by remember{mutableStateOf("")};var icon by remember{mutableStateOf("school")};val icons=listOf("school","abc","menu","language","math","science","ips","palette","music","computer","sports","world","library","brain","groups","writing","robotik","creative","keagamaan","star");LazyColumn(Modifier.fillMaxSize().background(Bg),contentPadding=PaddingValues(bottom=28.dp)){item{Column(Modifier.padding(18.dp)){Text("Tambah Program",fontSize=28.sp,fontWeight=FontWeight.ExtraBold,color=Navy);Text("Buat program baru dengan ikon dan tarif yang sesuai.",fontSize=11.sp,color=Color.Gray);Spacer(Modifier.height(14.dp));Card(Modifier.fillMaxWidth(),shape=RoundedCornerShape(25.dp),colors=CardDefaults.cardColors(Color.White),elevation=CardDefaults.cardElevation(2.dp)){Column(Modifier.padding(16.dp)){Text("Ikon Program",fontSize=16.sp,fontWeight=FontWeight.ExtraBold,color=Navy);Text("Pilih ikon modern untuk membedakan program.",fontSize=10.sp,color=Color.Gray);Spacer(Modifier.height(12.dp));androidx.compose.foundation.lazy.grid.LazyVerticalGrid(columns=androidx.compose.foundation.lazy.grid.GridCells.Fixed(5),modifier=Modifier.height(250.dp),horizontalArrangement=Arrangement.spacedBy(8.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){items(icons.size){i->val k=icons[i];val c=programColors(name.ifBlank{k});Surface(color=if(icon==k)c.iconBg else SoftBlue,shape=CircleShape,border=if(icon==k)androidx.compose.foundation.BorderStroke(2.dp,Navy) else null,modifier=Modifier.size(54.dp).clickable{icon=k}){Box(contentAlignment=Alignment.Center){ProgramIcon3D(k,"Ikon",Modifier.size(44.dp))}}}};Spacer(Modifier.height(14.dp));FormLabel("Nama Program");OutlinedTextField(name,{name=it},placeholder={Text("Contoh: Matematika, English, Seni...")},modifier=Modifier.fillMaxWidth(),singleLine=true,shape=RoundedCornerShape(16.dp));FormLabel("Tarif Program / Bulan");OutlinedTextField(fee,{fee=it.filter(Char::isDigit)},placeholder={Text("150000")},leadingIcon={Text("Rp",fontWeight=FontWeight.ExtraBold,color=Navy)},modifier=Modifier.fillMaxWidth(),singleLine=true,shape=RoundedCornerShape(16.dp));if(fee.isNotBlank())Text("${rupiah(fee.toLongOrNull()?:0L)} / bulan",fontSize=10.sp,color=Green,fontWeight=FontWeight.Bold);Spacer(Modifier.height(15.dp));Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(9.dp)){OutlinedButton(onClick=onBack,modifier=Modifier.weight(1f).height(50.dp),shape=RoundedCornerShape(15.dp)){Text("Batal",fontWeight=FontWeight.ExtraBold)};Button(enabled=name.isNotBlank()&&fee.toLongOrNull()?.let{it>0}==true,onClick={onSave(name.trim(),fee.toLong(),icon)},modifier=Modifier.weight(1f).height(50.dp),shape=RoundedCornerShape(15.dp),colors=ButtonDefaults.buttonColors(Navy)){Icon(Icons.Default.Save,null);Spacer(Modifier.width(5.dp));Text("Simpan",fontWeight=FontWeight.ExtraBold)}}}}}}}}

@Composable fun ProgramDialog(onDismiss:()->Unit,onSave:(String,Long,String)->Unit){var n by remember{mutableStateOf("")};var f by remember{mutableStateOf("")};var icon by remember{mutableStateOf("school")};AlertDialog(onDismissRequest=onDismiss,containerColor=Color(0xFFF7FAFE),shape=RoundedCornerShape(28.dp),title={Text("Tambah Program",fontSize=23.sp,fontWeight=FontWeight.ExtraBold,color=Navy)},text={Column(verticalArrangement=Arrangement.spacedBy(9.dp)){Text("Pilih Icon",fontSize=13.sp,fontWeight=FontWeight.ExtraBold,color=Navy);LazyRow(horizontalArrangement=Arrangement.spacedBy(8.dp)){items(listOf("school","groups","menu","language","computer")){k->Surface(color=if(icon==k)SoftBlue else Color.White,shape=CircleShape,modifier=Modifier.size(52.dp).clickable{icon=k}){Box(contentAlignment=Alignment.Center){Icon(programIcon(k),null,tint=Navy,modifier=Modifier.size(27.dp))}}}};OutlinedTextField(n,{n=it},label={Text("Nama program")},singleLine=true,modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(14.dp));OutlinedTextField(f,{f=it.filter(Char::isDigit)},label={Text("Tarif per bulan")},singleLine=true,modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(14.dp),leadingIcon={Text("Rp",fontWeight=FontWeight.Bold,color=Navy)})}},confirmButton={Button(enabled=n.isNotBlank()&&f.toLongOrNull()?.let{it>0}==true,onClick={onSave(n.trim(),f.toLong(),icon)},colors=ButtonDefaults.buttonColors(Navy),shape=RoundedCornerShape(14.dp)){Text("Simpan",fontWeight=FontWeight.ExtraBold)}},dismissButton={TextButton(onClick=onDismiss){Text("Batal",fontWeight=FontWeight.Bold,color=Navy)}})}

fun pdfFile(context:Context,name:String,draw:(PdfDocument.Page,Paint)->Unit):File{val doc=PdfDocument();val info=PdfDocument.PageInfo.Builder(595,842,1).create();val page=doc.startPage(info);val paint=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=android.graphics.Color.rgb(25,54,104);textSize=16f};draw(page,paint);doc.finishPage(page);val file=File(context.cacheDir,name);file.outputStream().use{doc.writeTo(it)};doc.close();return file}
fun drawLines(page:PdfDocument.Page,paint:Paint,lines:List<String>){var y=55f;for(line in lines){page.canvas.drawText(line.take(90),40f,y,paint);y+=24f;if(y>805f)break}}
fun createReceiptImage(context: Context, p: Payment, s: Student): File {
    // The user-approved receipt artwork is the fixed visual master.
    // Only transaction data is rendered dynamically over its sample fields.
    val receiptNo = p.receiptNo.ifBlank {
        "KUI/${SimpleDateFormat("yyyy/MM", Locale.US).format(Date())}/${p.id.toString().padStart(4, '0')}"
    }
    val safeReceiptNo = receiptNo.replace(Regex("[^A-Za-z0-9._-]"), "_")
    val cacheKey = "${safeReceiptNo}_${p.studentId}_${p.amount}_${p.date.hashCode()}_${p.month.hashCode()}"
    val file = File(context.cacheDir, "kuitansi_$cacheKey.png")
    if (file.exists() && file.length() > 0L) return file

    val decoded = BitmapFactory.decodeResource(context.resources, R.drawable.final_kuitansi_template)
        ?: throw IllegalStateException("Template kuitansi tidak tersedia")
    val bitmap = decoded.copy(Bitmap.Config.ARGB_8888, true)
        ?: throw IllegalStateException("Template kuitansi tidak dapat diproses")
    if (bitmap !== decoded) decoded.recycle()
    val canvas = Canvas(bitmap)
    val navy = android.graphics.Color.rgb(15, 67, 130)
    val green = android.graphics.Color.rgb(22, 163, 105)
    val white = android.graphics.Color.WHITE
    val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    val dateLong = runCatching {
        val candidates = listOf("dd/MM/yyyy", "yyyy-MM-dd", "dd-MM-yyyy")
        candidates.firstNotNullOfOrNull { pattern ->
            runCatching { SimpleDateFormat(pattern, Locale("id", "ID")).parse(p.date) }.getOrNull()
        }?.let { SimpleDateFormat("dd MMMM yyyy", Locale("id", "ID")).format(it) } ?: p.date
    }.getOrElse { p.date }

    fun cover(l:Float,t:Float,r:Float,b:Float,color:Int=white){
        paint.style=Paint.Style.FILL; paint.color=color; paint.alpha=245
        canvas.drawRect(l,t,r,b,paint); paint.alpha=255
    }
    fun text(value:String,x:Float,y:Float,size:Float,color:Int=navy,bold:Boolean=true){
        paint.style=Paint.Style.FILL; paint.color=color; paint.textSize=size
        paint.typeface=Typeface.create(Typeface.DEFAULT,if(bold)Typeface.BOLD else Typeface.NORMAL)
        canvas.drawText(value,x,y,paint)
    }

    // Dynamic receipt number and payment date in the fixed top-right receipt box.
    cover(728f,438f,1000f,548f)
    text("No. : $receiptNo",742f,482f,17f)
    text("Tanggal : $dateLong",742f,525f,16f,navy,false)

    // These six values always come from the selected payment + its student.
    val rows = listOf(
        s.name to navy,
        s.program to navy,
        p.month to navy,
        rupiah(s.monthlyFee) to navy,
        rupiah(p.amount) to navy,
        rupiah((s.monthlyFee-p.amount).coerceAtLeast(0L)) to green
    )
    val ys=floatArrayOf(628f,704f,781f,856f,930f,1005f)
    rows.forEachIndexed{index,(value,color)->
        cover(338f,ys[index]-42f,600f,ys[index]+12f)
        text(value.take(28),350f,ys[index],22f,color,true)
    }

    // Preserve the fixed artwork/status panel; only change the status text when not fully paid.
    if(p.amount < s.monthlyFee){
        cover(635f,720f,995f,900f,android.graphics.Color.rgb(238,249,242))
        val status=if(p.amount>0L)"KURANG BAYAR" else "BELUM BAYAR"
        text(status,690f,805f,38f,if(p.amount>0L)android.graphics.Color.rgb(190,130,0) else android.graphics.Color.rgb(220,46,65),true)
    }

    // Dynamic location/date line in the fixed bottom-right position.
    cover(610f,1000f,1000f,1050f)
    text("Pangkalan Kerinci, $dateLong",625f,1030f,18f,navy,false)

    file.outputStream().use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
    bitmap.recycle()
    return file
}

fun shareReceiptImage(context: Context, p: Payment, s: Student) {
    // Generate/cache the PNG off the UI thread so the Share button responds immediately.
    Toast.makeText(context, "Menyiapkan kuitansi…", Toast.LENGTH_SHORT).show()
    Thread {
        try {
            val file = createReceiptImage(context, p, s)
            val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
            val send = Intent(Intent.ACTION_SEND).apply {
                type = "image/png"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_TEXT, "Kuitansi pembayaran ${s.name} - ${p.month}")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                clipData = android.content.ClipData.newRawUri("Kuitansi pembayaran", uri)
            }
            Handler(Looper.getMainLooper()).post {
                runCatching { context.startActivity(Intent.createChooser(send, "Bagikan kuitansi")) }
                    .onFailure { Toast.makeText(context, "Kuitansi gagal dibagikan. Coba lagi.", Toast.LENGTH_SHORT).show() }
            }
        } catch (_:Throwable) {
            Handler(Looper.getMainLooper()).post {
                Toast.makeText(context, "Kuitansi gagal dibuat. Coba lagi.", Toast.LENGTH_SHORT).show()
            }
        }
    }.start()
}

fun createReportPdf(context:Context,month:String,program:String,status:String,list:List<Student>,payments:List<Payment>,income:Long,expense:Long):File {
    return pdfFile(context, "laporan_${month.replace(" ", "_")}.pdf", { page, paint ->
        paint.typeface=Typeface.DEFAULT_BOLD
        paint.textSize=22f
        page.canvas.drawText("LAPORAN PEMBAYARAN",40f,55f,paint)
        paint.typeface=Typeface.DEFAULT
        paint.textSize=13f
        drawLines(page,paint,listOf(
            "Bimbel Smart Kreatif Cemerlang",
            "Periode : $month",
            "Program : $program",
            "Status  : $status",
            "",
            "Total siswa : ${list.size}",
            "Pemasukan  : ${rupiah(income)}",
            "Pengeluaran: ${rupiah(expense)}",
            "Bersih     : ${rupiah(income-expense)}",
            "",
            "RINCIAN SISWA"
        ))
        var y=310f
        for ((i,s) in list.withIndex()) {
            val paid=payments.firstOrNull { it.studentId==s.id && it.month.equals(month,true) }?.amount ?: 0
            page.canvas.drawText("${i+1}. ${s.name} | ${s.program} | Tagihan ${rupiah(s.monthlyFee)} | Bayar ${rupiah(paid)}",40f,y,paint)
            y+=20f
            if(y>815f) break
        }
    })
}
fun createFinanceReportPdf(context:Context,month:String,mp:List<Payment>,me:List<Expense>,mi:List<Income>,income:Long,expense:Long):File{
    val file=File(context.cacheDir,"laporan_keuangan_${month.replace(" ","_")}.pdf")
    val doc=PdfDocument()
    val navy=android.graphics.Color.rgb(18,77,134);val green=android.graphics.Color.rgb(24,166,106);val red=android.graphics.Color.rgb(216,58,82);val blue=android.graphics.Color.rgb(14,102,183);val bg=android.graphics.Color.rgb(243,247,252);val softGreen=android.graphics.Color.rgb(229,248,240);val softRed=android.graphics.Color.rgb(255,236,236);val softBlue=android.graphics.Color.rgb(231,242,252);val line=android.graphics.Color.rgb(218,229,239);val dark=android.graphics.Color.rgb(35,55,75);val gray=android.graphics.Color.rgb(100,115,130)
    fun paint(size:Float,color:Int,bold:Boolean=false)=Paint(Paint.ANTI_ALIAS_FLAG).apply{this.textSize=size;this.color=color;this.typeface=Typeface.create(Typeface.DEFAULT,if(bold)Typeface.BOLD else Typeface.NORMAL)}
    fun round(c:Canvas,l:Float,t:Float,r:Float,b:Float,color:Int){val p=Paint(Paint.ANTI_ALIAS_FLAG);p.color=color;c.drawRoundRect(l,t,r,b,22f,22f,p)}
    fun header(c:Canvas,pageNo:Int){c.drawColor(bg);val logo=BitmapFactory.decodeResource(context.resources,context.resources.getIdentifier("logo_bimbel","drawable",context.packageName));if(logo!=null)c.drawBitmap(logo,null,android.graphics.RectF(36f,28f,100f,92f),Paint(Paint.ANTI_ALIAS_FLAG));c.drawText("BIMBEL SMART KREATIF CEMERLANG",125f,53f,paint(23f,navy,true));c.drawText("Belajar Hari Ini, Masa Depan Lebih Baik",125f,79f,paint(12f,gray));c.drawText("LAPORAN KEUANGAN",410f,48f,paint(11f,blue,true));c.drawText(month,410f,69f,paint(11f,gray));c.drawText("Halaman $pageNo",500f,816f,paint(9f,gray))}
    fun drawRow(c:Canvas,y:Float,no:String,title:String,date:String,amount:Long,color:Int){c.drawText(no,42f,y,paint(10f,gray));c.drawText(title.take(42),72f,y,paint(11f,dark,true));c.drawText(date,360f,y,paint(10f,gray));c.drawText(rupiah(amount),500f,y,paint(11f,color,true))}
    var pageNo=1
    var page=doc.startPage(PdfDocument.PageInfo.Builder(595,842,pageNo).create());var c=page.canvas;header(c,pageNo)
    c.drawText("Ringkasan Keuangan",36f,135f,paint(18f,navy,true))
    round(c,36f,155f,215f,235f,softGreen);c.drawText("PEMASUKAN",55f,180f,paint(10f,gray,true));c.drawText(rupiah(income),55f,213f,paint(18f,green,true))
    round(c,230f,155f,409f,235f,softRed);c.drawText("PENGELUARAN",249f,180f,paint(10f,gray,true));c.drawText(rupiah(expense),249f,213f,paint(18f,red,true))
    round(c,424f,155f,559f,235f,softBlue);c.drawText("LABA BERSIH",441f,180f,paint(10f,gray,true));c.drawText(rupiah(income-expense),441f,213f,paint(15f,blue,true))
    c.drawText("Rincian Pemasukan",36f,275f,paint(16f,navy,true));round(c,36f,290f,559f,322f,softGreen);c.drawText("No",42f,311f,paint(9f,gray,true));c.drawText("Keterangan",72f,311f,paint(9f,gray,true));c.drawText("Tanggal",360f,311f,paint(9f,gray,true));c.drawText("Jumlah",500f,311f,paint(9f,gray,true))
    var y=345f
    val paymentTotal=mp.sumOf{it.amount}
    drawRow(c,y,"1","Pembayaran Siswa","Bulan ini",paymentTotal,green);y+=30f
    var no=2
    for(i in mi){if(y>735f)break;drawRow(c,y,no.toString(),i.title,i.date,i.amount,green);y+=30f;no++}
    c.drawText("Total pemasukan",360f,780f,paint(11f,dark,true));c.drawText(rupiah(income),500f,780f,paint(12f,green,true))
    doc.finishPage(page)
    pageNo++;page=doc.startPage(PdfDocument.PageInfo.Builder(595,842,pageNo).create());c=page.canvas;header(c,pageNo)
    c.drawText("Rincian Pengeluaran",36f,135f,paint(18f,navy,true));round(c,36f,150f,559f,182f,softRed);c.drawText("No",42f,171f,paint(9f,gray,true));c.drawText("Keterangan",72f,171f,paint(9f,gray,true));c.drawText("Tanggal",360f,171f,paint(9f,gray,true));c.drawText("Jumlah",500f,171f,paint(9f,gray,true));y=205f;no=1
    for(e in me){if(y>745f)break;drawRow(c,y,no.toString(),e.title,e.date,e.amount,red);y+=30f;no++}
    c.drawText("Total pengeluaran",360f,780f,paint(11f,dark,true));c.drawText(rupiah(expense),500f,780f,paint(12f,red,true))
    doc.finishPage(page)
    doc.writeTo(file.outputStream());doc.close();return file
}

fun sharePdf(context:Context,file:File,title:String){val uri=FileProvider.getUriForFile(context,"${context.packageName}.fileprovider",file);val send=Intent(Intent.ACTION_SEND).apply{type="application/pdf";putExtra(Intent.EXTRA_STREAM,uri);putExtra(Intent.EXTRA_TEXT,title);addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)};runCatching{context.startActivity(Intent.createChooser(send,title))}}
fun shareReceiptPdf(context:Context,p:Payment,s:Student){shareReceiptImage(context,p,s)}
fun shareReportPdf(context:Context,month:String,program:String,status:String,list:List<Student>,payments:List<Payment>,income:Long,expense:Long){sharePdf(context,createReportPdf(context,month,program,status,list,payments,income,expense),"Bagikan laporan $month")}
fun savePdfWithChooser(context:Context,fileName:String,makeFile:()->File){val file=makeFile();val uri=FileProvider.getUriForFile(context,"${context.packageName}.fileprovider",file);val intent=Intent(Intent.ACTION_SEND).apply{type="application/pdf";putExtra(Intent.EXTRA_STREAM,uri);putExtra(Intent.EXTRA_TITLE,fileName);addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)};runCatching{context.startActivity(Intent.createChooser(intent,"Simpan/Bagikan PDF"))}}

class MainActivity:ComponentActivity(){override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);setContent{App()}}}

@Composable
fun MoreScreen(programs:List<Program>, vm:MainVm, activeMonth:String, onMonthChange:(String)->Unit, onProgram:()->Unit, onNotifications:()->Unit, onSecurity:()->Unit, onBackup:()->Unit, onAbout:()->Unit, onLock:()->Unit){
    LazyColumn(Modifier.fillMaxSize().background(Bg),contentPadding=PaddingValues(bottom=20.dp)){
        item{Box(Modifier.fillMaxWidth().height(250.dp).clip(RoundedCornerShape(bottomStart=30.dp,bottomEnd=30.dp))){Image(painterResource(R.drawable.final_lainnya_header),"Background Lainnya",Modifier.fillMaxSize(),contentScale=androidx.compose.ui.layout.ContentScale.FillBounds);}}
        item{MoreSettingCard("Program & Tarif","Kelola program belajar dan tarif bulanan",Icons.Default.School,Green,SoftGreen,onProgram)}
        item{MoreSettingCard("Pemberitahuan","Atur pemberitahuan ON / OFF",Icons.Default.Notifications,Yellow,SoftYellow,onNotifications)}
        item{MoreSettingCard("Keamanan Aplikasi","PIN Admin dan penguncian aplikasi",Icons.Default.Lock,Red,SoftRed,onSecurity)}
        item{MoreSettingCard("Backup & Restore","Simpan atau pulihkan seluruh data aplikasi",Icons.Default.CloudUpload,Navy2,SoftBlue,onBackup)}
        item{MoreSettingCard("Tentang Aplikasi","Informasi Bimbel Smart Kreatif Cemerlang",Icons.Default.Info,Color(0xFF7B32C8),SoftPurple,onAbout)}
    }
}
@Composable
fun MoreSettingCard(title:String,subtitle:String,icon:ImageVector,accent:Color,iconBg:Color,onClick:()->Unit){Card(Modifier.fillMaxWidth().padding(horizontal=14.dp,vertical=5.dp).clickable(onClick=onClick),shape=RoundedCornerShape(22.dp),colors=CardDefaults.cardColors(Color.White),elevation=CardDefaults.cardElevation(3.dp)){Row(Modifier.padding(13.dp),verticalAlignment=Alignment.CenterVertically){Surface(color=iconBg,shape=RoundedCornerShape(17.dp)){Icon(icon,null,tint=accent,modifier=Modifier.padding(12.dp).size(27.dp))};Spacer(Modifier.width(12.dp));Column(Modifier.weight(1f)){Text(title,fontSize=16.sp,fontWeight=FontWeight.ExtraBold,color=Navy);Text(subtitle,fontSize=10.sp,color=Color.Gray,maxLines=2,overflow=TextOverflow.Ellipsis)};Icon(Icons.Default.ChevronRight,null,tint=Navy,modifier=Modifier.size(25.dp))}}}


@Composable fun MoreMenuCard(title:String,subtitle:String,icon:ImageVector,onClick:()->Unit){Card(Modifier.fillMaxWidth().padding(horizontal=14.dp,vertical=6.dp).clickable(onClick=onClick),shape=RoundedCornerShape(22.dp),colors=CardDefaults.cardColors(Color.White),elevation=CardDefaults.cardElevation(3.dp)){Row(Modifier.padding(15.dp),verticalAlignment=Alignment.CenterVertically){Surface(color=SoftBlue,shape=CircleShape){Icon(icon,null,tint=Navy,modifier=Modifier.padding(11.dp).size(23.dp))};Spacer(Modifier.width(12.dp));Column(Modifier.weight(1f)){Text(title,fontSize=16.sp,fontWeight=FontWeight.ExtraBold,color=Navy);Text(subtitle,fontSize=10.sp,color=Color.Gray)};Icon(Icons.Default.ChevronRight,null,tint=Navy)}}}

@Composable fun ProgramManagementPage(programs:List<Program>,vm:MainVm,onAdd:()->Unit){LazyColumn(Modifier.fillMaxSize().background(Bg),contentPadding=PaddingValues(bottom=25.dp)){item{PageTitleBlock("Program & Tarif","Kelola program dan tarif bulanan.")};programs.forEach{program->item{Card(Modifier.fillMaxWidth().padding(horizontal=18.dp,vertical=4.dp),shape=RoundedCornerShape(19.dp),colors=CardDefaults.cardColors(Color.White),elevation=CardDefaults.cardElevation(2.dp)){Row(Modifier.padding(13.dp),verticalAlignment=Alignment.CenterVertically){Surface(color=programColors(program.name).iconBg,shape=CircleShape){ProgramIcon3D(program.iconKey,modifier=Modifier.padding(5.dp).size(42.dp))};Spacer(Modifier.width(11.dp));Column(Modifier.weight(1f)){Text(program.name,fontWeight=FontWeight.ExtraBold,color=Navy,fontSize=16.sp);Text("${rupiah(program.fee)} / bulan",fontSize=11.sp,color=Color.Gray)};IconButton(onClick={vm.deleteProgram(program)}){Icon(Icons.Default.Delete,null,tint=Red)}}}}};item{Button(onClick=onAdd,modifier=Modifier.fillMaxWidth().padding(18.dp).height(50.dp),shape=RoundedCornerShape(15.dp),colors=ButtonDefaults.buttonColors(Navy)){Icon(Icons.Default.Add,null);Spacer(Modifier.width(6.dp));Text("Tambah Program",fontWeight=FontWeight.ExtraBold)}}}}

@Composable fun PageTitleBlock(title:String,subtitle:String){Column(Modifier.padding(18.dp,18.dp,18.dp,8.dp)){Text(title,fontSize=26.sp,fontWeight=FontWeight.ExtraBold,color=Navy);Text(subtitle,fontSize=11.sp,color=Color.Gray)}}

@Composable fun NotificationSettingsPage(context:Context){val prefs=context.getSharedPreferences("bimbel_notifications",Context.MODE_PRIVATE);var all by remember{mutableStateOf(prefs.getBoolean("all",true))};var month by remember{mutableStateOf(prefs.getBoolean("month",true))};var payment by remember{mutableStateOf(prefs.getBoolean("payment",true))};var info by remember{mutableStateOf(prefs.getBoolean("info",true))};LazyColumn(Modifier.fillMaxSize().background(Bg),contentPadding=PaddingValues(bottom=25.dp)){item{Box(Modifier.fillMaxWidth().height(190.dp).clip(RoundedCornerShape(bottomStart=28.dp,bottomEnd=28.dp))){Image(painterResource(R.drawable.background_header_2),"Background Pemberitahuan",Modifier.fillMaxSize(),contentScale=androidx.compose.ui.layout.ContentScale.Crop);Box(Modifier.fillMaxSize().background(Brush.horizontalGradient(listOf(Color.White.copy(alpha=.94f),Color.White.copy(alpha=.35f),Color.Transparent))));Column(Modifier.align(Alignment.BottomStart).padding(18.dp)){Text("Pemberitahuan",fontSize=26.sp,fontWeight=FontWeight.ExtraBold,color=Navy);Text("Atur jenis pemberitahuan yang ingin diterima.",fontSize=11.sp,color=Navy)}}};item{NotificationRow("Pemberitahuan umum","Info dan perubahan aplikasi",all){all=it;prefs.edit().putBoolean("all",it).apply()}};item{NotificationRow("Pengingat ganti bulan","Peringatan sebelum bulan berganti",month){month=it;prefs.edit().putBoolean("month",it).apply()}};item{NotificationRow("Pembayaran","Pengingat status pembayaran",payment){payment=it;prefs.edit().putBoolean("payment",it).apply()}};item{NotificationRow("Pengumuman","Informasi dan pengumuman Bimbel",info){info=it;prefs.edit().putBoolean("info",it).apply()}};item{Card(Modifier.fillMaxWidth().padding(18.dp),shape=RoundedCornerShape(20.dp),colors=CardDefaults.cardColors(SoftBlue)){Row(Modifier.padding(14.dp),verticalAlignment=Alignment.CenterVertically){Icon(Icons.Default.Info,null,tint=Navy);Spacer(Modifier.width(9.dp));Text("Pengaturan ini tersimpan di perangkat dan dapat diubah kapan saja.",fontSize=10.sp,color=Navy)}}}}}

@Composable fun NotificationRow(title:String,subtitle:String,checked:Boolean,onChange:(Boolean)->Unit){Card(Modifier.fillMaxWidth().padding(horizontal=14.dp,vertical=5.dp),shape=RoundedCornerShape(19.dp),colors=CardDefaults.cardColors(Color.White),elevation=CardDefaults.cardElevation(2.dp)){Row(Modifier.padding(14.dp),verticalAlignment=Alignment.CenterVertically){Surface(color=if(checked)SoftBlue else Color(0xFFF1F3F6),shape=CircleShape){Icon(Icons.Default.Notifications,null,tint=if(checked)Navy else Color.Gray,modifier=Modifier.padding(10.dp).size(22.dp))};Spacer(Modifier.width(11.dp));Column(Modifier.weight(1f)){Text(title,fontWeight=FontWeight.ExtraBold,color=Navy,fontSize=15.sp);Text(subtitle,fontSize=10.sp,color=Color.Gray)};Switch(checked=checked,onCheckedChange=onChange)}}}

@Composable fun SecurityPage(context:Context,onLock:()->Unit){var changePin by remember{mutableStateOf(false)};LazyColumn(Modifier.fillMaxSize().background(Bg),contentPadding=PaddingValues(bottom=25.dp)){item{PageTitleBlock("Keamanan Aplikasi","Kelola keamanan aplikasi tanpa mengubah sistem PIN yang sudah ada.")};item{MoreSection("PIN Admin",Icons.Default.Lock){Text("Data siswa dan keuangan dilindungi dengan PIN Admin 6 digit.",fontSize=10.sp,color=Color.Gray);Spacer(Modifier.height(8.dp));OutlinedButton(onClick={changePin=true},modifier=Modifier.fillMaxWidth().height(44.dp),shape=RoundedCornerShape(13.dp)){Icon(Icons.Default.Password,null);Spacer(Modifier.width(6.dp));Text("Ganti PIN Admin",fontWeight=FontWeight.Bold)}}};item{MoreSection("Kunci Aplikasi",Icons.Default.Lock){Button(onClick=onLock,modifier=Modifier.fillMaxWidth().height(44.dp),shape=RoundedCornerShape(13.dp),colors=ButtonDefaults.buttonColors(Navy)){Icon(Icons.Default.Lock,null);Spacer(Modifier.width(6.dp));Text("Kunci Aplikasi",fontWeight=FontWeight.Bold)}}}};if(changePin)ChangePinDialog(context,{changePin=false})}

@Composable
fun BackupPage(vm:MainVm){
    var backupText by remember{mutableStateOf("")}
    var showBackup by remember{mutableStateOf(false)}
    val ctx=androidx.compose.ui.platform.LocalContext.current
    val create=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")){uri->
        if(uri!=null)ctx.contentResolver.openOutputStream(uri)?.use{it.write(backupText.toByteArray())}
    }
    val open=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){uri->
        if(uri!=null){
            val text=ctx.contentResolver.openInputStream(uri)?.bufferedReader()?.use{it.readText()}
            if(!text.isNullOrBlank())vm.viewModelScope.launch{vm.restoreJson(text)}
        }
    }
    LazyColumn(Modifier.fillMaxSize().background(Bg),contentPadding=PaddingValues(bottom=25.dp)){
        item{PageTitleBlock("Backup & Restore","Simpan dan pulihkan data aplikasi.")}
        item{
            MoreSection("Data Aplikasi",Icons.Default.Backup){
                Text("Simpan seluruh data siswa, pembayaran, program, pemasukan, dan pengeluaran.",fontSize=10.sp,color=Color.Gray)
                Spacer(Modifier.height(9.dp))
                Row(horizontalArrangement=Arrangement.spacedBy(8.dp),modifier=Modifier.fillMaxWidth()){
                    Button(onClick={vm.exportJson{backupText=it;showBackup=true}},modifier=Modifier.weight(1f).height(44.dp),shape=RoundedCornerShape(13.dp),colors=ButtonDefaults.buttonColors(Navy)){Text("Backup",fontWeight=FontWeight.Bold)}
                    OutlinedButton(onClick={open.launch(arrayOf("application/json","text/plain"))},modifier=Modifier.weight(1f).height(44.dp),shape=RoundedCornerShape(13.dp)){Text("Restore",fontWeight=FontWeight.Bold)}
                }
            }
        }
    }
    if(showBackup){
        AlertDialog(
            onDismissRequest={showBackup=false},
            title={Text("Backup siap",fontWeight=FontWeight.Bold,color=Navy)},
            text={Text("Simpan data aplikasi ke file JSON.")},
            confirmButton={Button(onClick={showBackup=false;create.launch("backup_bimbel_${today().replace('/','-')}.json")},colors=ButtonDefaults.buttonColors(Navy)){Text("Simpan")}},
            dismissButton={TextButton(onClick={showBackup=false}){Text("Batal")}}
        )
    }
}

@Composable fun AboutPage(){LazyColumn(Modifier.fillMaxSize().background(Bg),contentPadding=PaddingValues(bottom=25.dp)){item{PageTitleBlock("Tentang Aplikasi","Bimbel Smart Kreatif Cemerlang")};item{Card(Modifier.fillMaxWidth().padding(18.dp),shape=RoundedCornerShape(24.dp),colors=CardDefaults.cardColors(Color.White),elevation=CardDefaults.cardElevation(3.dp)){Column(Modifier.padding(20.dp),horizontalAlignment=Alignment.CenterHorizontally){Image(painterResource(R.drawable.logo_bimbel),"Logo",Modifier.size(100.dp));Spacer(Modifier.height(10.dp));Text("Bimbel Smart Kreatif Cemerlang",fontSize=21.sp,fontWeight=FontWeight.ExtraBold,color=Navy);Text("Aplikasi pengelolaan siswa, pembayaran, dan laporan keuangan.",fontSize=11.sp,color=Color.Gray)}}}}}

@Composable fun ChangePinDialog(context:Context,onDismiss:()->Unit){var old by remember{mutableStateOf("")};var next by remember{mutableStateOf("")};var confirm by remember{mutableStateOf("")};var error by remember{mutableStateOf("")};AlertDialog(onDismissRequest=onDismiss,title={Text("Ganti PIN Admin",fontWeight=FontWeight.Bold,color=Navy)},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){listOf(Triple("PIN lama",old,{v:String->old=v}),Triple("PIN baru",next,{v:String->next=v}),Triple("Ulangi PIN baru",confirm,{v:String->confirm=v})).forEach{(label,value,set)->OutlinedTextField(value,set,label={Text(label)},visualTransformation=androidx.compose.ui.text.input.PasswordVisualTransformation(),keyboardOptions=androidx.compose.foundation.text.KeyboardOptions(keyboardType=androidx.compose.ui.text.input.KeyboardType.NumberPassword),singleLine=true,modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(12.dp))};if(error.isNotBlank())Text(error,color=Red,fontSize=12.sp,fontWeight=FontWeight.Bold)}},confirmButton={Button(onClick={when{old.length!=6||next.length!=6||confirm.length!=6->error="Semua PIN harus 6 digit";!checkPin(context,old)->error="PIN lama salah";next!=confirm->error="PIN baru tidak sama";else->{savePin(context,next);onDismiss()}}},colors=ButtonDefaults.buttonColors(Navy)){Text("Simpan")}},dismissButton={TextButton(onClick=onDismiss){Text("Batal")}})}

@Composable fun MoreSection(title:String,icon:ImageVector,content:@Composable (() -> Unit)){Card(Modifier.fillMaxWidth().padding(horizontal=12.dp,vertical=5.dp),shape=RoundedCornerShape(22.dp),colors=CardDefaults.cardColors(Color.White),elevation=CardDefaults.cardElevation(2.dp)){Column(Modifier.padding(13.dp)){Row(verticalAlignment=Alignment.CenterVertically){Surface(color=SoftBlue,shape=CircleShape){Icon(icon,null,tint=Navy,modifier=Modifier.padding(9.dp).size(21.dp))};Spacer(Modifier.width(9.dp));Text(title,fontWeight=FontWeight.ExtraBold,color=Navy,fontSize=16.sp)};Spacer(Modifier.height(8.dp));content()}}}


