BLUEPRINT V2 - VISUAL PATCH
Project: Bimbel Smart Kreatif Cemerlang
Tanggal: 17 September 2026

Perubahan visual pada source ini mengikuti blueprint v2 yang dikunci user.

Dikunci / dipertahankan:
- Seluruh fungsi dan fitur yang sudah berjalan tidak dirombak.
- Navigasi dan alur buka halaman program/siswa/pembayaran/laporan tetap dipertahankan.
- Status pembayaran dan integrasi pemasukan tetap menggunakan database yang sama.
- Edit pemasukan/pengeluaran dan PDF laporan tetap dipertahankan.
- Tombol Tambah Program tetap membuka halaman form.

Visual yang diperbarui:
- Splash screen: layout lebih dekat blueprint, ilustrasi 4 anak.
- Dashboard: header, banner semangat dengan ilustrasi, bulan aktif center, kartu status modern, warning card, quote card.
- Tab Siswa: banner ilustrasi, search + tambah, filter pill, kartu program modern; nama siswa tetap alfabetis dan tanpa nomor urut di daftar detail.
- Avatar siswa: variasi avatar built-in lebih banyak dan lebih modern.
- Tab Bayar: banner, filter program/status, kartu pembayaran modern; alur edit status tetap menggunakan PaymentDialog/database yang ada.
- Tab Laporan: header/banner, kartu biru laporan, kotak pemasukan/pengeluaran dengan warna berbeda, tab modern, daftar transaksi dan PDF tetap tersedia.
- Tab Lainnya: Program & Tarif dibuat lebih modern dan tombol Tambah Program tetap aktif; form program menyediakan banyak pilihan ikon.
- Kuitansi: ditambahkan ilustrasi 4 anak dan tanda tangan Siti Rahma pada blok bawah kuitansi.

Catatan build:
- Source sudah dipatch dan asset blueprint_kids_4.png ditambahkan.
- Lingkungan container ini tidak memiliki Gradle executable/wrapper sehingga assembleRelease belum dapat diverifikasi secara lokal. Silakan jalankan GitHub Actions/Gradle pada lingkungan project untuk compile check.
