SOURCE BARU - BLUEPRINT V2 VISUAL PATCH
Tanggal: 17 September 2026

Dasar: source BLUEPRINT_V2_VISUAL_PATCH_BUILD_FIX2 yang sudah berhasil digunakan sebagai fondasi.

PERUBAHAN VISUAL NYATA:
1. Splash memakai artwork sekolah + empat anak + logo/tagline dari aset visual final, bukan lagi background gradient polos.
2. Dashboard welcome memakai scene sekolah/anak sebagai background lembut dan layout banner diperbesar agar lebih dekat dengan blueprint.
3. Fungsi database, pembayaran, laporan, pengeluaran/pemasukan, kuitansi, PIN, dan navigasi tidak dihapus atau dirombak.
4. blueprint_kids_4 tetap dipertahankan untuk receipt dan avatar illustration yang sudah ada.

CATATAN:
- Ini adalah SOURCE ZIP untuk di-upload ke repository.
- Jangan memasukkan file ZIP master blueprint sebagai source build terpilih. Workflow sebaiknya menunjuk langsung ke ZIP source ini.
