FINAL SOURCE PATCH — 17 SEPTEMBER 2026
Project: Bimbel Smart Kreatif Cemerlang
Foundation: BLUEPRINT_V2_VISUAL_FIX source that successfully built as Build #109.

LOCKED / UNCHANGED
- Splash Screen: unchanged.
- PIN Login: unchanged.
- Laporan: unchanged.
- Existing payment/month/navigation functions preserved.

APPLIED CHANGES
1. Dashboard
- Approved "background header" artwork applied to welcome banner.
- "Cerdas • Kreatif • Berkarakter • Berprestasi" is bold.
- "Langkah kecil hari ini, hasil besar untuk masa depan." is bold.
- Statistics cards receive stronger elevation/shadow.

2. Data Siswa
- Approved "background header 2" artwork applied to top section.
- Search and Tambah Siswa remain functional overlays.
- 3D avatar set: 20 assets (10 boys, 10 girls; includes hijab and non-hijab).
- Program group remains scrollable and connected to the same Program data.
- Opening a program shows alphabetical student list.
- Student three-dot menu now provides Edit and Hapus.
- Delete confirmation added.

3. Student deletion synchronization
- Deleting a student also deletes all payment records belonging to that student.
- Therefore the student disappears from Data Siswa, Bayar, dashboard payment counts, and payment-derived report totals.

4. Pembayaran
- Approved payment-themed background applied to header.
- Uses the same students/programs data source as Data Siswa.
- Program filters remain based on Program records.
- Each student row has status LUNAS / KURANG BAYAR / BELUM BAYAR and a three-dot action.
- Three-dot opens the existing Ubah Status Pembayaran form.
- Form supports changing status and sharing receipt when a payment exists.
- Existing Tagihan / Dibayar / Sisa calculations preserved.

5. Program icons
- Replaced vector-only visual set with 20 3D program icon assets.
- Selection in Tambah Program uses the 3D set.
- Selected iconKey propagates to program cards in Data Siswa, Bayar, and Lainnya.

6. Receipt
- Existing PNG receipt generation retained and status rendering now supports LUNAS, KURANG BAYAR, and BELUM BAYAR.
- Existing Blueprint V2 elements remain: logo, payment amount/status, four-child illustration, Hormat kami, Siti Rahma, and PNG sharing.

NOTE
This archive is source-only. The project ZIP intentionally uses the current workflow foundation; GitHub Actions should be used for the authoritative Android build.
