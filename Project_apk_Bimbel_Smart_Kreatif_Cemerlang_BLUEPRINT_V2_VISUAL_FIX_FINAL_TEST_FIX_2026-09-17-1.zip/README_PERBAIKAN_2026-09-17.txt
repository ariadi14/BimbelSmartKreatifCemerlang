PERBAIKAN SOURCE - 17 SEPTEMBER 2026

Perubahan diterapkan berdasarkan instruksi pengguna:
1. Splash: memakai panel Splash Blueprint V2 yang sudah dipisahkan dari gambar gabungan Splash+Kuitansi; progress/loading berasal dari artwork blueprint sehingga tidak dobel.
2. PIN: tidak diubah.
3. Dashboard: banner visual memakai artwork sekolah+anak Blueprint V2, tanpa mengubah kartu/status/bulan/peringatan yang sudah berjalan.
4. Avatar siswa: mengganti avatar Material Face menjadi ilustrasi anak 12 variasi, termasuk laki-laki/perempuan dan hijab; picker memiliki filter Semua/Laki-laki/Perempuan.
5. Bayar: kategori program sekarang dinamis dari tabel Program yang sama dengan Tab Siswa/Tambah Program; memilih program tidak lagi dianggap sebagai status pembayaran, sehingga daftar siswa langsung muncul. Filter status tetap terpisah.
6. Laporan: tidak diubah.
7. Ikon program: ikon tersimpan dari Tambah Program sekarang diteruskan ke tampilan grup program Siswa dan Bayar; daftar pilihan tetap modern dan beragam.

Catatan:
- Source ini belum dinyatakan build-success sampai GitHub Actions berhasil.
- PIN dan Laporan sengaja tidak disentuh.
