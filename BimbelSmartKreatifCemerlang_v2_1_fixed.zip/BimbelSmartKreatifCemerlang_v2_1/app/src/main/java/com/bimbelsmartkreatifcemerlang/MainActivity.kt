package com.bimbelsmartkreatifcemerlang

import android.content.Context
import android.content.Intent
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.room.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.*

@Entity(tableName = "students")
data class Student(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val className: String,
    val parentPhone: String,
    val program: String,
    val monthlyFee: Long,
    val active: Boolean = true
)

@Entity(tableName = "payments")
data class Payment(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val studentId: Long,
    val month: String,
    val amount: Long,
    val method: String,
    val date: String,
    val note: String,
    val receiptNo: String = ""
)

@Entity(tableName = "programs")
data class Program(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val fee: Long
)

@Dao
interface StudentDao {
    @Query("SELECT * FROM students WHERE active = 1 ORDER BY name") fun active(): Flow<List<Student>>
    @Insert suspend fun insert(s: Student): Long
    @Update suspend fun update(s: Student)
    @Delete suspend fun delete(s: Student)
}

@Dao
interface PaymentDao {
    @Query("SELECT * FROM payments ORDER BY id DESC") fun all(): Flow<List<Payment>>
    @Insert suspend fun insert(p: Payment): Long
    @Delete suspend fun delete(p: Payment)
}

@Dao
interface ProgramDao {
    @Query("SELECT * FROM programs ORDER BY name") fun all(): Flow<List<Program>>
    @Insert suspend fun insert(p: Program)
    @Delete suspend fun delete(p: Program)
}

@Database(entities = [Student::class, Payment::class, Program::class], version = 2, exportSchema = false)
abstract class AppDb : RoomDatabase() {
    abstract fun students(): StudentDao
    abstract fun payments(): PaymentDao
    abstract fun programs(): ProgramDao
    companion object {
        @Volatile private var INSTANCE: AppDb? = null
        fun get(c: Context): AppDb = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(c.applicationContext, AppDb::class.java, "bimbel.db")
                .fallbackToDestructiveMigration().build().also { INSTANCE = it }
        }
    }
}

fun rupiah(n: Long): String = NumberFormat.getCurrencyInstance(Locale("id", "ID")).format(n).replace(",00", "")
fun monthNow(): String = SimpleDateFormat("MMMM yyyy", Locale("id", "ID")).format(Date())
fun today(): String = SimpleDateFormat("dd/MM/yyyy", Locale("id", "ID")).format(Date())
fun normalizePhone(raw: String): String {
    val p = raw.filter(Char::isDigit)
    return when {
        p.startsWith("62") -> p
        p.startsWith("0") -> "62" + p.drop(1)
        else -> p
    }
}

class MainVm(ctx: Context) : ViewModel() {
    private val db = AppDb.get(ctx)
    private val app = ctx.applicationContext
    val students = db.students().active()
    val payments = db.payments().all()
    val programs = db.programs().all()

    init { viewModelScope.launch {
        db.programs().all().collect { if (it.isEmpty()) listOf(
            Program(name = "Calistung", fee = 150000),
            Program(name = "Iqro / Al-Qur'an", fee = 100000),
            Program(name = "Bimbel", fee = 150000),
            Program(name = "English", fee = 150000)
        ).forEach { db.programs().insert(it) } }
    } }
    fun addStudent(s: Student) = viewModelScope.launch { db.students().insert(s) }
    fun updateStudent(s: Student) = viewModelScope.launch { db.students().update(s) }
    fun deleteStudent(s: Student) = viewModelScope.launch { db.students().delete(s) }
    fun addPayment(p: Payment) = viewModelScope.launch { db.payments().insert(p) }
    fun deletePayment(p: Payment) = viewModelScope.launch { db.payments().delete(p) }
    fun addProgram(p: Program) = viewModelScope.launch { db.programs().insert(p) }
    fun deleteProgram(p: Program) = viewModelScope.launch { db.programs().delete(p) }

    fun exportJson(onDone: (String) -> Unit) = viewModelScope.launch {
        val ss = db.students().activeOnce()
        val ps = db.payments().allOnce()
        val gs = db.programs().allOnce()
        val o = JSONObject().put("version", 2).put("exportedAt", today())
        o.put("students", JSONArray().apply { ss.forEach { put(JSONObject().put("id",it.id).put("name",it.name).put("className",it.className).put("parentPhone",it.parentPhone).put("program",it.program).put("monthlyFee",it.monthlyFee).put("active",it.active)) } })
        o.put("payments", JSONArray().apply { ps.forEach { put(JSONObject().put("id",it.id).put("studentId",it.studentId).put("month",it.month).put("amount",it.amount).put("method",it.method).put("date",it.date).put("note",it.note).put("receiptNo",it.receiptNo)) } })
        o.put("programs", JSONArray().apply { gs.forEach { put(JSONObject().put("id",it.id).put("name",it.name).put("fee",it.fee)) } })
        onDone(o.toString(2))
    }

    suspend fun restoreJson(text: String) {
        val o = JSONObject(text)
        val ss = o.optJSONArray("students") ?: JSONArray()
        val gs = o.optJSONArray("programs") ?: JSONArray()
        val ps = o.optJSONArray("payments") ?: JSONArray()
        for (i in 0 until gs.length()) { val x=gs.getJSONObject(i); db.programs().insert(Program(x.optLong("id",0),x.optString("name"),x.optLong("fee"))) }
        for (i in 0 until ss.length()) { val x=ss.getJSONObject(i); db.students().insert(Student(x.optLong("id",0),x.optString("name"),x.optString("className"),x.optString("parentPhone"),x.optString("program"),x.optLong("monthlyFee"),x.optBoolean("active",true))) }
        for (i in 0 until ps.length()) { val x=ps.getJSONObject(i); db.payments().insert(Payment(x.optLong("id",0),x.optLong("studentId"),x.optString("month"),x.optLong("amount"),x.optString("method"),x.optString("date"),x.optString("note"),x.optString("receiptNo"))) }
    }
}

// Small read helpers used only for backup.
suspend fun StudentDao.activeOnce(): List<Student> = active().first()
suspend fun PaymentDao.allOnce(): List<Payment> = all().first()
suspend fun ProgramDao.allOnce(): List<Program> = all().first()

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun App() {
    val context = LocalContext.current.applicationContext
    val vm: MainVm = viewModel(factory = object : androidx.lifecycle.ViewModelProvider.Factory {
        override fun <T : ViewModel> create(modelClass: Class<T>): T = MainVm(context) as T
    })
    var tab by remember { mutableIntStateOf(0) }
    var studentDialog by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<Student?>(null) }
    var payStudent by remember { mutableStateOf<Student?>(null) }
    val students by vm.students.collectAsState(emptyList())
    val payments by vm.payments.collectAsState(emptyList())
    val programs by vm.programs.collectAsState(emptyList())
    Scaffold(topBar={CenterAlignedTopAppBar(title={Text("Bimbel Smart Kreatif Cemerlang",fontWeight=FontWeight.Bold)},navigationIcon={Image(painterResource(R.drawable.logo_bimbel),"Logo",Modifier.padding(7.dp).size(42.dp))})},bottomBar={
        NavigationBar { listOf(Icons.Default.Home to "Beranda",Icons.Default.People to "Siswa",Icons.Default.ReceiptLong to "Bayar",Icons.Default.BarChart to "Laporan",Icons.Default.Settings to "Pengaturan").forEachIndexed { i,(icon,label)->NavigationBarItem(selected = tab == i, onClick = { tab = i }, icon = { Icon(icon, null) }, label = { Text(label) }) } }
    }) { pad -> Box(Modifier.padding(pad).fillMaxSize()) { when(tab){
        0 -> Dashboard(students,payments)
        1 -> StudentsScreen(students,{payStudent=it},{editing=it;studentDialog=true},{studentDialog=true})
        2 -> PaymentsScreen(students,payments,{vm.deletePayment(it)})
        3 -> ReportsScreen(students,payments)
        else -> SettingsScreen(programs,vm)
    } } }
    if(studentDialog) StudentDialog(programs,editing,{studentDialog=false;editing=null}) { s -> if(s.id==0L) vm.addStudent(s) else vm.updateStudent(s); studentDialog=false;editing=null }
    payStudent?.let { s -> PaymentDialog(s,{payStudent=null}) { p -> vm.addPayment(p);payStudent=null } }
}

@Composable fun Header(title:String,subtitle:String?=null){Column(Modifier.padding(16.dp)){Text(title,style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold);subtitle?.let{Text(it,color=Color.Gray)}}}
@Composable fun Stat(title:String,value:String,modifier:Modifier=Modifier){Card(modifier){Column(Modifier.padding(14.dp)){Text(title,style=MaterialTheme.typography.labelMedium);Text(value,style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold)}}}


@Composable
fun Dashboard(students: List<Student>, payments: List<Payment>) {
    val m = monthNow()
    val mp = payments.filter { it.month.equals(m, true) }
    fun paidAmount(id: Long) = mp.filter { it.studentId == id }.sumOf { it.amount }
    val paid = students.count { paidAmount(it.id) >= it.monthlyFee }
    val income = mp.sumOf { it.amount }
    Column {
        Header("Dashboard", "Ringkasan pembayaran $m")
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Stat("Siswa", students.size.toString(), Modifier.weight(1f))
            Stat("Lunas", paid.toString(), Modifier.weight(1f))
        }
        Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Stat("Belum/Kurang", (students.size - paid).toString(), Modifier.weight(1f))
            Stat("Pemasukan", rupiah(income), Modifier.weight(1f))
        }
        Header("Belum lunas")
        LazyColumn {
            items(students.filter { paidAmount(it.id) < it.monthlyFee }) { s ->
                ListItem(
                    headlineContent = { Text(s.name, fontWeight = FontWeight.Bold) },
                    supportingContent = { Text("${s.program} • ${rupiah(paidAmount(s.id))} / ${rupiah(s.monthlyFee)}") }
                )
                HorizontalDivider()
            }
        }
    }
}

@Composable
fun StudentsScreen(
    students: List<Student>,
    onPay: (Student) -> Unit,
    onEdit: (Student) -> Unit,
    onAdd: () -> Unit
) {
    var q by remember { mutableStateOf("") }
    val list = students.filter {
        it.name.contains(q, true) || it.className.contains(q, true) || it.program.contains(q, true)
    }
    Column {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Data Siswa", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Button(onClick = onAdd) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(4.dp)); Text("Tambah") }
        }
        OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth().padding(horizontal = 12.dp), label = { Text("Cari siswa") }, singleLine = true)
        LazyColumn(Modifier.padding(horizontal = 10.dp)) {
            items(list) { s ->
                Card(Modifier.fillMaxWidth().padding(vertical = 5.dp)) {
                    ListItem(
                        headlineContent = { Text(s.name, fontWeight = FontWeight.Bold) },
                        supportingContent = { Text("${s.className} • ${s.program}\n${rupiah(s.monthlyFee)} / bulan\nWA: ${s.parentPhone}") },
                        trailingContent = {
                            Row {
                                TextButton(onClick = { onEdit(s) }) { Text("Edit") }
                                TextButton(onClick = { onPay(s) }) { Text("Bayar") }
                            }
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun PaymentsScreen(students: List<Student>, payments: List<Payment>, onDelete: (Payment) -> Unit) {
    val ctx = LocalContext.current
    Column {
        Header("Riwayat Pembayaran", "Semua transaksi admin")
        LazyColumn {
            items(payments) { p ->
                val s = students.firstOrNull { it.id == p.studentId }
                ListItem(
                    headlineContent = { Text(s?.name ?: "Siswa dihapus", fontWeight = FontWeight.Bold) },
                    supportingContent = { Text("${p.month} • ${p.date} • ${p.method}\n${if (p.receiptNo.isBlank()) "Tanpa nomor kuitansi" else p.receiptNo}") },
                    trailingContent = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(rupiah(p.amount))
                            if (s != null) IconButton(onClick = { shareReceipt(ctx, p, s) }) { Icon(Icons.Default.Share, "Kirim kuitansi") }
                            IconButton(onClick = { onDelete(p) }) { Icon(Icons.Default.Delete, "Hapus") }
                        }
                    }
                )
                HorizontalDivider()
            }
        }
    }
}

@Composable
fun ReportsScreen(students: List<Student>, payments: List<Payment>) {
    val grouped = payments.groupBy { it.month }.entries.sortedByDescending { it.key }
    Column {
        Header("Laporan", "Rekap pemasukan berdasarkan bulan")
        LazyColumn(Modifier.padding(12.dp)) {
            items(grouped) { entry ->
                val m = entry.key
                val list = entry.value
                Card(Modifier.fillMaxWidth().padding(vertical = 5.dp)) {
                    ListItem(
                        headlineContent = { Text(m, fontWeight = FontWeight.Bold) },
                        supportingContent = { Text("${list.size} transaksi • ${list.distinctBy { it.studentId }.size} siswa") },
                        trailingContent = { Text(rupiah(list.sumOf { it.amount }), fontWeight = FontWeight.Bold) }
                    )
                }
            }
            if (grouped.isEmpty()) item { Text("Belum ada transaksi.", Modifier.padding(20.dp)) }
        }
    }
}

@Composable
fun SettingsScreen(programs: List<Program>, vm: MainVm) {
    val ctx = LocalContext.current
    var addProgram by remember { mutableStateOf(false) }
    var showBackup by remember { mutableStateOf(false) }
    var backupText by remember { mutableStateOf("") }
    val create = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null && backupText.isNotBlank()) {
            ctx.contentResolver.openOutputStream(uri)?.use { it.write(backupText.toByteArray()) }
        }
    }
    val open = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val text = ctx.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
            if (!text.isNullOrBlank()) vm.viewModelScope.launch { vm.restoreJson(text) }
        }
    }
    Column {
        Header("Pengaturan", "Program, tarif, backup dan bantuan")
        Row(Modifier.padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Program & Tarif", style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
            Button(onClick = { addProgram = true }) { Text("+ Program") }
        }
        LazyColumn(Modifier.weight(1f).padding(10.dp)) {
            items(programs) { p ->
                ListItem(
                    headlineContent = { Text(p.name) },
                    supportingContent = { Text("${rupiah(p.fee)} / bulan") },
                    trailingContent = { IconButton(onClick = { vm.deleteProgram(p) }) { Icon(Icons.Default.Delete, "Hapus") } }
                )
                HorizontalDivider()
            }
        }
        Button(
            onClick = { vm.exportJson { backupText = it; showBackup = true } },
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)
        ) { Text("Backup Data") }
        OutlinedButton(
            onClick = { open.launch(arrayOf("application/json", "text/plain")) },
            modifier = Modifier.fillMaxWidth().padding(16.dp)
        ) { Text("Restore Data JSON") }
    }
    if (addProgram) ProgramDialog({ addProgram = false }) { n, f -> vm.addProgram(Program(name = n, fee = f)); addProgram = false }
    if (showBackup) AlertDialog(
        onDismissRequest = { showBackup = false },
        title = { Text("Backup siap") },
        text = { Text("Pilih Simpan untuk menyimpan file backup JSON di HP.") },
        confirmButton = { Button(onClick = { showBackup = false; create.launch("backup_bimbel_${today().replace('/', '-')}.json") }) { Text("Simpan") } },
        dismissButton = { TextButton(onClick = { showBackup = false }) { Text("Batal") } }
    )
}

@Composable
fun StudentDialog(programs: List<Program>, existing: Student?, onDismiss: () -> Unit, onSave: (Student) -> Unit) {
    var name by remember { mutableStateOf(existing?.name ?: "") }
    var cls by remember { mutableStateOf(existing?.className ?: "") }
    var phone by remember { mutableStateOf(existing?.parentPhone ?: "") }
    var program by remember { mutableStateOf(existing?.program ?: programs.firstOrNull()?.name ?: "Bimbel") }
    var fee by remember { mutableStateOf(existing?.monthlyFee?.toString() ?: programs.firstOrNull()?.fee?.toString() ?: "150000") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existing == null) "Tambah Siswa" else "Edit Siswa") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("Nama siswa") }, singleLine = true)
                OutlinedTextField(cls, { cls = it }, label = { Text("Kelas") }, singleLine = true)
                OutlinedTextField(phone, { phone = it }, label = { Text("No. WhatsApp orang tua") }, singleLine = true)
                OutlinedTextField(program, { program = it }, label = { Text("Program") }, singleLine = true)
                OutlinedTextField(fee, { fee = it.filter(Char::isDigit) }, label = { Text("Tarif bulanan") }, singleLine = true)
            }
        },
        confirmButton = {
            Button(enabled = name.isNotBlank() && fee.isNotBlank(), onClick = { onSave(Student(existing?.id ?: 0, name, cls, phone, program, fee.toLong())) }) { Text("Simpan") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } }
    )
}

@Composable
fun PaymentDialog(s: Student, onDismiss: () -> Unit, onSave: (Payment) -> Unit) {
    var month by remember { mutableStateOf(monthNow()) }
    var amount by remember { mutableStateOf(s.monthlyFee.toString()) }
    var method by remember { mutableStateOf("Tunai") }
    var note by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Catat Pembayaran") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(s.name, fontWeight = FontWeight.Bold)
                OutlinedTextField(month, { month = it }, label = { Text("Bulan") }, singleLine = true)
                OutlinedTextField(amount, { amount = it.filter(Char::isDigit) }, label = { Text("Nominal") }, singleLine = true)
                OutlinedTextField(method, { method = it }, label = { Text("Metode: Tunai / Transfer") }, singleLine = true)
                OutlinedTextField(note, { note = it }, label = { Text("Catatan") })
            }
        },
        confirmButton = {
            Button(enabled = amount.isNotBlank(), onClick = {
                val no = "KW-${SimpleDateFormat("yyyyMMddHHmmss", Locale.US).format(Date())}"
                onSave(Payment(studentId = s.id, month = month, amount = amount.toLong(), method = method, date = today(), note = note, receiptNo = no))
            }) { Text("Simpan") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } }
    )
}

@Composable
fun ProgramDialog(onDismiss: () -> Unit, onSave: (String, Long) -> Unit) {
    var n by remember { mutableStateOf("") }
    var f by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Tambah Program") },
        text = { Column { OutlinedTextField(n, { n = it }, label = { Text("Nama program") }); OutlinedTextField(f, { f = it.filter(Char::isDigit) }, label = { Text("Tarif bulanan") }) } },
        confirmButton = { Button(enabled = n.isNotBlank() && f.isNotBlank(), onClick = { onSave(n, f.toLong()) }) { Text("Simpan") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } }
    )
}

fun shareReceipt(context: Context, p: Payment, s: Student) {
    val text = "KUITANSI PEMBAYARAN\nBimbel Smart Kreatif Cemerlang\nNo: ${p.receiptNo}\nSiswa: ${s.name}\nProgram: ${s.program}\nBulan: ${p.month}\nNominal: ${rupiah(p.amount)}\nMetode: ${p.method}\nTanggal: ${p.date}"
    val phone = normalizePhone(s.parentPhone)
    if (phone.isNotBlank()) {
        val wa = Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$phone?text=" + Uri.encode(text)))
        try { context.startActivity(wa) } catch (_: Exception) {
            context.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, text) }, "Bagikan kuitansi"))
        }
    } else {
        context.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, text) }, "Bagikan kuitansi"))
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = lightColorScheme(primary = Color(0xFFE60000), secondary = Color(0xFF7CB342))) { App() } }
    }
}
