# Bimbel Smart Kreatif Cemerlang v2.3

Perubahan utama:
- Kuitansi pembayaran dibagikan sebagai gambar PNG melalui Android Share Sheet.
- Program dan tarif dikelola dari menu Lainnya > Program & Tarif.
- Saat menambah/mengedit siswa, program dipilih dari data Program & Tarif dan tarif otomatis mengikuti program.
- Laporan yang dibuka dari kartu Lunas/Kurang/Belum Bayar tetap menggunakan filter status tersebut.
- Rincian laporan dikelompokkan per program, lalu nama siswa ditampilkan di bawah masing-masing kelompok.
- Fitur laporan PDF dan berbagi laporan tetap dipertahankan.
- UI dasar/blueprint 14 layar dipertahankan.
