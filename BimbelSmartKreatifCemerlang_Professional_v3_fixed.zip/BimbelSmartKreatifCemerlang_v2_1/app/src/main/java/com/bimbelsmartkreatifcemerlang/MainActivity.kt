package com.bimbelsmartkreatifcemerlang

import android.content.Context
import android.content.Intent
import android.graphics.*
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.room.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.*

@Entity(tableName = "students")
data class Student(@PrimaryKey(autoGenerate = true) val id: Long = 0, val name: String, val className: String, val parentPhone: String, val program: String, val monthlyFee: Long, val active: Boolean = true)

@Entity(tableName = "payments")
data class Payment(@PrimaryKey(autoGenerate = true) val id: Long = 0, val studentId: Long, val month: String, val amount: Long, val method: String, val date: String, val note: String, val receiptNo: String = "")

@Entity(tableName = "programs")
data class Program(@PrimaryKey(autoGenerate = true) val id: Long = 0, val name: String, val fee: Long)

@Dao interface StudentDao {
    @Query("SELECT * FROM students WHERE active = 1 ORDER BY name") fun active(): Flow<List<Student>>
    @Insert suspend fun insert(s: Student): Long
    @Update suspend fun update(s: Student)
    @Delete suspend fun delete(s: Student)
}
@Dao interface PaymentDao {
    @Query("SELECT * FROM payments ORDER BY id DESC") fun all(): Flow<List<Payment>>
    @Insert suspend fun insert(p: Payment): Long
    @Delete suspend fun delete(p: Payment)
}
@Dao interface ProgramDao {
    @Query("SELECT * FROM programs ORDER BY name") fun all(): Flow<List<Program>>
    @Insert suspend fun insert(p: Program)
    @Delete suspend fun delete(p: Program)
}

@Database(entities = [Student::class, Payment::class, Program::class], version = 2, exportSchema = false)
abstract class AppDb : RoomDatabase() {
    abstract fun students(): StudentDao; abstract fun payments(): PaymentDao; abstract fun programs(): ProgramDao
    companion object { @Volatile private var INSTANCE: AppDb? = null; fun get(c: Context): AppDb = INSTANCE ?: synchronized(this) { INSTANCE ?: Room.databaseBuilder(c.applicationContext, AppDb::class.java, "bimbel.db").fallbackToDestructiveMigration().build().also { INSTANCE = it } } }
}

fun rupiah(n: Long): String = NumberFormat.getCurrencyInstance(Locale("id", "ID")).format(n).replace(",00", "")
fun monthNow(): String = SimpleDateFormat("MMMM yyyy", Locale("id", "ID")).format(Date())
fun today(): String = SimpleDateFormat("dd/MM/yyyy", Locale("id", "ID")).format(Date())
fun normalizePhone(raw: String): String { val p = raw.filter(Char::isDigit); return when { p.startsWith("62") -> p; p.startsWith("0") -> "62" + p.drop(1); else -> p } }
fun statusFor(student: Student, paid: Long): String = when { paid >= student.monthlyFee -> "LUNAS"; paid > 0 -> "KURANG BAYAR"; else -> "BELUM BAYAR" }

class MainVm(ctx: Context) : ViewModel() {
    private val db = AppDb.get(ctx); val students = db.students().active(); val payments = db.payments().all(); val programs = db.programs().all()
    init { viewModelScope.launch { db.programs().all().collect { if (it.isEmpty()) listOf(Program("Calistung",150000),Program("Iqro / Al-Qur'an",100000),Program("Bimbel",150000),Program("English",150000)).forEach { db.programs().insert(it) } } } }
    fun addStudent(s: Student) = viewModelScope.launch { db.students().insert(s) }; fun updateStudent(s: Student) = viewModelScope.launch { db.students().update(s) }; fun deleteStudent(s: Student) = viewModelScope.launch { db.students().delete(s) }
    fun addPayment(p: Payment) = viewModelScope.launch { db.payments().insert(p) }; fun deletePayment(p: Payment) = viewModelScope.launch { db.payments().delete(p) }; fun addProgram(p: Program) = viewModelScope.launch { db.programs().insert(p) }; fun deleteProgram(p: Program) = viewModelScope.launch { db.programs().delete(p) }
    fun exportJson(onDone: (String) -> Unit) = viewModelScope.launch { val ss=db.students().activeOnce(); val ps=db.payments().allOnce(); val gs=db.programs().allOnce(); val o=JSONObject().put("version",3).put("exportedAt",today()); o.put("students",JSONArray().apply{ss.forEach{put(JSONObject().put("id",it.id).put("name",it.name).put("className",it.className).put("parentPhone",it.parentPhone).put("program",it.program).put("monthlyFee",it.monthlyFee).put("active",it.active))}}); o.put("payments",JSONArray().apply{ps.forEach{put(JSONObject().put("id",it.id).put("studentId",it.studentId).put("month",it.month).put("amount",it.amount).put("method",it.method).put("date",it.date).put("note",it.note).put("receiptNo",it.receiptNo))}}); o.put("programs",JSONArray().apply{gs.forEach{put(JSONObject().put("id",it.id).put("name",it.name).put("fee",it.fee))}}); onDone(o.toString(2)) }
    suspend fun restoreJson(text:String){val o=JSONObject(text);val ss=o.optJSONArray("students")?:JSONArray();val gs=o.optJSONArray("programs")?:JSONArray();val ps=o.optJSONArray("payments")?:JSONArray();for(i in 0 until gs.length()){val x=gs.getJSONObject(i);db.programs().insert(Program(x.optLong("id",0),x.optString("name"),x.optLong("fee")))};for(i in 0 until ss.length()){val x=ss.getJSONObject(i);db.students().insert(Student(x.optLong("id",0),x.optString("name"),x.optString("className"),x.optString("parentPhone"),x.optString("program"),x.optLong("monthlyFee"),x.optBoolean("active",true)))};for(i in 0 until ps.length()){val x=ps.getJSONObject(i);db.payments().insert(Payment(x.optLong("id",0),x.optLong("studentId"),x.optString("month"),x.optLong("amount"),x.optString("method"),x.optString("date"),x.optString("note"),x.optString("receiptNo")))}}
}
suspend fun StudentDao.activeOnce():List<Student> = active().first(); suspend fun PaymentDao.allOnce():List<Payment> = all().first(); suspend fun ProgramDao.allOnce():List<Program> = all().first()

private val Navy=Color(0xFF123B73); private val Blue=Color(0xFF1677E8); private val Green=Color(0xFF159A62); private val Gold=Color(0xFFFFC83D); private val Bg=Color(0xFFF4F7FB)

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun App(){
    val context=LocalContext.current.applicationContext; val vm:MainVm=viewModel(factory=object:androidx.lifecycle.ViewModelProvider.Factory{override fun<T:ViewModel>create(c:Class<T>):T=MainVm(context) as T})
    var tab by remember{mutableIntStateOf(0)}; var studentDialog by remember{mutableStateOf(false)}; var editing by remember{mutableStateOf<Student?>(null)}; var payStudent by remember{mutableStateOf<Student?>(null)}
    val students by vm.students.collectAsState(emptyList()); val payments by vm.payments.collectAsState(emptyList()); val programs by vm.programs.collectAsState(emptyList())
    Scaffold(containerColor=Bg,topBar={TopAppBar(title={Text("Bimbel Smart Kreatif Cemerlang",fontWeight=FontWeight.Bold,color=Navy)},navigationIcon={Image(painterResource(R.drawable.logo_bimbel),"Logo",Modifier.padding(7.dp).size(42.dp))},colors=TopAppBarDefaults.topAppBarColors(containerColor=Color.White))},bottomBar={NavigationBar{listOf(Icons.Default.Home to "Beranda",Icons.Default.People to "Siswa",Icons.Default.ReceiptLong to "Bayar",Icons.Default.BarChart to "Laporan",Icons.Default.Settings to "Lainnya").forEachIndexed{i,(icon,label)->NavigationBarItem(selected=tab==i,onClick={tab=i},icon={Icon(icon,null)},label={Text(label)})}}}){pad->Box(Modifier.padding(pad).fillMaxSize()){when(tab){0->Dashboard(students,payments);1->StudentsScreen(students,{payStudent=it},{editing=it;studentDialog=true},{studentDialog=true});2->PaymentsScreen(students,payments);3->ReportsScreen(students,payments);else->SettingsScreen(programs,vm)}}}
    if(studentDialog)StudentDialog(programs,editing,{studentDialog=false;editing=null}){s->if(s.id==0L)vm.addStudent(s)else vm.updateStudent(s);studentDialog=false;editing=null};payStudent?.let{s->PaymentDialog(s,{payStudent=null}){p->vm.addPayment(p);payStudent=null}}
}

@Composable fun Header(title:String,subtitle:String?=null){Column(Modifier.padding(16.dp)){Text(title,style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold,color=Navy);subtitle?.let{Text(it,color=Color.Gray)}}}
@Composable fun Stat(title:String,value:String,modifier:Modifier=Modifier,accent:Color=Blue){Card(modifier,colors=CardDefaults.cardColors(containerColor=Color.White),shape=RoundedCornerShape(18.dp)){Column(Modifier.padding(14.dp)){Text(title,style=MaterialTheme.typography.labelMedium,color=Color.Gray);Text(value,style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold,color=accent)}}}

@Composable
fun Dashboard(students: List<Student>, payments: List<Payment>) {
    val m = monthNow()
    val mp = payments.filter { it.month.equals(m, true) }
    fun paid(id: Long): Long = mp.filter { it.studentId == id }.sumOf { it.amount }
    val paidCount = students.count { paid(it.id) >= it.monthlyFee }
    val kurang = students.count { paid(it.id) in 1 until it.monthlyFee }
    val belum = students.size - paidCount - kurang
    val income = mp.sumOf { it.amount }

    Column {
        Header("Selamat datang 👋", "Dashboard pembayaran • $m")
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Stat("Total Siswa", students.size.toString(), Modifier.weight(1f), Blue)
            Stat("Sudah Bayar", paidCount.toString(), Modifier.weight(1f), Green)
        }
        Row(
            Modifier.fillMaxWidth().padding(16.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Stat("Kurang Bayar", kurang.toString(), Modifier.weight(1f), Gold)
            Stat("Pemasukan", rupiah(income), Modifier.weight(1f), Navy)
        }
        Card(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = Navy)
        ) {
            Column(Modifier.padding(18.dp)) {
                Text("Ringkasan bulan ini", color = Color.White, fontWeight = FontWeight.Bold)
                Text(
                    "$paidCount lunas • $kurang kurang • $belum belum bayar",
                    color = Color.White.copy(alpha = .85f)
                )
                Text(
                    rupiah(income),
                    color = Color.White,
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold
                )
            }
        }
        Header("Perlu ditindaklanjuti")
        LazyColumn {
            items(students.filter { paid(it.id) < it.monthlyFee }) { student ->
                val amount = paid(student.id)
                ListItem(
                    headlineContent = { Text(student.name, fontWeight = FontWeight.Bold) },
                    supportingContent = {
                        Text("${student.program} • ${rupiah(amount)} / ${rupiah(student.monthlyFee)}")
                    },
                    trailingContent = { StatusBadge(statusFor(student, amount)) }
                )
                HorizontalDivider()
            }
        }
    }
}

@Composable
fun StatusBadge(status: String) {
    val c = when (status) {
        "LUNAS" -> Green
        "KURANG BAYAR" -> Gold
        else -> Color(0xFFE53935)
    }
    Surface(
        color = c.copy(alpha = .15f),
        shape = RoundedCornerShape(50),
        modifier = Modifier.padding(2.dp)
    ) {
        Text(
            status,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
            color = c,
            fontWeight = FontWeight.Bold,
            style = MaterialTheme.typography.labelSmall
        )
    }
}

@Composable
fun StudentsScreen(
    students: List<Student>,
    onPay: (Student) -> Unit,
    onEdit: (Student) -> Unit,
    onAdd: () -> Unit
) {
    var q by remember { mutableStateOf("") }
    val list = students.filter {
        it.name.contains(q, true) ||
            it.className.contains(q, true) ||
            it.program.contains(q, true)
    }
    Column {
        Row(
            Modifier.fillMaxWidth().padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(
                    "Data Siswa",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    color = Navy
                )
                Text("${students.size} siswa aktif", color = Color.Gray)
            }
            Button(onClick = onAdd) {
                Icon(Icons.Default.Add, null)
                Spacer(Modifier.width(4.dp))
                Text("Tambah")
            }
        }
        OutlinedTextField(
            value = q,
            onValueChange = { q = it },
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp),
            label = { Text("Cari nama, kelas, atau program") },
            leadingIcon = { Icon(Icons.Default.Search, null) },
            singleLine = true
        )
        LazyColumn(Modifier.padding(10.dp)) {
            items(list) { student ->
                Card(
                    Modifier.fillMaxWidth().padding(vertical = 5.dp),
                    shape = RoundedCornerShape(18.dp)
                ) {
                    ListItem(
                        headlineContent = {
                            Text(student.name, fontWeight = FontWeight.Bold, color = Navy)
                        },
                        supportingContent = {
                            Text("${student.className} • ${student.program}\n${rupiah(student.monthlyFee)} / bulan")
                        },
                        trailingContent = {
                            Row {
                                TextButton(onClick = { onEdit(student) }) { Text("Edit") }
                                Button(onClick = { onPay(student) }) { Text("Bayar") }
                            }
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun PaymentsScreen(students: List<Student>, payments: List<Payment>) {
    val ctx = LocalContext.current
    Column {
        Header("Pembayaran", "Riwayat transaksi & kirim kuitansi gambar")
        LazyColumn {
            items(payments) { payment ->
                val student = students.firstOrNull { it.id == payment.studentId }
                ListItem(
                    headlineContent = {
                        Text(student?.name ?: "Siswa dihapus", fontWeight = FontWeight.Bold)
                    },
                    supportingContent = {
                        Text(
                            "${payment.month} • ${payment.date} • ${payment.method}\n" +
                                payment.receiptNo.ifBlank { "Tanpa nomor kuitansi" }
                        )
                    },
                    trailingContent = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(rupiah(payment.amount), fontWeight = FontWeight.Bold)
                            if (student != null) {
                                IconButton(onClick = { shareReceiptImage(ctx, payment, student) }) {
                                    Icon(Icons.Default.Image, "Kirim kuitansi gambar")
                                }
                            }
                        }
                    }
                )
                HorizontalDivider()
            }
        }
    }
}

@Composable
fun ReportsScreen(students: List<Student>, payments: List<Payment>) {
    val ctx = LocalContext.current
    val m = monthNow()
    val mp = payments.filter { it.month.equals(m, true) }
    fun paid(id: Long): Long = mp.filter { it.studentId == id }.sumOf { it.amount }
    val lunas = students.filter { paid(it.id) >= it.monthlyFee }
    val kurang = students.filter { paid(it.id) in 1 until it.monthlyFee }
    val belum = students.filter { paid(it.id) == 0L }

    Column {
        Header("Laporan Lengkap", "Detail status pembayaran • $m")
        Card(
            Modifier.padding(horizontal = 16.dp).fillMaxWidth(),
            shape = RoundedCornerShape(20.dp)
        ) {
            Row(
                Modifier.padding(14.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Stat("Lunas", lunas.size.toString(), Modifier.weight(1f), Green)
                Stat("Kurang", kurang.size.toString(), Modifier.weight(1f), Gold)
                Stat("Belum", belum.size.toString(), Modifier.weight(1f), Color(0xFFE53935))
            }
        }
        Button(
            onClick = { shareReportPdf(ctx, students, payments, m) },
            modifier = Modifier.fillMaxWidth().padding(16.dp)
        ) {
            Icon(Icons.Default.PictureAsPdf, null)
            Spacer(Modifier.width(8.dp))
            Text("Buat & Bagikan Laporan PDF")
        }
        LazyColumn(Modifier.padding(horizontal = 12.dp)) {
            items(students) { student ->
                val amount = paid(student.id)
                ListItem(
                    headlineContent = {
                        Text(student.name, fontWeight = FontWeight.Bold)
                    },
                    supportingContent = {
                        Text(
                            "${student.className} • ${student.program}\n" +
                                "Tagihan ${rupiah(student.monthlyFee)} • Dibayar ${rupiah(amount)} • " +
                                "Sisa ${rupiah((student.monthlyFee - amount).coerceAtLeast(0))}"
                        )
                    },
                    trailingContent = { StatusBadge(statusFor(student, amount)) }
                )
                HorizontalDivider()
            }
        }
    }
}

@Composable
fun SettingsScreen(programs: List<Program>, vm: MainVm) {
    val ctx = LocalContext.current
    var addProgram by remember { mutableStateOf(false) }
    var showBackup by remember { mutableStateOf(false) }
    var backupText by remember { mutableStateOf("") }
    val create = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        if (uri != null && backupText.isNotBlank()) {
            ctx.contentResolver.openOutputStream(uri)?.use {
                it.write(backupText.toByteArray())
            }
        }
    }
    val open = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            val text = ctx.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
            if (!text.isNullOrBlank()) {
                vm.viewModelScope.launch { vm.restoreJson(text) }
            }
        }
    }
    Column {
        Header("Pengaturan", "Program, tarif, backup data")
        Row(
            Modifier.padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "Program & Tarif",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f)
            )
            Button(onClick = { addProgram = true }) { Text("+ Program") }
        }
        LazyColumn(Modifier.weight(1f).padding(10.dp)) {
            items(programs) { program ->
                Card(
                    Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    ListItem(
                        headlineContent = { Text(program.name, fontWeight = FontWeight.Bold) },
                        supportingContent = { Text("${rupiah(program.fee)} / bulan") },
                        trailingContent = {
                            IconButton(onClick = { vm.deleteProgram(program) }) {
                                Icon(Icons.Default.Delete, "Hapus")
                            }
                        }
                    )
                }
            }
        }
        Button(
            onClick = { vm.exportJson { backupText = it; showBackup = true } },
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)
        ) { Text("Backup Data JSON") }
        OutlinedButton(
            onClick = { open.launch(arrayOf("application/json", "text/plain")) },
            modifier = Modifier.fillMaxWidth().padding(16.dp)
        ) { Text("Restore Data JSON") }
    }
    if (addProgram) {
        ProgramDialog({ addProgram = false }) { name, fee ->
            vm.addProgram(Program(name = name, fee = fee))
            addProgram = false
        }
    }
    if (showBackup) {
        AlertDialog(
            onDismissRequest = { showBackup = false },
            title = { Text("Backup siap") },
            text = { Text("Simpan file backup JSON ke HP.") },
            confirmButton = {
                Button(onClick = {
                    showBackup = false
                    create.launch("backup_bimbel_${today().replace('/', '-')}.json")
                }) { Text("Simpan") }
            },
            dismissButton = {
                TextButton(onClick = { showBackup = false }) { Text("Batal") }
            }
        )
    }
}

@Composable
fun StudentDialog(
    programs: List<Program>,
    existing: Student?,
    onDismiss: () -> Unit,
    onSave: (Student) -> Unit
) {
    var name by remember { mutableStateOf(existing?.name ?: "") }
    var cls by remember { mutableStateOf(existing?.className ?: "") }
    var phone by remember { mutableStateOf(existing?.parentPhone ?: "") }
    var program by remember { mutableStateOf(existing?.program ?: programs.firstOrNull()?.name ?: "Bimbel") }
    var fee by remember {
        mutableStateOf(existing?.monthlyFee?.toString() ?: programs.firstOrNull()?.fee?.toString() ?: "150000")
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existing == null) "Tambah Siswa" else "Edit Siswa") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("Nama siswa") }, singleLine = true)
                OutlinedTextField(cls, { cls = it }, label = { Text("Kelas") }, singleLine = true)
                OutlinedTextField(phone, { phone = it }, label = { Text("No. WhatsApp orang tua") }, singleLine = true)
                OutlinedTextField(program, { program = it }, label = { Text("Program") }, singleLine = true)
                OutlinedTextField(
                    fee,
                    { fee = it.filter(Char::isDigit) },
                    label = { Text("Tarif bulanan") },
                    singleLine = true
                )
            }
        },
        confirmButton = {
            Button(
                enabled = name.isNotBlank() && fee.isNotBlank(),
                onClick = {
                    onSave(
                        Student(
                            existing?.id ?: 0,
                            name,
                            cls,
                            phone,
                            program,
                            fee.toLong()
                        )
                    )
                }
            ) { Text("Simpan") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } }
    )
}

@Composable
fun PaymentDialog(
    s: Student,
    onDismiss: () -> Unit,
    onSave: (Payment) -> Unit
) {
    var month by remember { mutableStateOf(monthNow()) }
    var amount by remember { mutableStateOf(s.monthlyFee.toString()) }
    var method by remember { mutableStateOf("Tunai") }
    var note by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Catat Pembayaran") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(s.name, fontWeight = FontWeight.Bold, color = Navy)
                OutlinedTextField(month, { month = it }, label = { Text("Bulan") }, singleLine = true)
                OutlinedTextField(amount, { amount = it.filter(Char::isDigit) }, label = { Text("Nominal") }, singleLine = true)
                OutlinedTextField(method, { method = it }, label = { Text("Metode: Tunai / Transfer") }, singleLine = true)
                OutlinedTextField(note, { note = it }, label = { Text("Catatan") })
            }
        },
        confirmButton = {
            Button(
                enabled = amount.isNotBlank(),
                onClick = {
                    val no = "KW-${SimpleDateFormat("yyyyMMddHHmmss", Locale.US).format(Date())}"
                    onSave(
                        Payment(
                            studentId = s.id,
                            month = month,
                            amount = amount.toLong(),
                            method = method,
                            date = today(),
                            note = note,
                            receiptNo = no
                        )
                    )
                }
            ) { Text("Simpan & Buat Kuitansi") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } }
    )
}

@Composable
fun ProgramDialog(onDismiss: () -> Unit, onSave: (String, Long) -> Unit) {
    var n by remember { mutableStateOf("") }
    var f by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Tambah Program") },
        text = {
            Column {
                OutlinedTextField(n, { n = it }, label = { Text("Nama program") })
                OutlinedTextField(f, { f = it.filter(Char::isDigit) }, label = { Text("Tarif bulanan") })
            }
        },
        confirmButton = {
            Button(
                enabled = n.isNotBlank() && f.isNotBlank(),
                onClick = { onSave(n, f.toLong()) }
            ) { Text("Simpan") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } }
    )
}

private fun paintText(c:Canvas,text:String,x:Float,y:Float,size:Float,color:Int,bold:Boolean=false){val p=Paint(Paint.ANTI_ALIAS_FLAG).apply{this.color=color;textSize=size;typeface=if(bold)Typeface.DEFAULT_BOLD else Typeface.DEFAULT};c.drawText(text,x,y,p)}
private fun receiptBitmap(context:Context,p:Payment,s:Student):Bitmap{val w=1080;val h=1527;val b=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888);val c=Canvas(b);c.drawColor(Color.WHITE);val navy=Color.rgb(18,59,115);val blue=Color.rgb(22,119,232);val green=Color.rgb(21,154,98);val gold=Color.rgb(255,200,61);val logo=BitmapFactory.decodeResource(context.resources,R.drawable.logo_bimbel);c.drawBitmap(logo,null,Rect(55,55,225,225),Paint(Paint.ANTI_ALIAS_FLAG));paintText(c,"Bimbel Smart",260f,120f,52f,navy,true);paintText(c,"Kreatif Cemerlang",260f,178f,52f,green,true);paintText(c,"Belajar Hari Ini, Masa Depan Lebih Baik",260f,215f,25f,navy,false);paintText(c,"KWITANSI PEMBAYARAN",70f,335f,55f,navy,true);paintText(c,"No. ${p.receiptNo}",720f,390f,26f,navy,true);c.drawRoundRect(50f,410f,1030f,475f,18f,18f,Paint(Paint.ANTI_ALIAS_FLAG).apply{color=Color.rgb(235,244,255)});paintText(c,"PEMBAYARAN BIMBEL",80f,452f,26f,blue,true);val rows=listOf("Telah terima dari" to s.name,"Kelas" to s.className,"Program" to s.program,"Untuk pembayaran" to "Biaya bimbel bulan ${p.month}","Jumlah" to rupiah(p.amount),"Metode" to p.method,"Tanggal" to p.date,"Keterangan" to p.note.ifBlank{"Pembayaran biaya bimbel"});var y=540f;rows.forEachIndexed{i,(a,v)->paintText(c,a,70f,y,27f,navy,false);paintText(c,":",285f,y,27f,navy,false);paintText(c,v,320f,y,29f,if(i==4)green else Color.DKGRAY,i==4);c.drawLine(70f,y+18f,1000f,y+18f,Paint(Paint.ANTI_ALIAS_FLAG).apply{color=Color.LTGRAY;strokeWidth=1f});y+=82f};c.drawRoundRect(55f,1230f,1025f,1370f,25f,25f,Paint(Paint.ANTI_ALIAS_FLAG).apply{color=Color.rgb(241,250,246)});paintText(c,"Terima kasih atas kepercayaannya.",85f,1280f,30f,green,true);paintText(c,"Semoga ilmu yang didapatkan menjadi berkah.",85f,1325f,24f,navy,false);paintText(c,"Hormat kami,",760f,1390f,22f,navy,false);paintText(c,"Bimbel Smart Kreatif Cemerlang",650f,1440f,23f,navy,true);paintText(c,"Pangkalan Kerinci, ${p.date}",70f,1475f,20f,Color.GRAY,false);c.drawRect(0f,0f,w.toFloat(),18f,Paint().apply{color=gold});c.drawRect(0f,h-18f,w.toFloat(),h.toFloat(),Paint().apply{color=navy});return b}

fun shareReceiptImage(context:Context,p:Payment,s:Student){val file=File(context.cacheDir,"kwitansi_${p.receiptNo}.png");FileOutputStream(file).use{receiptBitmap(context,p,s).compress(Bitmap.CompressFormat.PNG,100,it)};val uri=FileProvider.getUriForFile(context,context.packageName+".fileprovider",file);val text="Kwitansi pembayaran Bimbel Smart Kreatif Cemerlang\n${s.name} • ${p.month}\n${rupiah(p.amount)}";val intent=Intent(Intent.ACTION_SEND).apply{type="image/png";putExtra(Intent.EXTRA_STREAM,uri);putExtra(Intent.EXTRA_TEXT,text);addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)};try{intent.setPackage("com.whatsapp");context.startActivity(intent)}catch(_:Exception){intent.setPackage(null);context.startActivity(Intent.createChooser(intent,"Bagikan kuitansi"))}}

fun shareReportPdf(context:Context,students:List<Student>,payments:List<Payment>,month:String){val file=File(context.cacheDir,"laporan_pembayaran_${month.replace(" ","_")}.pdf");val doc=PdfDocument();val pageW=595;val pageH=842;var pageNo=1;var page=doc.startPage(PdfDocument.PageInfo.Builder(pageW,pageH,pageNo).create());var c=page.canvas;val navy=Color.rgb(18,59,115);val green=Color.rgb(21,154,98);val red=Color.rgb(229,57,53);paintText(c,"BIMBEL SMART KREATIF CEMERLANG",35f,45f,20f,navy,true);paintText(c,"LAPORAN PEMBAYARAN SISWA",35f,72f,18f,green,true);paintText(c,"Bulan: $month",35f,100f,13f,Color.DKGRAY);var y=135f;paintText(c,"No",35f,y,11f,navy,true);paintText(c,"Nama Siswa",55f,y,11f,navy,true);paintText(c,"Program",190f,y,11f,navy,true);paintText(c,"Tagihan",290f,y,11f,navy,true);paintText(c,"Dibayar",365f,y,11f,navy,true);paintText(c,"Sisa",435f,y,11f,navy,true);paintText(c,"Status",490f,y,11f,navy,true);y+=22;val mp=payments.filter{it.month.equals(month,true)};students.forEachIndexed{idx,s->if(y>790f){doc.finishPage(page);pageNo++;page=doc.startPage(PdfDocument.PageInfo.Builder(pageW,pageH,pageNo).create());c=page.canvas;y=40f};val paid=mp.filter{it.studentId==s.id}.sumOf{it.amount};val rem=(s.monthlyFee-paid).coerceAtLeast(0);val st=statusFor(s,paid);paintText(c,"${idx+1}",35f,y,9f,Color.DKGRAY);paintText(c,s.name.take(20),55f,y,9f,Color.DKGRAY);paintText(c,s.program.take(14),190f,y,9f,Color.DKGRAY);paintText(c,rupiah(s.monthlyFee),290f,y,9f,Color.DKGRAY);paintText(c,rupiah(paid),365f,y,9f,Color.DKGRAY);paintText(c,rupiah(rem),435f,y,9f,Color.DKGRAY);paintText(c,st,490f,y,8f,if(st=="LUNAS")green else if(st=="KURANG BAYAR")Color.rgb(210,150,0) else red,true);y+=20};doc.finishPage(page);FileOutputStream(file).use{doc.writeTo(it)};doc.close();val uri=FileProvider.getUriForFile(context,context.packageName+".fileprovider",file);val i=Intent(Intent.ACTION_SEND).apply{type="application/pdf";putExtra(Intent.EXTRA_STREAM,uri);putExtra(Intent.EXTRA_TEXT,"Laporan pembayaran Bimbel Smart Kreatif Cemerlang - $month");addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)};context.startActivity(Intent.createChooser(i,"Bagikan laporan PDF"))}

class MainActivity:ComponentActivity(){override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);setContent{MaterialTheme(colorScheme=lightColorScheme(primary=Navy,secondary=Green,background=Bg,surface=Color.White)){App()}}}}
