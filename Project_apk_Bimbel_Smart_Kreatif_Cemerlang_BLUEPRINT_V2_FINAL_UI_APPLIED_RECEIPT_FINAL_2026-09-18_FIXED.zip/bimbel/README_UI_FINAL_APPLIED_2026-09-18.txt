PROJECT APK BIMBEL SMART KREATIF CEMERLANG
FINAL UI PATCH APPLIED - 18 SEPTEMBER 2026

PONDASI:
Project_apk_Bimbel_Smart_Kreatif_Cemerlang_BLUEPRINT_V2_FINAL_2026-09-18.zip

PERUBAHAN YANG DITERAPKAN:
1. DASHBOARD
- Tampilan dashboard diterapkan mengikuti tampilan final yang disetujui.
- Branding/logo dibuat jelas pada hero background.
- Statistik Total Siswa, Sudah Bayar, Kurang Bayar, Belum Bayar dipertahankan beserta fungsi kliknya.
- Bulan aktif dan navigasi bulan tetap berfungsi.
- Peringatan pergantian bulan dan kartu kutipan tetap dipertahankan.

2. DATA SISWA
- Branding/logo dan tulisan Bimbel diperjelas pada background.
- Scroll horizontal kartu nama program dihilangkan.
- Kolom pencarian dan tombol Tambah ditempatkan di area background/header.
- Tombol Tambah diperbaiki agar teks terbaca jelas.
- Fungsi pencarian, program, tambah/edit/hapus siswa dan navigasi tetap dipertahankan.

3. BAYAR
- Branding/logo dan judul Pembayaran Siswa diperjelas pada background.
- Kolom pencarian ditempatkan di area background/header.
- Bagian Bulan Aktif di halaman utama Bayar dihilangkan sesuai perintah.
- Filter Semua/Lunas/Kurang Bayar/Belum Bayar tetap berfungsi.
- Daftar program dan alur menuju daftar siswa/detail pembayaran tetap dipertahankan.

4. DETAIL PEMBAYARAN
- Tombol Bagikan Kuitansi diberi jarak yang jelas dari tombol Edit Pembayaran.
- Fungsi kuitansi PNG dan fungsi pembayaran lainnya tidak diubah.

5. LAPORAN
- Tampilan laporan diterapkan/dirapikan mengikuti desain final yang disetujui.
- Ringkasan pemasukan, pengeluaran, laba bersih, bulan aktif, daftar transaksi dan tombol tambah tetap berfungsi.
- Fitur edit/delete/save dan pembuatan PDF tetap dipertahankan.

6. LAINNYA
- Tampilan header/branding mengikuti desain final yang disetujui.
- Ikon di sebelah kiri setiap menu dibuat berwarna dan berbeda sesuai tampilan final.
- Program & Tarif, Pemberitahuan, Keamanan Aplikasi, Backup & Restore, Tentang Aplikasi tetap menggunakan fungsi yang sudah ada.

BATASAN:
- Tidak mengubah database/schema.
- Tidak mengubah sistem PIN.
- Tidak menghapus atau mengubah fungsi hapus siswa.
- Tidak mengubah logic pembayaran, status pembayaran, receipt, laporan, backup, atau navigasi selain perubahan UI yang disebutkan di atas.
- Source tetap menggunakan pondasi yang sama, bukan dibuat ulang dari nol.
