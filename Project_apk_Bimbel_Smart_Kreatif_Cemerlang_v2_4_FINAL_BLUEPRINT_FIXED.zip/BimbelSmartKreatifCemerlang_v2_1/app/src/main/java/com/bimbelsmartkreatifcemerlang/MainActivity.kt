package com.bimbelsmartkreatifcemerlang

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import androidx.core.content.FileProvider
import java.io.File
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.room.*
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.*

@Entity(tableName = "students")
data class Student(@PrimaryKey(autoGenerate = true) val id: Long = 0, val name: String, val className: String, val parentPhone: String, val program: String, val monthlyFee: Long, val active: Boolean = true)
@Entity(tableName = "payments", indices = [Index(value = ["studentId", "month"], unique = true)])
data class Payment(@PrimaryKey(autoGenerate = true) val id: Long = 0, val studentId: Long, val month: String, val amount: Long, val method: String, val date: String, val note: String, val receiptNo: String = "")
@Entity(tableName = "programs")
data class Program(@PrimaryKey(autoGenerate = true) val id: Long = 0, val name: String, val fee: Long)
@Entity(tableName = "expenses")
data class Expense(@PrimaryKey(autoGenerate = true) val id: Long = 0, val month: String, val date: String, val title: String, val category: String, val amount: Long, val note: String = "")
@Entity(tableName = "incomes")
data class Income(@PrimaryKey(autoGenerate = true) val id: Long = 0, val month: String, val date: String, val title: String, val category: String, val amount: Long, val note: String = "")

@Dao interface StudentDao { @Query("SELECT * FROM students WHERE active = 1 ORDER BY program, name") fun active(): Flow<List<Student>>; @Insert suspend fun insert(s: Student): Long; @Update suspend fun update(s: Student); @Delete suspend fun delete(s: Student) }
@Dao interface PaymentDao { @Query("SELECT * FROM payments ORDER BY id DESC") fun all(): Flow<List<Payment>>; @Query("SELECT * FROM payments WHERE studentId=:studentId AND month=:month LIMIT 1") suspend fun find(studentId:Long,month:String):Payment?; @Insert suspend fun insert(p:Payment):Long; @Update suspend fun update(p:Payment); @Delete suspend fun delete(p:Payment) }
@Dao interface ProgramDao { @Query("SELECT * FROM programs ORDER BY name") fun all():Flow<List<Program>>; @Insert suspend fun insert(p:Program); @Delete suspend fun delete(p:Program) }
@Dao interface ExpenseDao { @Query("SELECT * FROM expenses ORDER BY id DESC") fun all():Flow<List<Expense>>; @Insert suspend fun insert(e:Expense):Long; @Delete suspend fun delete(e:Expense) }
@Dao interface IncomeDao { @Query("SELECT * FROM incomes ORDER BY id DESC") fun all():Flow<List<Income>>; @Insert suspend fun insert(i:Income):Long; @Delete suspend fun delete(i:Income) }

@Database(entities=[Student::class,Payment::class,Program::class,Expense::class,Income::class],version=4,exportSchema=false)
abstract class AppDb:RoomDatabase(){ abstract fun students():StudentDao; abstract fun payments():PaymentDao; abstract fun programs():ProgramDao; abstract fun expenses():ExpenseDao; abstract fun incomes():IncomeDao
 companion object { @Volatile private var INSTANCE:AppDb?=null; fun get(c:Context):AppDb=INSTANCE?: synchronized(this){ INSTANCE?:Room.databaseBuilder(c.applicationContext,AppDb::class.java,"bimbel.db").addMigrations(MIGRATION_2_3, MIGRATION_3_4).build().also{INSTANCE=it} } }
}
val MIGRATION_3_4=object:Migration(3,4){override fun migrate(db:SupportSQLiteDatabase){db.execSQL("CREATE TABLE IF NOT EXISTS incomes (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, month TEXT NOT NULL, date TEXT NOT NULL, title TEXT NOT NULL, category TEXT NOT NULL, amount INTEGER NOT NULL, note TEXT NOT NULL)")}}
val MIGRATION_2_3=object:Migration(2,3){override fun migrate(db:SupportSQLiteDatabase){db.execSQL("CREATE TABLE IF NOT EXISTS expenses (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, month TEXT NOT NULL, date TEXT NOT NULL, title TEXT NOT NULL, category TEXT NOT NULL, amount INTEGER NOT NULL, note TEXT NOT NULL)");db.execSQL("CREATE TEMP TABLE payment_keep AS SELECT MIN(p.id) AS id,p.studentId,p.month,CASE WHEN SUM(p.amount)>COALESCE(s.monthlyFee,SUM(p.amount)) THEN COALESCE(s.monthlyFee,SUM(p.amount)) ELSE SUM(p.amount) END AS amount,MAX(p.method) AS method,MAX(p.date) AS date,MAX(p.note) AS note,MAX(p.receiptNo) AS receiptNo FROM payments p LEFT JOIN students s ON s.id=p.studentId GROUP BY p.studentId,p.month");db.execSQL("DELETE FROM payments");db.execSQL("INSERT INTO payments(id,studentId,month,amount,method,date,note,receiptNo) SELECT id,studentId,month,amount,method,date,note,receiptNo FROM payment_keep");db.execSQL("DROP TABLE payment_keep");db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_payments_studentId_month ON payments(studentId,month)")}}

fun rupiah(n:Long)=NumberFormat.getCurrencyInstance(Locale("id","ID")).format(n).replace(",00","")
fun monthNow()=SimpleDateFormat("MMMM yyyy",Locale("id","ID")).format(Date())
fun today()=SimpleDateFormat("dd/MM/yyyy",Locale("id","ID")).format(Date())
fun normalizePhone(raw:String):String{val p=raw.filter(Char::isDigit);return when{p.startsWith("62")->p;p.startsWith("0")->"62"+p.drop(1);else->p}}
fun daysRemainingInMonth():Int{val c=Calendar.getInstance();return c.getActualMaximum(Calendar.DAY_OF_MONTH)-c.get(Calendar.DAY_OF_MONTH)}
fun isMonthWarning()=daysRemainingInMonth() in 0..7

class MainVm(ctx:Context):ViewModel(){private val db=AppDb.get(ctx);val students=db.students().active();val payments=db.payments().all();val programs=db.programs().all();val expenses=db.expenses().all();val incomes=db.incomes().all()
 init{viewModelScope.launch{if(db.programs().all().first().isEmpty())listOf(Program(name="Calistung",fee=150000),Program(name="Calistung 2",fee=150000),Program(name="Iqro / Al-Qur'an",fee=100000),Program(name="Bimbel",fee=150000),Program(name="English",fee=150000)).forEach{db.programs().insert(it)}}}
 fun addStudent(s:Student)=viewModelScope.launch{db.students().insert(s)};fun updateStudent(s:Student)=viewModelScope.launch{db.students().update(s)};fun deleteStudent(s:Student)=viewModelScope.launch{db.students().delete(s)}
 fun recordPayment(s:Student,month:String,amount:Long,method:String,note:String,onDone:()->Unit={})=viewModelScope.launch{val old=db.payments().find(s.id,month);if(old==null){db.payments().insert(Payment(studentId=s.id,month=month,amount=amount,method=method,date=today(),note=note,receiptNo="KW-"+SimpleDateFormat("yyyyMMddHHmmss",Locale.US).format(Date())))}else{val total=(old.amount+amount).coerceAtMost(s.monthlyFee);if(total<=old.amount)return@launch;db.payments().update(old.copy(amount=total,method=method,date=today(),note=note))};onDone()}
 fun deletePayment(p:Payment)=viewModelScope.launch{db.payments().delete(p)};fun addIncome(i:Income)=viewModelScope.launch{db.incomes().insert(i)};fun deleteIncome(i:Income)=viewModelScope.launch{db.incomes().delete(i)};fun addProgram(p:Program)=viewModelScope.launch{db.programs().insert(p)};fun deleteProgram(p:Program)=viewModelScope.launch{db.programs().delete(p)};fun addExpense(e:Expense)=viewModelScope.launch{db.expenses().insert(e)};fun deleteExpense(e:Expense)=viewModelScope.launch{db.expenses().delete(e)}
 fun exportJson(onDone:(String)->Unit)=viewModelScope.launch{val ss=db.students().activeOnce();val ps=db.payments().allOnce();val gs=db.programs().allOnce();val es=db.expenses().allOnce();val ins=db.incomes().allOnce();val o=JSONObject().put("version",4).put("exportedAt",today());o.put("students",JSONArray().apply{ss.forEach{put(JSONObject().put("id",it.id).put("name",it.name).put("className",it.className).put("parentPhone",it.parentPhone).put("program",it.program).put("monthlyFee",it.monthlyFee).put("active",it.active))}});o.put("payments",JSONArray().apply{ps.forEach{put(JSONObject().put("id",it.id).put("studentId",it.studentId).put("month",it.month).put("amount",it.amount).put("method",it.method).put("date",it.date).put("note",it.note).put("receiptNo",it.receiptNo))}});o.put("programs",JSONArray().apply{gs.forEach{put(JSONObject().put("id",it.id).put("name",it.name).put("fee",it.fee))}});o.put("expenses",JSONArray().apply{es.forEach{put(JSONObject().put("id",it.id).put("month",it.month).put("date",it.date).put("title",it.title).put("category",it.category).put("amount",it.amount).put("note",it.note))}});o.put("incomes",JSONArray().apply{ins.forEach{put(JSONObject().put("id",it.id).put("month",it.month).put("date",it.date).put("title",it.title).put("category",it.category).put("amount",it.amount).put("note",it.note))}});onDone(o.toString(2))}
 suspend fun restoreJson(text:String){val o=JSONObject(text);val ss=o.optJSONArray("students")?:JSONArray();val gs=o.optJSONArray("programs")?:JSONArray();val ps=o.optJSONArray("payments")?:JSONArray();val es=o.optJSONArray("expenses")?:JSONArray();val ins=o.optJSONArray("incomes")?:JSONArray();for(i in 0 until gs.length()){val x=gs.getJSONObject(i);db.programs().insert(Program(x.optLong("id",0),x.optString("name"),x.optLong("fee")))};for(i in 0 until ss.length()){val x=ss.getJSONObject(i);db.students().insert(Student(x.optLong("id",0),x.optString("name"),x.optString("className"),x.optString("parentPhone"),x.optString("program"),x.optLong("monthlyFee"),x.optBoolean("active",true)))};for(i in 0 until ps.length()){val x=ps.getJSONObject(i);runCatching{db.payments().insert(Payment(x.optLong("id",0),x.optLong("studentId"),x.optString("month"),x.optLong("amount"),x.optString("method"),x.optString("date"),x.optString("note"),x.optString("receiptNo")))}};for(i in 0 until es.length()){val x=es.getJSONObject(i);db.expenses().insert(Expense(x.optLong("id",0),x.optString("month"),x.optString("date"),x.optString("title"),x.optString("category"),x.optLong("amount"),x.optString("note")))};for(i in 0 until ins.length()){val x=ins.getJSONObject(i);db.incomes().insert(Income(x.optLong("id",0),x.optString("month"),x.optString("date"),x.optString("title"),x.optString("category"),x.optLong("amount"),x.optString("note")))}}
}
suspend fun StudentDao.activeOnce()=active().first();suspend fun PaymentDao.allOnce()=all().first();suspend fun ProgramDao.allOnce()=all().first();suspend fun ExpenseDao.allOnce()=all().first();suspend fun IncomeDao.allOnce()=all().first()

private val Navy=Color(0xFF124D86);private val Navy2=Color(0xFF0B6FBA);private val Green=Color(0xFF18A66A);private val Yellow=Color(0xFFF2B632);private val Red=Color(0xFFE44747);private val Bg=Color(0xFFF3F7FC);private val SoftBlue=Color(0xFFE7F2FC);private val SoftGreen=Color(0xFFE5F8F0);private val SoftRed=Color(0xFFFFECEC);private val SoftYellow=Color(0xFFFFF6DD);private val SoftPurple=Color(0xFFF1EAFE)

private val navItems=listOf(Triple(Icons.Default.Home,"Beranda",0),Triple(Icons.Default.People,"Siswa",1),Triple(Icons.Default.Payments,"Bayar",2),Triple(Icons.Default.BarChart,"Laporan",3),Triple(Icons.Default.MoreHoriz,"Lainnya",4))

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun App(){val context=androidx.compose.ui.platform.LocalContext.current.applicationContext;val vm:MainVm=viewModel(factory=object:androidx.lifecycle.ViewModelProvider.Factory{override fun<T:ViewModel>create(c:Class<T>):T=MainVm(context) as T});var tab by remember{mutableIntStateOf(0)};var studentDialog by remember{mutableStateOf(false)};var editing by remember{mutableStateOf<Student?>(null)};var payStudent by remember{mutableStateOf<Student?>(null)};var paymentFilter by remember{mutableStateOf("Semua")};var showSplash by remember{mutableStateOf(true)};val students by vm.students.collectAsState(emptyList());val payments by vm.payments.collectAsState(emptyList());val programs by vm.programs.collectAsState(emptyList());val expenses by vm.expenses.collectAsState(emptyList());val incomes by vm.incomes.collectAsState(emptyList())
 LaunchedEffect(Unit){kotlinx.coroutines.delay(1200);showSplash=false}
 MaterialTheme(colorScheme=lightColorScheme(primary=Navy,secondary=Green,background=Bg,surface=Color.White,error=Red)){if(showSplash){Splash()}else{Scaffold(containerColor=Bg,topBar={if(tab!=0)SimpleTopBar(title=when(tab){1->"Data Siswa";2->"Pembayaran";3->"Laporan";else->"Lainnya"})},bottomBar={NavigationBar(containerColor=Color.White,tonalElevation=8.dp){navItems.forEach{(icon,label,index)->NavigationBarItem(selected=tab==index,onClick={tab=index},icon={Icon(icon,null)},label={Text(label,fontSize=10.sp)},colors=NavigationBarItemDefaults.colors(selectedIconColor=Navy,selectedTextColor=Navy,indicatorColor=SoftBlue))}}}){pad->Box(Modifier.padding(pad).fillMaxSize()){when(tab){0->Dashboard(students,payments,expenses,incomes){status->paymentFilter=status;tab=2};1->StudentsScreen(students,programs,{editing=it;studentDialog=true},{editing=null;studentDialog=true});2->PaymentsScreen(students,payments,paymentFilter,{paymentFilter="Semua"},{status->paymentFilter=status},{payStudent=it},{vm.deletePayment(it)});3->ReportsScreen(payments,expenses,incomes,vm);else->MoreScreen(programs,vm)}}}}
 if(studentDialog)StudentDialog(programs,editing,{studentDialog=false;editing=null}){s->if(s.id==0L)vm.addStudent(s)else vm.updateStudent(s);studentDialog=false;editing=null};payStudent?.let{s->PaymentDialog(s,payments.find{it.studentId==s.id&&it.month.equals(monthNow(),true)},{payStudent=null}){amount,method,note->vm.recordPayment(s,monthNow(),amount,method,note){payStudent=null}}}}
}

@Composable fun Splash(){Box(Modifier.fillMaxSize().background(Color.White),contentAlignment=Alignment.Center){Column(horizontalAlignment=Alignment.CenterHorizontally){Image(painterResource(R.drawable.logo_bimbel),"Logo",Modifier.size(128.dp).clip(CircleShape));Spacer(Modifier.height(18.dp));Text("Bimbel Smart",fontSize=29.sp,fontWeight=FontWeight.Bold,color=Navy);Text("Kreatif Cemerlang",fontSize=25.sp,fontWeight=FontWeight.Bold,color=Green);Spacer(Modifier.height(10.dp));Text("Belajar Hari Ini, Masa Depan Lebih Baik",color=Color.Gray,fontSize=14.sp);Spacer(Modifier.height(28.dp));LinearProgressIndicator(Modifier.width(100.dp),color=Navy,trackColor=SoftBlue);Spacer(Modifier.height(8.dp));Text("Memuat aplikasi…",fontSize=12.sp,color=Color.Gray)}}}
@OptIn(ExperimentalMaterial3Api::class) @Composable fun SimpleTopBar(title:String){CenterAlignedTopAppBar(title={Text(title,fontWeight=FontWeight.Bold,color=Navy,fontSize=20.sp)},navigationIcon={Icon(Icons.Default.School,null,tint=Navy)},actions={IconButton(onClick={}){Icon(Icons.Default.NotificationsNone,null,tint=Navy)}})}

@Composable
fun Dashboard(
    students: List<Student>,
    payments: List<Payment>,
    expenses: List<Expense>,
    incomes: List<Income>,
    onStatus: (String) -> Unit
) {
    val m = monthNow()
    val mp = payments.filter { it.month.equals(m, true) }
    val me = expenses.filter { it.month.equals(m, true) }
    val mi = incomes.filter { it.month.equals(m, true) }
    fun paid(id: Long): Long = mp.filter { it.studentId == id }.sumOf { it.amount }
    val income = mp.sumOf { it.amount } + mi.sumOf { it.amount }
    val expense = me.sumOf { it.amount }
    val net = income - expense
    val lunas = students.count { paid(it.id) >= it.monthlyFee }
    val kurang = students.count { val x = paid(it.id); x in 1 until it.monthlyFee }
    val belum = students.count { paid(it.id) == 0L }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 20.dp)) {
        item { DashboardHeader() }
        item { MonthPill(m) }
        item {
            if (isMonthWarning()) {
                WarningCard(belum, kurang) { onStatus("Belum Bayar") }
            }
        }
        item { FinanceHero(income, expense, net) }
        item {
            Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 4.dp)) {
                StatCard("Total Siswa", students.size.toString(), Icons.Default.Groups, Navy, SoftBlue) {}
                StatCard("Sudah Bayar", lunas.toString(), Icons.Default.CheckCircle, Green, SoftGreen) { onStatus("Lunas") }
            }
        }
        item {
            Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 4.dp)) {
                StatCard("Kurang Bayar", kurang.toString(), Icons.Default.Schedule, Yellow, SoftYellow) { onStatus("Kurang Bayar") }
                StatCard("Belum Bayar", belum.toString(), Icons.Default.Cancel, Red, SoftRed) { onStatus("Belum Bayar") }
            }
        }
    }
}

@Composable fun DashboardHeader(){Row(Modifier.fillMaxWidth().padding(horizontal=18.dp,vertical=12.dp),verticalAlignment=Alignment.CenterVertically){Image(painterResource(R.drawable.logo_bimbel),"Logo",Modifier.size(48.dp).clip(RoundedCornerShape(14.dp)));Spacer(Modifier.width(10.dp));Column(Modifier.weight(1f)){Text("Bimbel Smart",fontWeight=FontWeight.Bold,color=Navy,fontSize=17.sp);Text("Kreatif Cemerlang",fontWeight=FontWeight.Bold,color=Green,fontSize=16.sp);Text("Selamat pagi, Admin 👋",color=Color.Gray,fontSize=12.sp)};Surface(color=SoftBlue,shape=CircleShape){IconButton(onClick={}){Icon(Icons.Default.Notifications,null,tint=Navy)}}}}
@Composable fun MonthPill(month:String){Card(Modifier.fillMaxWidth().padding(horizontal=18.dp),shape=RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(Color.White),elevation=CardDefaults.cardElevation(1.dp)){Row(Modifier.padding(12.dp),verticalAlignment=Alignment.CenterVertically){Icon(Icons.Default.CalendarMonth,null,tint=Navy);Spacer(Modifier.width(9.dp));Column(Modifier.weight(1f)){Text("Bulan Aktif",fontSize=11.sp,color=Color.Gray);Text(month,fontWeight=FontWeight.Bold,color=Navy,fontSize=16.sp)};Icon(Icons.Default.ChevronRight,null,tint=Navy)}}}
@Composable fun WarningCard(belum:Int,kurang:Int,onStatus:()->Unit){Card(Modifier.fillMaxWidth().padding(12.dp),shape=RoundedCornerShape(22.dp),colors=CardDefaults.cardColors(SoftYellow)){Row(Modifier.padding(15.dp),verticalAlignment=Alignment.CenterVertically){Surface(color=Yellow.copy(alpha=.18f),shape=CircleShape){Icon(Icons.Default.NotificationsActive,null,tint=Yellow,modifier=Modifier.padding(10.dp))};Spacer(Modifier.width(12.dp));Column(Modifier.weight(1f)){Text("${daysRemainingInMonth()} hari lagi bulan berganti!",fontWeight=FontWeight.Bold,color=Red,fontSize=17.sp);Text("$belum belum bayar • $kurang kurang bayar",fontSize=12.sp,color=Color(0xFF765C20));Spacer(Modifier.height(8.dp));TextButton(onClick={onStatus}){Text("Lihat sekarang →",color=Navy,fontWeight=FontWeight.Bold)}}}}}
@Composable fun FinanceHero(income:Long,expense:Long,net:Long){Card(Modifier.fillMaxWidth().padding(12.dp),shape=RoundedCornerShape(24.dp),colors=CardDefaults.cardColors(Navy)){Column(Modifier.padding(18.dp)){Text("Ringkasan keuangan",color=Color.White.copy(alpha=.8f),fontSize=12.sp);Text("Pendapatan bersih",color=Color.White,fontSize=14.sp);Text(rupiah(net),color=Color.White,fontSize=26.sp,fontWeight=FontWeight.Bold);Spacer(Modifier.height(12.dp));Row(Modifier.fillMaxWidth()){FinanceMini("Pemasukan",rupiah(income),Green,Modifier.weight(1f));FinanceMini("Pengeluaran",rupiah(expense),Red,Modifier.weight(1f))}}}}
@Composable fun FinanceMini(label:String,value:String,accent:Color,modifier:Modifier){Column(modifier){Text(label,color=Color.White.copy(alpha=.7f),fontSize=11.sp);Text(value,color=Color.White,fontWeight=FontWeight.Bold,fontSize=14.sp)}}
@Composable fun RowScope.StatCard(title:String,value:String,icon:ImageVector,accent:Color,bg:Color,onClick:()->Unit){Card(Modifier.weight(1f).padding(5.dp).clickable(onClick=onClick),shape=RoundedCornerShape(20.dp),colors=CardDefaults.cardColors(Color.White),elevation=CardDefaults.cardElevation(1.dp)){Column(Modifier.padding(14.dp)){Surface(color=bg,shape=CircleShape){Icon(icon,null,tint=accent,modifier=Modifier.padding(8.dp).size(18.dp))};Spacer(Modifier.height(9.dp));Text(title,fontSize=11.sp,color=Color.Gray);Text(value,fontSize=25.sp,fontWeight=FontWeight.Bold,color=accent)}}}
data class ProgramColors(val bg:Color,val accent:Color,val iconBg:Color)
fun programColors(name:String):ProgramColors{val n=name.lowercase(Locale.getDefault());return when{n.contains("bimbel")->ProgramColors(Color(0xFFE3F6EA),Color(0xFF2E9B61),Color(0xFFCDEFD9));n.contains("calistung")->ProgramColors(Color(0xFFFFF2CC),Color(0xFFB98200),Color(0xFFFFE6A3));n.contains("iqro")||n.contains("qur")||n.contains("al-qur")->ProgramColors(Color(0xFFE0F2FF),Color(0xFF2184C5),Color(0xFFC8E8FA));n.contains("english")->ProgramColors(Color(0xFFFCE4F1),Color(0xFFC44D91),Color(0xFFF7C9E2));n.contains("komputer")||n.contains("computer")->ProgramColors(Color(0xFFEDE4FF),Color(0xFF7551B5),Color(0xFFDCCEFF));else->{val palette=listOf(ProgramColors(Color(0xFFE8F5E9),Color(0xFF3A8F5D),Color(0xFFD2EEDB)),ProgramColors(Color(0xFFFFF3D6),Color(0xFFB68116),Color(0xFFFFE5A3)),ProgramColors(Color(0xFFE4F3FB),Color(0xFF2B82B8),Color(0xFFC9E8F7)),ProgramColors(Color(0xFFFBE5F2),Color(0xFFC24D8C),Color(0xFFF5CBE1)),ProgramColors(Color(0xFFEDE5FB),Color(0xFF7453AD),Color(0xFFDCD0F5)));palette[kotlin.math.abs(name.hashCode())%palette.size]}}}
@Composable fun SectionTitle(title:String,action:String?=null){val c=programColors(title);Card(Modifier.fillMaxWidth().padding(horizontal=12.dp,vertical=5.dp),shape=RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(c.bg)){Row(Modifier.padding(horizontal=14.dp,vertical=10.dp),verticalAlignment=Alignment.CenterVertically){Surface(color=c.iconBg,shape=CircleShape){Icon(Icons.Default.Groups,null,tint=c.accent,modifier=Modifier.padding(7.dp).size(17.dp))};Spacer(Modifier.width(9.dp));Text(title,fontWeight=FontWeight.Bold,color=Navy,fontSize=16.sp,modifier=Modifier.weight(1f));if(action!=null)Text(action,color=c.accent,fontSize=11.sp,fontWeight=FontWeight.Bold)}}}
@Composable fun ProgramCard(name:String,total:Int,lunas:Int,kurang:Int,belum:Int){val c=programColors(name);val icon=when{name.contains("English",true)->Icons.Default.Language;name.contains("Iqro",true)->Icons.Default.MenuBook;else->Icons.Default.Groups};Card(Modifier.fillMaxWidth().padding(horizontal=12.dp,vertical=5.dp),shape=RoundedCornerShape(19.dp),colors=CardDefaults.cardColors(c.bg),elevation=CardDefaults.cardElevation(1.dp)){Row(Modifier.padding(13.dp),verticalAlignment=Alignment.CenterVertically){Surface(color=c.iconBg,shape=CircleShape){Icon(icon,null,tint=c.accent,modifier=Modifier.padding(10.dp))};Spacer(Modifier.width(11.dp));Column(Modifier.weight(1f)){Text(name,fontWeight=FontWeight.Bold,color=Navy);Text("$total siswa",fontSize=11.sp,color=Color.Gray);Spacer(Modifier.height(4.dp));Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){TinyStatus("$lunas Lunas",Green);if(kurang>0)TinyStatus("$kurang Kurang",Yellow);if(belum>0)TinyStatus("$belum Belum",Red)}};Icon(Icons.Default.ChevronRight,null,tint=c.accent)}}}
@Composable fun TinyStatus(text:String,color:Color){Surface(color=color.copy(alpha=.12f),shape=RoundedCornerShape(20.dp)){Text(text,color=color,fontSize=9.sp,fontWeight=FontWeight.Bold,modifier=Modifier.padding(horizontal=7.dp,vertical=3.dp))}}

@Composable fun StudentsScreen(students:List<Student>,programs:List<Program>,onEdit:(Student)->Unit,onAdd:()->Unit){var q by remember{mutableStateOf("")};var programFilter by remember{mutableStateOf("Semua")};val filtered=students.filter{it.name.contains(q,true)||it.className.contains(q,true)||it.program.contains(q,true)}.filter{programFilter=="Semua"||it.program==programFilter};val programNames=(programs.map{it.name}+students.map{it.program}).distinct().sorted();LazyColumn(Modifier.fillMaxSize(),contentPadding=PaddingValues(bottom=20.dp)){item{Row(Modifier.fillMaxWidth().padding(18.dp,14.dp,18.dp,8.dp),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text("Data Siswa",fontSize=23.sp,fontWeight=FontWeight.Bold,color=Navy);Text("${students.size} siswa aktif",fontSize=12.sp,color=Color.Gray)};Button(onClick=onAdd,shape=RoundedCornerShape(13.dp),colors=ButtonDefaults.buttonColors(Navy)){Icon(Icons.Default.Add,null);Spacer(Modifier.width(4.dp));Text("Tambah")}};OutlinedTextField(q,{q=it},Modifier.fillMaxWidth().padding(horizontal=14.dp),placeholder={Text("Cari nama siswa...")},leadingIcon={Icon(Icons.Default.Search,null)},singleLine=true,shape=RoundedCornerShape(15.dp));Row(Modifier.fillMaxWidth().padding(horizontal=14.dp,vertical=7.dp),horizontalArrangement=Arrangement.spacedBy(6.dp)){FilterChip(selected=programFilter=="Semua",onClick={programFilter="Semua"},label={Text("Semua")});programNames.forEach{p->FilterChip(selected=programFilter==p,onClick={programFilter=p},label={Text(p,maxLines=1,overflow=TextOverflow.Ellipsis)})}}};val groups=filtered.groupBy{it.program};groups.forEach{(program,list)->item{SectionTitle(program,"${list.size} siswa")};items(list){s->StudentDataCard(s,onEdit)}}}}
@Composable fun StudentDataCard(s:Student,onEdit:(Student)->Unit){val c=programColors(s.program);Card(Modifier.fillMaxWidth().padding(horizontal=12.dp,vertical=4.dp),shape=RoundedCornerShape(19.dp),colors=CardDefaults.cardColors(c.bg),elevation=CardDefaults.cardElevation(1.dp)){ListItem(leadingContent={Surface(color=c.iconBg,shape=CircleShape){Avatar(s.name)}},headlineContent={Text(s.name,fontWeight=FontWeight.Bold,color=Navy,fontSize=16.sp)},supportingContent={Text(s.className,fontSize=11.sp,color=Color.Gray)},trailingContent={TextButton(onClick={onEdit(s)}){Text("Edit",fontSize=10.sp,color=c.accent)}})}}

@Composable fun Avatar(name:String){val initial=name.trim().firstOrNull()?.uppercase()?:"?";Surface(color=SoftBlue,shape=CircleShape,modifier=Modifier.size(47.dp)){Box(contentAlignment=Alignment.Center){Text(initial,color=Navy,fontWeight=FontWeight.Bold,fontSize=18.sp)}}}
@Composable fun StatusChip(status:String){val(c,bg)=when(status){"LUNAS"->Green to SoftGreen;"KURANG"->Yellow to SoftYellow;else->Red to SoftRed};Surface(color=bg,shape=RoundedCornerShape(20.dp)){Text(status,color=c,fontWeight=FontWeight.Bold,fontSize=10.sp,modifier=Modifier.padding(horizontal=9.dp,vertical=5.dp))}}

@Composable
fun PaymentsScreen(
    students: List<Student>,
    payments: List<Payment>,
    filter: String,
    onClearFilter: () -> Unit,
    onFilterChange: (String) -> Unit,
    onPay: (Student) -> Unit,
    onDelete: (Payment) -> Unit
) {
    val m = monthNow()
    val groups = students.groupBy { it.program }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 20.dp)) {
        item {
            Column(Modifier.padding(18.dp, 14.dp)) {
                Text("Pembayaran", fontSize = 23.sp, fontWeight = FontWeight.Bold, color = Navy)
                Text("Status pembayaran bulan $m", fontSize = 12.sp, color = Color.Gray)
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("Semua", "Lunas", "Kurang Bayar", "Belum Bayar").forEach { st ->
                        FilterChip(
                            selected = filter == st,
                            onClick = { if (st == "Semua") onClearFilter() else onFilterChange(st) },
                            label = { Text(st, maxLines = 1, overflow = TextOverflow.Ellipsis) }
                        )
                    }
                }
            }
        }
        groups.forEach { (program, list) ->
            val visible = list.filter { s ->
                val p = payments.firstOrNull { it.studentId == s.id && it.month.equals(m, true) }
                val paid = p?.amount ?: 0L
                val status = when {
                    paid >= s.monthlyFee -> "Lunas"
                    paid > 0L -> "Kurang Bayar"
                    else -> "Belum Bayar"
                }
                filter == "Semua" || status == filter
            }
            if (visible.isNotEmpty()) {
                item { SectionTitle(program, "${visible.size} siswa") }
                items(visible) { s ->
                    val payment = payments.firstOrNull { it.studentId == s.id && it.month.equals(m, true) }
                    PaymentStudentCard(s, payment, onPay) { p -> onDelete(p) }
                }
            }
        }
    }
}

@Composable
fun PaymentStudentCard(
    s: Student,
    payment: Payment?,
    onPay: (Student) -> Unit,
    onDelete: (Payment) -> Unit
) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val pc = programColors(s.program)
    val paid = payment?.amount ?: 0L
    val status = when {
        paid >= s.monthlyFee -> "LUNAS"
        paid > 0L -> "KURANG"
        else -> "BELUM BAYAR"
    }
    Card(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(pc.bg),
        elevation = CardDefaults.cardElevation(1.dp)
    ) {
        ListItem(
            leadingContent = { Surface(color = pc.iconBg, shape = CircleShape) { Avatar(s.name) } },
            headlineContent = { Text(s.name, fontWeight = FontWeight.Bold, color = Navy, fontSize = 15.sp) },
            supportingContent = {
                Text(
                    if (payment == null) "${s.className} • Tagihan ${rupiah(s.monthlyFee)}"
                    else "${s.className} • Bayar ${rupiah(paid)} dari ${rupiah(s.monthlyFee)}",
                    fontSize = 10.sp, color = Color.Gray
                )
            },
            trailingContent = {
                Column(horizontalAlignment = Alignment.End) {
                    StatusChip(status)
                    Spacer(Modifier.height(3.dp))
                    if (payment == null || paid < s.monthlyFee) {
                        TextButton(onClick = { onPay(s) }) {
                            Text(if (payment == null) "Bayar" else "Bayar Sisa", fontSize = 10.sp, color = pc.accent)
                        }
                    } else {
                        TextButton(onClick = { payment?.let(onDelete) }) {
                            Text("Kuitansi", fontSize = 10.sp, color = pc.accent)
                        }
                    }
                    payment?.let { p ->
                        TextButton(onClick = { shareReceiptImage(ctx, p, s) }) {
                            Icon(Icons.Default.Share, null, modifier = Modifier.size(14.dp))
                            Spacer(Modifier.width(3.dp))
                            Text("Kirim", fontSize = 9.sp, color = pc.accent)
                        }
                    }
                }
            }
        )
    }
}

@Composable fun PaymentSummary(list:List<Pair<Student,Payment>>){val l=list.count{it.second.amount>=it.first.monthlyFee};val k=list.count{it.second.amount<it.first.monthlyFee};Row(Modifier.fillMaxWidth().padding(horizontal=12.dp)){SummaryBox("Lunas",l,Green,SoftGreen);SummaryBox("Kurang",k,Yellow,SoftYellow);SummaryBox("Total",list.size,Navy,SoftBlue)}}
@Composable fun RowScope.SummaryBox(label:String,value:Int,color:Color,bg:Color){Card(Modifier.weight(1f).padding(4.dp),shape=RoundedCornerShape(17.dp),colors=CardDefaults.cardColors(bg)){Column(Modifier.padding(12.dp)){Text(label,color=Color.Gray,fontSize=10.sp);Text(value.toString(),color=color,fontSize=22.sp,fontWeight=FontWeight.Bold)}}}
@Composable fun PaymentListCard(s:Student,p:Payment,onDelete:(Payment)->Unit){val ctx=androidx.compose.ui.platform.LocalContext.current;val pc=programColors(s.program);Card(Modifier.fillMaxWidth().padding(horizontal=12.dp,vertical=4.dp),shape=RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(pc.bg)){ListItem(leadingContent={Surface(color=pc.iconBg,shape=CircleShape){Avatar(s.name)}},headlineContent={Text(s.name,fontWeight=FontWeight.Bold,color=Navy)},supportingContent={Text("${p.date} • ${p.method}\n${p.receiptNo}",fontSize=10.sp)},trailingContent={Column(horizontalAlignment=Alignment.End){Text(rupiah(p.amount),fontWeight=FontWeight.Bold,color=Green);StatusChip(if(p.amount>=s.monthlyFee)"LUNAS" else "KURANG");Row{TextButton(onClick={shareReceiptImage(ctx,p,s)}){Icon(Icons.Default.Share,null,modifier=Modifier.size(15.dp));Spacer(Modifier.width(3.dp));Text("Kuitansi",fontSize=10.sp)}}}})}}

@Composable
fun ReportsScreen(payments:List<Payment>,expenses:List<Expense>,incomes:List<Income>,vm:MainVm){val month=monthNow();val mp=payments.filter{it.month.equals(month,true)};val me=expenses.filter{it.month.equals(month,true)};val mi=incomes.filter{it.month.equals(month,true)};val monthlyIncome=mp.sumOf{it.amount}+mi.sumOf{it.amount};val monthlyExpense=me.sumOf{it.amount};var showExpense by remember{mutableStateOf(false)};var showIncome by remember{mutableStateOf(false)};var addExpense by remember{mutableStateOf(false)};var addIncome by remember{mutableStateOf(false)};val ctx=androidx.compose.ui.platform.LocalContext.current;LazyColumn(Modifier.fillMaxSize(),contentPadding=PaddingValues(bottom=20.dp)){item{Column(Modifier.padding(18.dp,14.dp)){Text("Laporan Keuangan",fontSize=23.sp,fontWeight=FontWeight.Bold,color=Navy);Text("Ringkasan keuangan • $month",fontSize=12.sp,color=Color.Gray)}};item{FinanceHero(monthlyIncome,monthlyExpense,monthlyIncome-monthlyExpense)};item{FinanceReportCard("Pemasukan",monthlyIncome,Green,SoftGreen,Icons.Default.TrendingUp){showIncome=true}};item{FinanceReportCard("Pengeluaran",monthlyExpense,Red,SoftRed,Icons.Default.TrendingDown){showExpense=true}};item{Button(onClick={savePdfWithChooser(ctx,"laporan_${month.replace(" ","_")}.pdf"){createFinanceReportPdf(ctx,month,mp,me,mi,monthlyIncome,monthlyExpense)}},modifier=Modifier.fillMaxWidth().padding(12.dp),shape=RoundedCornerShape(13.dp),colors=ButtonDefaults.buttonColors(Navy)){Icon(Icons.Default.PictureAsPdf,null);Spacer(Modifier.width(5.dp));Text("Simpan Laporan PDF")};OutlinedButton(onClick={sharePdf(ctx,createFinanceReportPdf(ctx,month,mp,me,mi,monthlyIncome,monthlyExpense),"Bagikan laporan $month")},modifier=Modifier.fillMaxWidth().padding(horizontal=12.dp),shape=RoundedCornerShape(13.dp)){Icon(Icons.Default.Share,null);Spacer(Modifier.width(5.dp));Text("Bagikan Laporan")}}};if(showExpense)ExpenseListDialog(me,{showExpense=false},{addExpense=true});if(showIncome)IncomeListDialog(mi,{showIncome=false},{addIncome=true});if(addExpense)ExpenseDialog(onDismiss={addExpense=false}){title,category,amount,note->vm.addExpense(Expense(month,today(),title,category,amount,note));addExpense=false};if(addIncome)IncomeDialog(onDismiss={addIncome=false}){title,category,amount,note->vm.addIncome(Income(month,today(),title,category,amount,note));addIncome=false}}
@Composable fun FinanceReportCard(title:String,total:Long,color:Color,bg:Color,icon:ImageVector,onClick:()->Unit){Card(Modifier.fillMaxWidth().padding(horizontal=12.dp,vertical=6.dp).clickable(onClick=onClick),shape=RoundedCornerShape(19.dp),colors=CardDefaults.cardColors(bg)){ListItem(leadingContent={Surface(color=Color.White,shape=CircleShape){Icon(icon,null,tint=color,modifier=Modifier.padding(9.dp))}},headlineContent={Text(title,fontWeight=FontWeight.Bold,color=Navy)},supportingContent={Text("Lihat rincian bulan ini",fontSize=11.sp,color=Color.Gray)},trailingContent={Row(verticalAlignment=Alignment.CenterVertically){Text(rupiah(total),fontWeight=FontWeight.Bold,color=color);Icon(Icons.Default.ChevronRight,null,tint=color)}})}}
@Composable fun ExpenseListDialog(items:List<Expense>,onDismiss:()->Unit,onAdd:()->Unit){AlertDialog(onDismissRequest=onDismiss,title={Text("Pengeluaran ${monthNow()}",fontWeight=FontWeight.Bold,color=Navy)},text={LazyColumn{if(items.isEmpty())item{Text("Belum ada pengeluaran bulan ini.")};items(items){e->ListItem(headlineContent={Text(e.title,fontWeight=FontWeight.Bold)},supportingContent={Text("${e.date} • ${e.category}\n${e.note}",fontSize=11.sp)},trailingContent={Text(rupiah(e.amount),fontWeight=FontWeight.Bold,color=Red)})}}},confirmButton={Button(onClick={onAdd();onDismiss()},colors=ButtonDefaults.buttonColors(Navy)){Text("+ Tambah Pengeluaran")}},dismissButton={TextButton(onClick=onDismiss){Text("Tutup")}})}
@Composable fun IncomeListDialog(items:List<Income>,onDismiss:()->Unit,onAdd:()->Unit){AlertDialog(onDismissRequest=onDismiss,title={Text("Pemasukan ${monthNow()}",fontWeight=FontWeight.Bold,color=Navy)},text={LazyColumn{if(items.isEmpty())item{Text("Belum ada pemasukan tambahan bulan ini.")};items(items){i->ListItem(headlineContent={Text(i.title,fontWeight=FontWeight.Bold)},supportingContent={Text("${i.date} • ${i.category}\n${i.note}",fontSize=11.sp)},trailingContent={Text(rupiah(i.amount),fontWeight=FontWeight.Bold,color=Green)})}}},confirmButton={Button(onClick={onAdd();onDismiss()},colors=ButtonDefaults.buttonColors(Navy)){Text("+ Tambah Pemasukan")}},dismissButton={TextButton(onClick=onDismiss){Text("Tutup")}})}

@Composable fun ReportMetric(label:String,value:Int,color:Color){Column(horizontalAlignment=Alignment.CenterHorizontally){Text(value.toString(),fontSize=21.sp,fontWeight=FontWeight.Bold,color=color);Text(label,fontSize=10.sp,color=Color.Gray)}}
@Composable fun RowScope.FilterBox(label:String,value:String,options:List<String>,onSelect:(String)->Unit){var open by remember{mutableStateOf(false)};Box(Modifier.weight(1f).padding(4.dp)){OutlinedButton(onClick={open=true},Modifier.fillMaxWidth(),shape=RoundedCornerShape(13.dp)){Column{Text(label,fontSize=9.sp,color=Color.Gray);Text(value,maxLines=1,overflow=TextOverflow.Ellipsis,fontSize=11.sp)}};DropdownMenu(open,{open=false}){options.forEach{DropdownMenuItem(text={Text(it)},onClick={onSelect(it);open=false})}}}}

@Composable
fun MoreScreen(programs: List<Program>, vm: MainVm) {
    var addProgram by remember { mutableStateOf(false) }
    var backupText by remember { mutableStateOf("") }
    var showBackup by remember { mutableStateOf(false) }
    val ctx = androidx.compose.ui.platform.LocalContext.current

    val create = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        if (uri != null) {
            ctx.contentResolver.openOutputStream(uri)?.use { output ->
                output.write(backupText.toByteArray())
            }
        }
    }

    val open = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            val text = ctx.contentResolver.openInputStream(uri)
                ?.bufferedReader()
                ?.use { reader -> reader.readText() }
            if (!text.isNullOrBlank()) {
                vm.viewModelScope.launch {
                    vm.restoreJson(text)
                }
            }
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 20.dp)
    ) {
        item {
            Column(Modifier.padding(horizontal = 18.dp, vertical = 14.dp)) {
                Text("Lainnya", fontSize = 23.sp, fontWeight = FontWeight.Bold, color = Navy)
                Text("Pengaturan aplikasi & data", fontSize = 12.sp, color = Color.Gray)
            }
        }
        item {
            MoreSection("Program & Tarif", Icons.Default.School) {
                Column {
                    programs.forEach { program ->
                        val pc = programColors(program.name)
                        Surface(color = pc.bg, shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp)) {
                            ListItem(
                            headlineContent = { Text(program.name, fontWeight = FontWeight.Bold, color = Navy) },
                            supportingContent = { Text("${rupiah(program.fee)} / bulan") },
                            trailingContent = {
                                IconButton(onClick = { vm.deleteProgram(program) }) {
                                    Icon(Icons.Default.Delete, contentDescription = "Hapus")
                                }
                            }
                            )
                        }
                    }
                    Button(
                        onClick = { addProgram = true },
                        modifier = Modifier.fillMaxWidth().padding(12.dp),
                        shape = RoundedCornerShape(13.dp),
                        colors = ButtonDefaults.buttonColors(Navy)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null)
                        Text(" Tambah Program")
                    }
                }
            }
        }
        item {
            MoreSection("Backup & Restore", Icons.Default.Backup) {
                Button(
                    onClick = {
                        vm.exportJson {
                            backupText = it
                            showBackup = true
                        }
                    },
                    modifier = Modifier.fillMaxWidth().padding(12.dp),
                    colors = ButtonDefaults.buttonColors(Navy),
                    shape = RoundedCornerShape(13.dp)
                ) {
                    Text("Backup Data JSON")
                }
                OutlinedButton(
                    onClick = { open.launch(arrayOf("application/json", "text/plain")) },
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 0.dp, vertical = 0.dp),
                    shape = RoundedCornerShape(13.dp)
                ) {
                    Text("Restore Data JSON")
                }
            }
        }
        item {
            MoreSection("Tentang Aplikasi", Icons.Default.Info) {
                Text("Bimbel Smart Kreatif Cemerlang", fontWeight = FontWeight.Bold, color = Navy)
                Text("Belajar Hari Ini, Masa Depan Lebih Baik", fontSize = 12.sp, color = Color.Gray)
                Text(
                    "Versi 3.0 • Data tersimpan di perangkat",
                    fontSize = 11.sp,
                    color = Color.Gray,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }
        }
    }

    if (addProgram) {
        ProgramDialog(onDismiss = { addProgram = false }) { name, fee ->
            vm.addProgram(Program(name = name, fee = fee))
            addProgram = false
        }
    }

    if (showBackup) {
        AlertDialog(
            onDismissRequest = { showBackup = false },
            title = { Text("Backup siap") },
            text = { Text("Simpan data siswa, pembayaran, program, dan pengeluaran ke file JSON.") },
            confirmButton = {
                Button(
                    onClick = {
                        showBackup = false
                        create.launch("backup_bimbel_${today().replace('/', '-')}.json")
                    }
                ) { Text("Simpan") }
            },
            dismissButton = {
                TextButton(onClick = { showBackup = false }) { Text("Batal") }
            }
        )
    }
}

@Composable fun MoreSection(title:String,icon:ImageVector,content: @Composable (() -> Unit)){Card(Modifier.fillMaxWidth().padding(horizontal=12.dp,vertical=5.dp),shape=RoundedCornerShape(20.dp),colors=CardDefaults.cardColors(Color.White),elevation=CardDefaults.cardElevation(1.dp)){Column(Modifier.padding(14.dp)){Row(verticalAlignment=Alignment.CenterVertically){Surface(color=SoftBlue,shape=CircleShape){Icon(icon,null,tint=Navy,modifier=Modifier.padding(8.dp))};Spacer(Modifier.width(10.dp));Text(title,fontWeight=FontWeight.Bold,color=Navy,fontSize=17.sp)};Spacer(Modifier.height(8.dp));content()}}}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudentDialog(programs: List<Program>, existing: Student?, onDismiss: () -> Unit, onSave: (Student) -> Unit) {
    var name by remember { mutableStateOf(existing?.name ?: "") }
    var cls by remember { mutableStateOf(existing?.className ?: "") }
    var phone by remember { mutableStateOf(existing?.parentPhone ?: "") }
    var selectedProgram by remember { mutableStateOf(existing?.program ?: programs.firstOrNull()?.name.orEmpty()) }
    var fee by remember { mutableStateOf(existing?.monthlyFee?.toString() ?: programs.firstOrNull()?.fee?.toString().orEmpty()) }
    var programMenu by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existing == null) "Tambah Siswa" else "Edit Siswa", fontWeight = FontWeight.Bold, color = Navy) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Nama lengkap") },
                    leadingIcon = { Icon(Icons.Default.Person, null) },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp)
                )
                OutlinedTextField(
                    value = cls,
                    onValueChange = { cls = it },
                    label = { Text("Kelas") },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp)
                )
                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text("No. HP (opsional)") },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp)
                )
                ExposedDropdownMenuBox(
                    expanded = programMenu,
                    onExpandedChange = { programMenu = !programMenu }
                ) {
                    OutlinedTextField(
                        value = selectedProgram,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Program") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = programMenu) },
                        modifier = Modifier.menuAnchor().fillMaxWidth(),
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp)
                    )
                    ExposedDropdownMenu(
                        expanded = programMenu,
                        onDismissRequest = { programMenu = false }
                    ) {
                        programs.forEach { item ->
                            DropdownMenuItem(
                                text = { Text("${item.name} • ${rupiah(item.fee)}/bulan") },
                                onClick = {
                                    selectedProgram = item.name
                                    fee = item.fee.toString()
                                    programMenu = false
                                }
                            )
                        }
                    }
                }
                OutlinedTextField(
                    value = rupiah(fee.toLongOrNull() ?: 0L),
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("Tarif per bulan") },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp)
                )
            }
        },
        confirmButton = {
            Button(
                enabled = name.isNotBlank() && selectedProgram.isNotBlank() && fee.toLongOrNull()?.let { it > 0 } == true,
                onClick = {
                    onSave(Student(existing?.id ?: 0L, name, cls, phone, selectedProgram, fee.toLong()))
                },
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(Navy)
            ) { Text("Simpan") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } }
    )
}

@Composable fun PaymentDialog(s:Student,existing:Payment?,onDismiss:()->Unit,onSave:(Long,String,String)->Unit){val remaining=(s.monthlyFee-(existing?.amount?:0)).coerceAtLeast(0);var amount by remember{mutableStateOf(remaining.toString())};var method by remember{mutableStateOf(existing?.method?:"Tunai")};var note by remember{mutableStateOf("")};AlertDialog(onDismissRequest=onDismiss,title={Text("Pembayaran • ${monthNow()}",fontWeight=FontWeight.Bold,color=Navy)},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){Row(verticalAlignment=Alignment.CenterVertically){Avatar(s.name);Spacer(Modifier.width(9.dp));Column{Text(s.name,fontWeight=FontWeight.Bold,color=Navy);Text(s.program,fontSize=11.sp,color=Color.Gray)}};Spacer(Modifier.height(4.dp));Text("Tagihan     ${rupiah(s.monthlyFee)}");Text("Sudah bayar ${rupiah(existing?.amount?:0)}");Text("Sisa         ${rupiah(remaining)}",fontWeight=FontWeight.Bold,color=if(remaining>0)Red else Green);if(remaining>0)OutlinedTextField(amount,{amount=it.filter(Char::isDigit)},label={Text("Nominal pembayaran")},singleLine=true,shape=RoundedCornerShape(12.dp));OutlinedTextField(method,{method=it},label={Text("Metode")},singleLine=true,shape=RoundedCornerShape(12.dp));OutlinedTextField(note,{note=it},label={Text("Catatan")},singleLine=true,shape=RoundedCornerShape(12.dp))}},confirmButton={Button(enabled=remaining>0&&amount.toLongOrNull()?.let{it>0&&it<=remaining}==true,onClick={onSave(amount.toLong(),method,note)},shape=RoundedCornerShape(12.dp),colors=ButtonDefaults.buttonColors(Navy)){Text(if(existing==null)"Simpan Pembayaran" else "Bayar Sisa")}},dismissButton={TextButton(onClick=onDismiss){Text("Batal")}})}
@Composable fun ExpenseDialog(onDismiss:()->Unit,onSave:(String,String,Long,String)->Unit){var title by remember{mutableStateOf("")};var cat by remember{mutableStateOf("Operasional")};var amount by remember{mutableStateOf("")};var note by remember{mutableStateOf("")};AlertDialog(onDismissRequest=onDismiss,title={Text("Tambah Pengeluaran",fontWeight=FontWeight.Bold,color=Navy)},text={Column(verticalArrangement=Arrangement.spacedBy(7.dp)){OutlinedTextField(title,{title=it},label={Text("Nama pengeluaran")},singleLine=true);OutlinedTextField(cat,{cat=it},label={Text("Kategori")},singleLine=true);OutlinedTextField(amount,{amount=it.filter(Char::isDigit)},label={Text("Jumlah")},singleLine=true);OutlinedTextField(note,{note=it},label={Text("Keterangan")},singleLine=true)}},confirmButton={Button(enabled=title.isNotBlank()&&amount.toLongOrNull()?.let{it>0}==true,onClick={onSave(title,cat,amount.toLong(),note)},colors=ButtonDefaults.buttonColors(Navy)){Text("Simpan")}},dismissButton={TextButton(onClick=onDismiss){Text("Batal")}})}
@Composable fun IncomeDialog(onDismiss:()->Unit,onSave:(String,String,Long,String)->Unit){var title by remember{mutableStateOf("")};var cat by remember{mutableStateOf("Lainnya")};var amount by remember{mutableStateOf("")};var note by remember{mutableStateOf("")};AlertDialog(onDismissRequest=onDismiss,title={Text("Tambah Pemasukan",fontWeight=FontWeight.Bold,color=Navy)},text={Column(verticalArrangement=Arrangement.spacedBy(7.dp)){OutlinedTextField(title,{title=it},label={Text("Sumber pemasukan")},singleLine=true);OutlinedTextField(cat,{cat=it},label={Text("Kategori")},singleLine=true);OutlinedTextField(amount,{amount=it.filter(Char::isDigit)},label={Text("Jumlah")},singleLine=true);OutlinedTextField(note,{note=it},label={Text("Keterangan")},singleLine=true)}},confirmButton={Button(enabled=title.isNotBlank()&&amount.toLongOrNull()?.let{it>0}==true,onClick={onSave(title,cat,amount.toLong(),note)},colors=ButtonDefaults.buttonColors(Navy)){Text("Simpan")}},dismissButton={TextButton(onClick=onDismiss){Text("Batal")}})}
@Composable fun ProgramDialog(onDismiss:()->Unit,onSave:(String,Long)->Unit){var n by remember{mutableStateOf("")};var f by remember{mutableStateOf("")};AlertDialog(onDismissRequest=onDismiss,title={Text("Tambah Program",fontWeight=FontWeight.Bold,color=Navy)},text={Column(verticalArrangement=Arrangement.spacedBy(7.dp)){OutlinedTextField(n,{n=it},label={Text("Nama program")},singleLine=true);OutlinedTextField(f,{f=it.filter(Char::isDigit)},label={Text("Tarif bulanan")},singleLine=true)}},confirmButton={Button(enabled=n.isNotBlank()&&f.toLongOrNull()?.let{it>0}==true,onClick={onSave(n,f.toLong())},colors=ButtonDefaults.buttonColors(Navy)){Text("Simpan")}},dismissButton={TextButton(onClick=onDismiss){Text("Batal")}})}

fun pdfFile(context:Context,name:String,draw:(PdfDocument.Page,Paint)->Unit):File{val doc=PdfDocument();val info=PdfDocument.PageInfo.Builder(595,842,1).create();val page=doc.startPage(info);val paint=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=android.graphics.Color.rgb(25,54,104);textSize=16f};draw(page,paint);doc.finishPage(page);val file=File(context.cacheDir,name);file.outputStream().use{doc.writeTo(it)};doc.close();return file}
fun drawLines(page:PdfDocument.Page,paint:Paint,lines:List<String>){var y=55f;for(line in lines){page.canvas.drawText(line.take(90),40f,y,paint);y+=24f;if(y>805f)break}}
fun createReceiptImage(context: Context, p: Payment, s: Student): File {
    val width = 1200
    val height = 1500
    val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(bitmap)
    val navy = android.graphics.Color.rgb(18, 77, 134)
    val navy2 = android.graphics.Color.rgb(11, 111, 186)
    val green = android.graphics.Color.rgb(24, 166, 106)
    val softGreen = android.graphics.Color.rgb(229, 248, 240)
    val softBlue = android.graphics.Color.rgb(231, 242, 252)
    val gray = android.graphics.Color.rgb(95, 105, 120)
    val dark = android.graphics.Color.rgb(34, 52, 72)
    val line = android.graphics.Color.rgb(218, 229, 239)
    val white = android.graphics.Color.WHITE
    val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    canvas.drawColor(android.graphics.Color.rgb(246, 249, 253))
    paint.color = navy
    canvas.drawRoundRect(28f, 28f, 1172f, 1472f, 42f, 42f, paint)
    paint.color = white
    canvas.drawRoundRect(42f, 42f, 1158f, 1458f, 34f, 34f, paint)

    // Header band
    paint.color = navy
    canvas.drawRoundRect(42f, 42f, 1158f, 285f, 34f, 34f, paint)
    paint.color = navy
    canvas.drawRect(42f, 180f, 1158f, 285f, paint)
    val logo = BitmapFactory.decodeResource(context.resources, context.resources.getIdentifier("logo_bimbel", "drawable", context.packageName))
    if (logo != null) canvas.drawBitmap(logo, null, android.graphics.RectF(75f, 78f, 210f, 213f), Paint(Paint.ANTI_ALIAS_FLAG))
    paint.color = white; paint.typeface = Typeface.DEFAULT_BOLD; paint.textSize = 38f
    canvas.drawText("Bimbel Smart", 245f, 125f, paint)
    paint.color = android.graphics.Color.rgb(177, 244, 212); paint.textSize = 36f
    canvas.drawText("Kreatif Cemerlang", 245f, 170f, paint)
    paint.color = white; paint.typeface = Typeface.DEFAULT; paint.textSize = 19f
    canvas.drawText("Belajar Hari Ini, Masa Depan Lebih Baik", 245f, 211f, paint)
    paint.typeface = Typeface.DEFAULT_BOLD; paint.textSize = 30f
    canvas.drawText("KWITANSI PEMBAYARAN", 75f, 260f, paint)

    // Receipt number badge
    paint.color = softBlue
    canvas.drawRoundRect(760f, 88f, 1110f, 158f, 20f, 20f, paint)
    paint.color = navy; paint.textSize = 16f
    canvas.drawText("NO. KUITANSI", 785f, 116f, paint)
    paint.color = dark; paint.textSize = 18f; paint.typeface = Typeface.DEFAULT_BOLD
    canvas.drawText(p.receiptNo.ifBlank { "-" }, 785f, 143f, paint)

    fun labelValue(label:String, value:String, x:Float, y:Float, valueX:Float){
        paint.typeface = Typeface.DEFAULT_BOLD; paint.textSize = 18f; paint.color = gray; canvas.drawText(label,x,y,paint)
        paint.typeface = Typeface.DEFAULT; paint.textSize = 22f; paint.color = dark; canvas.drawText(value,valueX,y,paint)
    }
    labelValue("Nama",s.name,85f,350f,280f)
    labelValue("Kelas",s.className,85f,405f,280f)
    labelValue("Program",s.program,85f,460f,280f)
    labelValue("Bulan",p.month,650f,350f,805f)
    labelValue("Tanggal",p.date,650f,405f,805f)
    labelValue("Metode",p.method,650f,460f,805f)

    paint.color = line; canvas.drawRect(85f,505f,1115f,507f,paint)

    // Amount card
    paint.color = softGreen
    canvas.drawRoundRect(75f, 545f, 1125f, 790f, 30f, 30f, paint)
    paint.color = green; paint.typeface = Typeface.DEFAULT_BOLD; paint.textSize = 20f
    canvas.drawText("JUMLAH PEMBAYARAN", 110f, 595f, paint)
    paint.color = dark; paint.textSize = 58f
    canvas.drawText(rupiah(p.amount), 110f, 680f, paint)
    paint.color = green; paint.textSize = 20f; paint.typeface = Typeface.DEFAULT
    canvas.drawText("Pembayaran bulan ${p.month}", 110f, 730f, paint)

    // Status pill
    val paidEnough = p.amount >= s.monthlyFee
    val status = if (paidEnough) "LUNAS" else "KURANG BAYAR"
    val statusBg = if (paidEnough) softGreen else android.graphics.Color.rgb(255,246,221)
    val statusColor = if (paidEnough) green else android.graphics.Color.rgb(185,130,0)
    paint.color = statusBg; canvas.drawRoundRect(860f, 595f, 1080f, 650f, 18f, 18f, paint)
    paint.color = statusColor; paint.textSize = 18f; paint.typeface = Typeface.DEFAULT_BOLD
    canvas.drawText(status, 895f, 630f, paint)

    // Detail payment
    paint.color = navy; paint.textSize = 23f
    canvas.drawText("RINCIAN", 85f, 850f, paint)
    labelValue("Tagihan bulanan",rupiah(s.monthlyFee),85f,900f,340f)
    labelValue("Dibayar",rupiah(p.amount),85f,950f,340f)
    labelValue("Sisa",rupiah((s.monthlyFee-p.amount).coerceAtLeast(0L)),85f,1000f,340f)

    paint.color = softBlue; canvas.drawRoundRect(75f,1050f,1125f,1160f,24f,24f,paint)
    paint.color = navy; paint.typeface = Typeface.DEFAULT_BOLD; paint.textSize = 21f
    canvas.drawText("Terima kasih atas kepercayaannya.", 110f, 1095f, paint)
    paint.typeface = Typeface.DEFAULT; paint.textSize = 17f; paint.color = gray
    canvas.drawText("Semoga ilmu yang didapatkan menjadi berkah.", 110f, 1130f, paint)

    paint.color = line; canvas.drawRect(85f,1200f,1115f,1202f,paint)
    paint.color = gray; paint.typeface = Typeface.DEFAULT; paint.textSize = 16f
    canvas.drawText("Kuitansi ini dibuat secara otomatis oleh aplikasi.", 85f, 1250f, paint)
    paint.color = navy; paint.typeface = Typeface.DEFAULT_BOLD; paint.textSize = 20f
    canvas.drawText("Bimbel Smart Kreatif Cemerlang", 85f, 1295f, paint)
    paint.color = gray; paint.typeface = Typeface.DEFAULT; paint.textSize = 16f
    canvas.drawText("Pangkalan Kerinci, Pelalawan", 85f, 1325f, paint)
    canvas.drawText("Terima kasih 🙏", 930f, 1325f, paint)

    val file = File(context.cacheDir, "kuitansi_${p.receiptNo.ifBlank { "pembayaran" }}.png")
    file.outputStream().use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
    bitmap.recycle()
    return file
}

fun shareReceiptImage(context: Context, p: Payment, s: Student) {
    val file = createReceiptImage(context, p, s)
    val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
    val send = Intent(Intent.ACTION_SEND).apply {
        type = "image/png"
        putExtra(Intent.EXTRA_STREAM, uri)
        putExtra(Intent.EXTRA_TEXT, "Kuitansi pembayaran ${s.name} - ${p.month}")
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    runCatching { context.startActivity(Intent.createChooser(send, "Bagikan kuitansi")) }
}

fun createReportPdf(context:Context,month:String,program:String,status:String,list:List<Student>,payments:List<Payment>,income:Long,expense:Long):File {
    return pdfFile(context, "laporan_${month.replace(" ", "_")}.pdf", { page, paint ->
        paint.typeface=Typeface.DEFAULT_BOLD
        paint.textSize=22f
        page.canvas.drawText("LAPORAN PEMBAYARAN",40f,55f,paint)
        paint.typeface=Typeface.DEFAULT
        paint.textSize=13f
        drawLines(page,paint,listOf(
            "Bimbel Smart Kreatif Cemerlang",
            "Periode : $month",
            "Program : $program",
            "Status  : $status",
            "",
            "Total siswa : ${list.size}",
            "Pemasukan  : ${rupiah(income)}",
            "Pengeluaran: ${rupiah(expense)}",
            "Bersih     : ${rupiah(income-expense)}",
            "",
            "RINCIAN SISWA"
        ))
        var y=310f
        for ((i,s) in list.withIndex()) {
            val paid=payments.firstOrNull { it.studentId==s.id && it.month.equals(month,true) }?.amount ?: 0
            page.canvas.drawText("${i+1}. ${s.name} | ${s.program} | Tagihan ${rupiah(s.monthlyFee)} | Bayar ${rupiah(paid)}",40f,y,paint)
            y+=20f
            if(y>815f) break
        }
    })
}
fun createFinanceReportPdf(context:Context,month:String,mp:List<Payment>,me:List<Expense>,mi:List<Income>,income:Long,expense:Long):File{
    val file=File(context.cacheDir,"laporan_keuangan_${month.replace(" ","_")}.pdf")
    val doc=PdfDocument()
    val navy=android.graphics.Color.rgb(18,77,134);val green=android.graphics.Color.rgb(24,166,106);val red=android.graphics.Color.rgb(216,58,82);val blue=android.graphics.Color.rgb(14,102,183);val bg=android.graphics.Color.rgb(243,247,252);val softGreen=android.graphics.Color.rgb(229,248,240);val softRed=android.graphics.Color.rgb(255,236,236);val softBlue=android.graphics.Color.rgb(231,242,252);val line=android.graphics.Color.rgb(218,229,239);val dark=android.graphics.Color.rgb(35,55,75);val gray=android.graphics.Color.rgb(100,115,130)
    fun paint(size:Float,color:Int,bold:Boolean=false)=Paint(Paint.ANTI_ALIAS_FLAG).apply{this.textSize=size;this.color=color;this.typeface=Typeface.create(Typeface.DEFAULT,if(bold)Typeface.BOLD else Typeface.NORMAL)}
    fun round(c:Canvas,l:Float,t:Float,r:Float,b:Float,color:Int){val p=Paint(Paint.ANTI_ALIAS_FLAG);p.color=color;c.drawRoundRect(l,t,r,b,22f,22f,p)}
    fun header(c:Canvas,pageNo:Int){c.drawColor(bg);val logo=BitmapFactory.decodeResource(context.resources,context.resources.getIdentifier("logo_bimbel","drawable",context.packageName));if(logo!=null)c.drawBitmap(logo,null,android.graphics.RectF(36f,28f,100f,92f),Paint(Paint.ANTI_ALIAS_FLAG));c.drawText("BIMBEL SMART KREATIF CEMERLANG",125f,53f,paint(23f,navy,true));c.drawText("Belajar Hari Ini, Masa Depan Lebih Baik",125f,79f,paint(12f,gray));c.drawText("LAPORAN KEUANGAN",405f,48f,paint(12f,blue,true));c.drawText(month,405f,69f,paint(12f,gray));c.drawText("Halaman $pageNo",500f,816f,paint(9f,gray))}
    fun drawRow(c:Canvas,y:Float,no:String,title:String,date:String,amount:Long,color:Int){c.drawText(no,42f,y,paint(10f,gray));c.drawText(title.take(42),72f,y,paint(11f,dark,true));c.drawText(date,360f,y,paint(10f,gray));c.drawText(rupiah(amount),500f,y,paint(11f,color,true))}
    var pageNo=1
    var page=doc.startPage(PdfDocument.PageInfo.Builder(595,842,pageNo).create());var c=page.canvas;header(c,pageNo)
    c.drawText("Ringkasan Keuangan",36f,135f,paint(18f,navy,true))
    round(c,36f,155f,215f,235f,softGreen);c.drawText("PEMASUKAN",55f,180f,paint(10f,gray,true));c.drawText(rupiah(income),55f,213f,paint(18f,green,true))
    round(c,230f,155f,409f,235f,softRed);c.drawText("PENGELUARAN",249f,180f,paint(10f,gray,true));c.drawText(rupiah(expense),249f,213f,paint(18f,red,true))
    round(c,424f,155f,559f,235f,softBlue);c.drawText("LABA BERSIH",441f,180f,paint(10f,gray,true));c.drawText(rupiah(income-expense),441f,213f,paint(15f,blue,true))
    c.drawText("Rincian Pemasukan",36f,275f,paint(16f,navy,true));round(c,36f,290f,559f,322f,softGreen);c.drawText("No",42f,311f,paint(9f,gray,true));c.drawText("Keterangan",72f,311f,paint(9f,gray,true));c.drawText("Tanggal",360f,311f,paint(9f,gray,true));c.drawText("Jumlah",500f,311f,paint(9f,gray,true))
    var y=345f
    val paymentTotal=mp.sumOf{it.amount}
    drawRow(c,y,"1","Pembayaran Siswa","Bulan ini",paymentTotal,green);y+=30f
    var no=2
    for(i in mi){if(y>735f)break;drawRow(c,y,no.toString(),i.title,i.date,i.amount,green);y+=30f;no++}
    c.drawText("Total pemasukan",360f,780f,paint(11f,dark,true));c.drawText(rupiah(income),500f,780f,paint(12f,green,true))
    doc.finishPage(page)
    pageNo++;page=doc.startPage(PdfDocument.PageInfo.Builder(595,842,pageNo).create());c=page.canvas;header(c,pageNo)
    c.drawText("Rincian Pengeluaran",36f,135f,paint(18f,navy,true));round(c,36f,150f,559f,182f,softRed);c.drawText("No",42f,171f,paint(9f,gray,true));c.drawText("Keterangan",72f,171f,paint(9f,gray,true));c.drawText("Tanggal",360f,171f,paint(9f,gray,true));c.drawText("Jumlah",500f,171f,paint(9f,gray,true));y=205f;no=1
    for(e in me){if(y>745f)break;drawRow(c,y,no.toString(),e.title,e.date,e.amount,red);y+=30f;no++}
    c.drawText("Total pengeluaran",360f,780f,paint(11f,dark,true));c.drawText(rupiah(expense),500f,780f,paint(12f,red,true))
    doc.finishPage(page)
    doc.writeTo(file.outputStream());doc.close();return file
}

fun sharePdf(context:Context,file:File,title:String){val uri=FileProvider.getUriForFile(context,"${context.packageName}.fileprovider",file);val send=Intent(Intent.ACTION_SEND).apply{type="application/pdf";putExtra(Intent.EXTRA_STREAM,uri);putExtra(Intent.EXTRA_TEXT,title);addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)};runCatching{context.startActivity(Intent.createChooser(send,title))}}
fun shareReceiptPdf(context:Context,p:Payment,s:Student){shareReceiptImage(context,p,s)}
fun shareReportPdf(context:Context,month:String,program:String,status:String,list:List<Student>,payments:List<Payment>,income:Long,expense:Long){sharePdf(context,createReportPdf(context,month,program,status,list,payments,income,expense),"Bagikan laporan $month")}
fun savePdfWithChooser(context:Context,fileName:String,makeFile:()->File){val file=makeFile();val uri=FileProvider.getUriForFile(context,"${context.packageName}.fileprovider",file);val intent=Intent(Intent.ACTION_SEND).apply{type="application/pdf";putExtra(Intent.EXTRA_STREAM,uri);putExtra(Intent.EXTRA_TITLE,fileName);addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)};runCatching{context.startActivity(Intent.createChooser(intent,"Simpan/Bagikan PDF"))}}

class MainActivity:ComponentActivity(){override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);setContent{App()}}}
