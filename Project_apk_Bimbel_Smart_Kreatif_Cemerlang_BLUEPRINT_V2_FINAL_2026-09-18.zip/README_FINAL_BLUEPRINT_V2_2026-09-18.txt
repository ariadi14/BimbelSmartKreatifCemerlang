FINAL BLUEPRINT V2 - IMPLEMENTATION 2026-09-18

Pondasi: Project_apk_Bimbel_Smart_Kreatif_Cemerlang_BLUEPRINT_V2_PERBAIKAN_2026-09-18.zip

IMPLEMENTASI FINAL
1. Dashboard
- Menggunakan satu hero/header pendidikan yang proporsional.
- Logo asli dipertahankan.
- Branding dan tulisan dibuat lebih terbaca dengan overlay kontras.
- Greeting final: "Semangat Mengelola Bimbel!".
- Bulan aktif dan panah tetap memakai fungsi yang sudah ada.
- 4 kartu status tetap: Total Siswa, Sudah Bayar, Kurang Bayar, Belum Bayar.
- Klik kartu status tetap menuju daftar pembayaran dengan filter yang sama.
- Peringatan ganti bulan dan motivasi tetap.

2. Siswa
- Halaman utama: perbaikan visual hero/background dan keterbacaan logo/tulisan.
- Search, Tambah, program dan fungsi hapus tetap.
- Program tetap dapat dipilih.
- Halaman program: Back di kiri atas di dalam area background.
- Daftar siswa tetap alfabetis dan sekarang bernomor.

3. Bayar
- Halaman utama: background/logo/tulisan diperjelas.
- Scroll horizontal nama program pada halaman utama DIHILANGKAN.
- Program tetap tersedia sebagai kartu vertikal yang dapat dipilih.
- Halaman program: Back di kiri atas di dalam background.
- Status Lunas/Kurang Bayar/Belum Bayar tetap.
- Daftar siswa alfabetis dan bernomor.
- Detail pembayaran: hanya penambahan/penyempurnaan tombol Bagikan Kuitansi pada status LUNAS; fungsi pembayaran lain tidak diubah.

4. Kuitansi
- Output PNG.
- Logo asli.
- Tidak ada QR Code.
- Tidak ada field Metode Pembayaran.
- Tidak ada TTD pribadi.
- Pengesahan menggunakan paraf S dan cap berbasis logo asli.
- Ucapan "Terima Kasih Telah Menjadi Bagian dari Kami".
- Data kuitansi tetap diambil dari data pembayaran yang sudah ada.

5. Laporan
- Visual utama menggunakan konsep final: hero pendidikan, logo asli, Laporan Keuangan, bulan aktif, Laba Bersih, Pemasukan, Pengeluaran.
- Fungsi pemasukan/pengeluaran, tambah, edit, hapus dan PDF tetap.

6. Lainnya
- Visual utama menggunakan hero pendidikan dan menu final:
  Program & Tarif
  Pemberitahuan
  Keamanan Aplikasi
  Backup & Restore
  Tentang Aplikasi
- Fungsi menu yang ada tetap diarahkan ke halaman masing-masing.

YANG DIKUNCI
- PIN Login tidak diubah.
- Database/penyimpanan dan logika pembayaran tidak diganti.
- Fungsi hapus siswa tidak diubah.
- Navigasi utama tetap.
- Tidak membuat sistem pembayaran baru.
