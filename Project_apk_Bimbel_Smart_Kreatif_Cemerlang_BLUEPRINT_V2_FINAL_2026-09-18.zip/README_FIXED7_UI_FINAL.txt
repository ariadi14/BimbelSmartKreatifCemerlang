FIXED7 UI FINAL — Bimbel Smart Kreatif Cemerlang

Fondasi: source FIXED6 yang sudah berhasil berjalan.
Tujuan versi ini: redesign UI agar lebih dekat dengan blueprint_final_14_layar.png tanpa menghapus fitur yang sudah berjalan.

UI: splash bergambar, PIN Admin, dashboard kartu pastel, kelompok program buka/tutup, filter horizontal, detail pembayaran status, kuitansi PNG, laporan lengkap/per program/keuangan, pemasukan-pengeluaran edit/hapus, dan tab Lainnya.
Keamanan: PIN Admin 6 digit + kunci aplikasi.
Versi aplikasi: 2.5 (versionCode 25).


FINAL VISUAL PATCH 2026-09-18:
- Data Siswa: program cards are the primary entry point, horizontally scrollable, with dedicated program page and back navigation.
- Bayar: program selection remains scrollable and program page has back navigation.
- Payment detail: historical months are locked for new edits; LUNAS shows Bagikan Kuitansi PNG.
- Kuitansi: PNG only, original logo, no QR, no Metode Tunai field, no personal signature; uses S paraf + seal.
- Dashboard warning appears during the final 7 days before month change.
- Existing student deletion, PIN, database and payment/report logic are preserved.
