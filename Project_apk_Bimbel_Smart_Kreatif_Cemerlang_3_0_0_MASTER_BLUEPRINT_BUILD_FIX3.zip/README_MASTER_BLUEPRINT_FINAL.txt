BIMBEL SMART KREATIF CEMERLANG — MASTER BLUEPRINT FINAL
Version 3.0.0

Foundation: FINAL_BLUEPRINT_v2_6_BUILD_FIX3, the previously successful build/install baseline.

MASTER BLUEPRINT UI/UX:
1. Splash: full-screen light sky/white visual, large centered logo, blue/green app name, centered two-line slogan, large student illustration, progress bar and loading text; no large white card.
2. PIN: same visual language as splash, large logo/title, 6-digit PIN, keypad, confirmation on first setup.
3. Dashboard: compact logo/name header, notification, “Semangat Mengelola Bimbel! 💪”, live Indonesian day/date, active month arrows, four large icon/stat cards with balanced icon/number scale, dynamic month-change warning, no Rekap per Program.
4. Data Siswa: grouped by program, colorful program cards with icon, expandable lists, alphabetical numbering, student avatar/photo, upload photo or built-in male/female avatar, program-selected tariff.
5. Pembayaran: grouped by program with icon, expandable student lists, status LUNAS/KURANG BAYAR/BELUM BAYAR, student detail, payment summary and history, LUNAS remains editable for correction.
6. Laporan: financial report only; no Laporan Lengkap, no Per Program, no horizontal report tabs; income/expense add/edit/delete, totals and PDF retained.
7. Lainnya: blueprint-style list menu; Program & Tarif opens dedicated management page with icons and add/delete; Backup/Restore, active month, notification, PIN, about and logout retained.
8. Data sync: saved programs automatically appear in student program choices/groups; saved students automatically appear in payment groups; payment data contributes to financial reports.

DATABASE:
- Room schema migrated from version 4 to 5.
- Student avatarPath added with migration preserving existing records.
- JSON backup includes avatarPath and version 5.
