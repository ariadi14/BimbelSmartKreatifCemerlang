# Bimbel Smart Kreatif Cemerlang v2.2 — PDF & Share

Perbaikan build v2.2:
- Memperbaiki syntax Kotlin pada `createReceiptPdf()` yang menyebabkan `Expecting ')'` di MainActivity.kt.
- Kuitansi pembayaran dibuat sebagai PDF dan dapat dibagikan melalui Android Share Sheet.
- Laporan dibuat sebagai PDF dan dapat dibagikan melalui Android Share Sheet.
- Menggunakan AndroidX FileProvider agar URI PDF dapat dibaca aplikasi lain.
- PDF disimpan sementara di cache aplikasi.

Build:
`gradle assembleRelease --no-daemon`

APK release yang dihasilkan berada di:
`app/build/outputs/apk/release/app-release.apk`
