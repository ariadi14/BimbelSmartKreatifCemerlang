BIMBEL SMART KREATIF CEMERLANG — BLUEPRINT V1
===============================================

Basis source:
- Project_apk_Bimbel_Smart_Kreatif_Cemerlang_BLUEPRINT_IMPLEMENTED_FINAL.zip
- Fungsi existing dipertahankan sebagai fondasi.

Implementasi Blueprint v1:
1. Splash screen menggunakan artwork splash_kids sebagai tampilan penuh area aplikasi.
2. Dashboard:
   - Bulan aktif berada di tengah dengan kontrol bulan kiri/kanan.
   - Kartu Total Siswa, Sudah Bayar, Kurang Bayar, Belum Bayar tampil bold, rounded, dan memiliki shadow.
   - Ringkasan Pembayaran dihilangkan dari judul dashboard.
3. Data Siswa:
   - Fungsi daftar siswa dan pengelompokan program dipertahankan.
   - Background modern/profesional.
   - Icon program mengikuti icon yang tersimpan pada Program.
   - Menu titik tiga tetap digunakan untuk edit siswa.
   - Form Tambah/Edit Siswa mendukung foto kamera/file dan pilihan 12 avatar bawaan.
   - Avatar siswa tersimpan dan digunakan konsisten di Data Siswa dan Bayar.
   - Program baru tanpa siswa tetap dapat muncul sebagai kelompok program.
4. Bayar:
   - Koneksi data siswa/pembayaran dipertahankan.
   - Background modern/profesional.
   - Icon program mengikuti icon program yang dipilih.
   - Status LUNAS / KURANG BAYAR / BELUM BAYAR tetap dihitung dari nominal pembayaran.
   - Nama/header siswa dapat ditekan untuk membuka detail pembayaran.
   - Pembayaran LUNAS memiliki tombol Edit Pembayaran sehingga nominal dapat dikoreksi menjadi 0, sebagian, atau lunas.
   - Program baru tetap tersedia di daftar Bayar meskipun belum memiliki siswa.
5. Laporan:
   - Fungsi pemasukan, pengeluaran, edit/hapus, laporan dan PDF dipertahankan.
   - Struktur fungsi tidak diubah.
6. Lainnya:
   - Background modern/profesional.
   - Tombol Tambah Program membuka form yang berfungsi.
   - Form berisi nama program, tarif per bulan, dan 10 pilihan icon program.
   - Program tersimpan ke database dan otomatis muncul di Data Siswa serta Bayar.
7. Bottom navigation:
   - Beranda, Siswa, Bayar, Laporan, Lainnya menggunakan navigasi Material 3 dengan indicator/pill modern.

Aturan pengembangan:
- Jangan merusak fungsi yang sudah berjalan.
- Jangan mengganti struktur database secara tidak perlu.
- Jika build gagal, fokus perbaikan hanya pada error build/compile.
- Blueprint v1 adalah acuan visual dan fungsi untuk perubahan berikutnya.

Catatan build:
- Source ini tidak dibuild di environment paket karena Gradle/Android SDK tidak tersedia di runtime ini.
- Pemeriksaan sintaks Kotlin lokal dilakukan tanpa menemukan error parser pada MainActivity.kt.
