# Bimbel Smart Kreatif Cemerlang — Android v3.0

Versi final source project dengan tampilan modern dan modul administrasi pembayaran + pengeluaran.

## Fitur final
- Dashboard modern dengan ringkasan Total Siswa, Lunas, Kurang Bayar, Belum Bayar.
- Angka status di Dashboard dapat ditekan untuk membuka Laporan dengan filter status.
- Siswa otomatis dikelompokkan berdasarkan program (mis. Calistung, Calistung 2, Bimbel, English, Iqro/Al-Qur'an).
- Pembayaran terkunci setelah lunas untuk kombinasi 1 siswa + 1 bulan + 1 tahun (bulan aktif otomatis mengikuti kalender perangkat).
- Jika pembayaran masih kurang, tombol menjadi Bayar Sisa dan total pembayaran diperbarui, bukan membuat tagihan ganda.
- Migrasi database 2→3 mempertahankan data lama dan menggabungkan transaksi ganda siswa/bulan sebelum kunci unik diterapkan.
- Peringatan 7 hari sebelum pergantian bulan jika masih ada siswa belum/kurang bayar.
- Tab Pengeluaran untuk pencatatan pengeluaran bulanan.
- Laporan terhubung dengan pemasukan, pengeluaran, dan pendapatan bersih.
- Filter laporan berdasarkan program dan status pembayaran.
- Kuitansi dapat dibagikan melalui WhatsApp/aplikasi lain.
- Backup/restore JSON mencakup siswa, program, pembayaran, dan pengeluaran.
- Logo Bimbel Smart Kreatif Cemerlang.

## Build di HP
1. Buka project ini di AndroidIDE/AndroidIDE-Fix.
2. Gunakan JDK 17 jika diminta.
3. Tunggu Gradle Sync.
4. Build > Assemble Debug / Run.
5. APK debug berada di `app/build/outputs/apk/debug/app-debug.apk`.

Catatan: source project ini menggunakan Android SDK/Gradle dari lingkungan AndroidIDE.
