package com.bimbelsmartkreatifcemerlang

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.content.SharedPreferences
import java.security.MessageDigest
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import androidx.core.content.FileProvider
import java.io.File
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.ui.graphics.Brush
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.room.*
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.*

@Entity(tableName = "students")
data class Student(@PrimaryKey(autoGenerate = true) val id: Long = 0, val name: String, val className: String, val parentPhone: String, val program: String, val monthlyFee: Long, val active: Boolean = true)
@Entity(tableName = "payments", indices = [Index(value = ["studentId", "month"], unique = true)])
data class Payment(@PrimaryKey(autoGenerate = true) val id: Long = 0, val studentId: Long, val month: String, val amount: Long, val method: String, val date: String, val note: String, val receiptNo: String = "")
@Entity(tableName = "programs")
data class Program(@PrimaryKey(autoGenerate = true) val id: Long = 0, val name: String, val fee: Long)
@Entity(tableName = "expenses")
data class Expense(@PrimaryKey(autoGenerate = true) val id: Long = 0, val month: String, val date: String, val title: String, val category: String, val amount: Long, val note: String = "")
@Entity(tableName = "incomes")
data class Income(@PrimaryKey(autoGenerate = true) val id: Long = 0, val month: String, val date: String, val title: String, val category: String, val amount: Long, val note: String = "")

@Dao interface StudentDao { @Query("SELECT * FROM students WHERE active = 1 ORDER BY program, name") fun active(): Flow<List<Student>>; @Insert suspend fun insert(s: Student): Long; @Update suspend fun update(s: Student); @Delete suspend fun delete(s: Student) }
@Dao interface PaymentDao { @Query("SELECT * FROM payments ORDER BY id DESC") fun all(): Flow<List<Payment>>; @Query("SELECT * FROM payments WHERE studentId=:studentId AND month=:month LIMIT 1") suspend fun find(studentId:Long,month:String):Payment?; @Insert suspend fun insert(p:Payment):Long; @Update suspend fun update(p:Payment); @Delete suspend fun delete(p:Payment) }
@Dao interface ProgramDao { @Query("SELECT * FROM programs ORDER BY name") fun all():Flow<List<Program>>; @Insert suspend fun insert(p:Program); @Delete suspend fun delete(p:Program) }
@Dao interface ExpenseDao { @Query("SELECT * FROM expenses ORDER BY id DESC") fun all():Flow<List<Expense>>; @Insert suspend fun insert(e:Expense):Long; @Update suspend fun update(e:Expense); @Delete suspend fun delete(e:Expense) }
@Dao interface IncomeDao { @Query("SELECT * FROM incomes ORDER BY id DESC") fun all():Flow<List<Income>>; @Insert suspend fun insert(i:Income):Long; @Update suspend fun update(i:Income); @Delete suspend fun delete(i:Income) }

@Database(entities=[Student::class,Payment::class,Program::class,Expense::class,Income::class],version=4,exportSchema=false)
abstract class AppDb:RoomDatabase(){ abstract fun students():StudentDao; abstract fun payments():PaymentDao; abstract fun programs():ProgramDao; abstract fun expenses():ExpenseDao; abstract fun incomes():IncomeDao
 companion object { @Volatile private var INSTANCE:AppDb?=null; fun get(c:Context):AppDb=INSTANCE?: synchronized(this){ INSTANCE?:Room.databaseBuilder(c.applicationContext,AppDb::class.java,"bimbel.db").addMigrations(MIGRATION_2_3, MIGRATION_3_4).build().also{INSTANCE=it} } }
}
val MIGRATION_3_4=object:Migration(3,4){override fun migrate(db:SupportSQLiteDatabase){db.execSQL("CREATE TABLE IF NOT EXISTS incomes (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, month TEXT NOT NULL, date TEXT NOT NULL, title TEXT NOT NULL, category TEXT NOT NULL, amount INTEGER NOT NULL, note TEXT NOT NULL)")}}
val MIGRATION_2_3=object:Migration(2,3){override fun migrate(db:SupportSQLiteDatabase){db.execSQL("CREATE TABLE IF NOT EXISTS expenses (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, month TEXT NOT NULL, date TEXT NOT NULL, title TEXT NOT NULL, category TEXT NOT NULL, amount INTEGER NOT NULL, note TEXT NOT NULL)");db.execSQL("CREATE TEMP TABLE payment_keep AS SELECT MIN(p.id) AS id,p.studentId,p.month,CASE WHEN SUM(p.amount)>COALESCE(s.monthlyFee,SUM(p.amount)) THEN COALESCE(s.monthlyFee,SUM(p.amount)) ELSE SUM(p.amount) END AS amount,MAX(p.method) AS method,MAX(p.date) AS date,MAX(p.note) AS note,MAX(p.receiptNo) AS receiptNo FROM payments p LEFT JOIN students s ON s.id=p.studentId GROUP BY p.studentId,p.month");db.execSQL("DELETE FROM payments");db.execSQL("INSERT INTO payments(id,studentId,month,amount,method,date,note,receiptNo) SELECT id,studentId,month,amount,method,date,note,receiptNo FROM payment_keep");db.execSQL("DROP TABLE payment_keep");db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_payments_studentId_month ON payments(studentId,month)")}}

fun rupiah(n:Long)=NumberFormat.getCurrencyInstance(Locale("id","ID")).format(n).replace(",00","")
fun monthNow()=SimpleDateFormat("MMMM yyyy",Locale("id","ID")).format(Date())
fun shiftMonth(month:String,delta:Int):String{val f=SimpleDateFormat("MMMM yyyy",Locale("id","ID"));val c=Calendar.getInstance();runCatching{c.time=f.parse(month)?:Date()}.getOrElse{c.time=Date()};c.add(Calendar.MONTH,delta);return f.format(c.time)}
fun today()=SimpleDateFormat("dd/MM/yyyy",Locale("id","ID")).format(Date())
fun normalizePhone(raw:String):String{val p=raw.filter(Char::isDigit);return when{p.startsWith("62")->p;p.startsWith("0")->"62"+p.drop(1);else->p}}
fun daysRemainingInMonth():Int{val c=Calendar.getInstance();return c.getActualMaximum(Calendar.DAY_OF_MONTH)-c.get(Calendar.DAY_OF_MONTH)}
fun isMonthWarning()=daysRemainingInMonth() in 0..7

class MainVm(ctx:Context):ViewModel(){private val db=AppDb.get(ctx);val students=db.students().active();val payments=db.payments().all();val programs=db.programs().all();val expenses=db.expenses().all();val incomes=db.incomes().all()
 init{viewModelScope.launch{if(db.programs().all().first().isEmpty())listOf(Program(name="Calistung",fee=150000),Program(name="Calistung 2",fee=150000),Program(name="Iqro / Al-Qur'an",fee=100000),Program(name="Bimbel",fee=150000),Program(name="English",fee=150000)).forEach{db.programs().insert(it)}}}
 fun addStudent(s:Student)=viewModelScope.launch{db.students().insert(s)};fun updateStudent(s:Student)=viewModelScope.launch{db.students().update(s)};fun deleteStudent(s:Student)=viewModelScope.launch{db.students().delete(s)}
 fun recordPayment(s:Student,month:String,amount:Long,method:String,note:String,onDone:()->Unit={})=viewModelScope.launch{val old=db.payments().find(s.id,month);if(old==null){db.payments().insert(Payment(studentId=s.id,month=month,amount=amount,method=method,date=today(),note=note,receiptNo="KW-"+SimpleDateFormat("yyyyMMddHHmmss",Locale.US).format(Date())))}else{val total=(old.amount+amount).coerceAtMost(s.monthlyFee);if(total<=old.amount)return@launch;db.payments().update(old.copy(amount=total,method=method,date=today(),note=note))};onDone()}
 fun deletePayment(p:Payment)=viewModelScope.launch{db.payments().delete(p)};fun addIncome(i:Income)=viewModelScope.launch{db.incomes().insert(i)};fun updateIncome(i:Income)=viewModelScope.launch{db.incomes().update(i)};fun deleteIncome(i:Income)=viewModelScope.launch{db.incomes().delete(i)};fun addProgram(p:Program)=viewModelScope.launch{db.programs().insert(p)};fun deleteProgram(p:Program)=viewModelScope.launch{db.programs().delete(p)};fun addExpense(e:Expense)=viewModelScope.launch{db.expenses().insert(e)};fun updateExpense(e:Expense)=viewModelScope.launch{db.expenses().update(e)};fun deleteExpense(e:Expense)=viewModelScope.launch{db.expenses().delete(e)}
 fun exportJson(onDone:(String)->Unit)=viewModelScope.launch{val ss=db.students().activeOnce();val ps=db.payments().allOnce();val gs=db.programs().allOnce();val es=db.expenses().allOnce();val ins=db.incomes().allOnce();val o=JSONObject().put("version",4).put("exportedAt",today());o.put("students",JSONArray().apply{ss.forEach{put(JSONObject().put("id",it.id).put("name",it.name).put("className",it.className).put("parentPhone",it.parentPhone).put("program",it.program).put("monthlyFee",it.monthlyFee).put("active",it.active))}});o.put("payments",JSONArray().apply{ps.forEach{put(JSONObject().put("id",it.id).put("studentId",it.studentId).put("month",it.month).put("amount",it.amount).put("method",it.method).put("date",it.date).put("note",it.note).put("receiptNo",it.receiptNo))}});o.put("programs",JSONArray().apply{gs.forEach{put(JSONObject().put("id",it.id).put("name",it.name).put("fee",it.fee))}});o.put("expenses",JSONArray().apply{es.forEach{put(JSONObject().put("id",it.id).put("month",it.month).put("date",it.date).put("title",it.title).put("category",it.category).put("amount",it.amount).put("note",it.note))}});o.put("incomes",JSONArray().apply{ins.forEach{put(JSONObject().put("id",it.id).put("month",it.month).put("date",it.date).put("title",it.title).put("category",it.category).put("amount",it.amount).put("note",it.note))}});onDone(o.toString(2))}
 suspend fun restoreJson(text:String){val o=JSONObject(text);val ss=o.optJSONArray("students")?:JSONArray();val gs=o.optJSONArray("programs")?:JSONArray();val ps=o.optJSONArray("payments")?:JSONArray();val es=o.optJSONArray("expenses")?:JSONArray();val ins=o.optJSONArray("incomes")?:JSONArray();for(i in 0 until gs.length()){val x=gs.getJSONObject(i);db.programs().insert(Program(x.optLong("id",0),x.optString("name"),x.optLong("fee")))};for(i in 0 until ss.length()){val x=ss.getJSONObject(i);db.students().insert(Student(x.optLong("id",0),x.optString("name"),x.optString("className"),x.optString("parentPhone"),x.optString("program"),x.optLong("monthlyFee"),x.optBoolean("active",true)))};for(i in 0 until ps.length()){val x=ps.getJSONObject(i);runCatching{db.payments().insert(Payment(x.optLong("id",0),x.optLong("studentId"),x.optString("month"),x.optLong("amount"),x.optString("method"),x.optString("date"),x.optString("note"),x.optString("receiptNo")))}};for(i in 0 until es.length()){val x=es.getJSONObject(i);db.expenses().insert(Expense(x.optLong("id",0),x.optString("month"),x.optString("date"),x.optString("title"),x.optString("category"),x.optLong("amount"),x.optString("note")))};for(i in 0 until ins.length()){val x=ins.getJSONObject(i);db.incomes().insert(Income(x.optLong("id",0),x.optString("month"),x.optString("date"),x.optString("title"),x.optString("category"),x.optLong("amount"),x.optString("note")))}}
}
suspend fun StudentDao.activeOnce()=active().first();suspend fun PaymentDao.allOnce()=all().first();suspend fun ProgramDao.allOnce()=all().first();suspend fun ExpenseDao.allOnce()=all().first();suspend fun IncomeDao.allOnce()=all().first()

private val Navy=Color(0xFF0B4C87);private val Navy2=Color(0xFF1268B3);private val Green=Color(0xFF16A66A);private val Yellow=Color(0xFFF2B52D);private val Red=Color(0xFFE94B50);private val Bg=Color(0xFFF2F9FF);private val SoftBlue=Color(0xFFE7F3FF);private val SoftGreen=Color(0xFFE2F7EA);private val SoftRed=Color(0xFFFFE8EA);private val SoftYellow=Color(0xFFFFF4D1);private val SoftPurple=Color(0xFFF0E8FF)

private val navItems=listOf(Triple(Icons.Default.Home,"Beranda",0),Triple(Icons.Default.People,"Siswa",1),Triple(Icons.Default.Payments,"Bayar",2),Triple(Icons.Default.BarChart,"Laporan",3),Triple(Icons.Default.MoreHoriz,"Lainnya",4))

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun App(){
    val context=androidx.compose.ui.platform.LocalContext.current.applicationContext
    val vm:MainVm=viewModel(factory=object:androidx.lifecycle.ViewModelProvider.Factory{override fun<T:ViewModel>create(c:Class<T>):T=MainVm(context) as T})
    var tab by remember{mutableIntStateOf(0)}
    var studentDialog by remember{mutableStateOf(false)};var editing by remember{mutableStateOf<Student?>(null)};var payStudent by remember{mutableStateOf<Student?>(null)}
    var paymentFilter by remember{mutableStateOf("Semua")};var activeMonth by remember{mutableStateOf(monthNow())};var showSplash by remember{mutableStateOf(true)};var authenticated by remember{mutableStateOf(false)}
    val students by vm.students.collectAsState(emptyList());val payments by vm.payments.collectAsState(emptyList());val programs by vm.programs.collectAsState(emptyList());val expenses by vm.expenses.collectAsState(emptyList());val incomes by vm.incomes.collectAsState(emptyList())
    LaunchedEffect(Unit){kotlinx.coroutines.delay(1400);showSplash=false}
    MaterialTheme(
            colorScheme=lightColorScheme(primary=Navy,secondary=Green,background=Bg,surface=Color.White,error=Red),
            typography=Typography(
                headlineLarge=androidx.compose.ui.text.TextStyle(fontSize=24.sp,fontWeight=FontWeight.ExtraBold,color=Navy),
                headlineMedium=androidx.compose.ui.text.TextStyle(fontSize=21.sp,fontWeight=FontWeight.ExtraBold,color=Navy),
                titleLarge=androidx.compose.ui.text.TextStyle(fontSize=18.sp,fontWeight=FontWeight.ExtraBold,color=Navy),
                titleMedium=androidx.compose.ui.text.TextStyle(fontSize=15.sp,fontWeight=FontWeight.Bold,color=Navy),
                bodyLarge=androidx.compose.ui.text.TextStyle(fontSize=14.sp,color=Navy),
                bodyMedium=androidx.compose.ui.text.TextStyle(fontSize=12.sp,color=Color.Gray),
                labelLarge=androidx.compose.ui.text.TextStyle(fontSize=11.sp,fontWeight=FontWeight.Bold)
            ),
            shapes=Shapes(
                small=RoundedCornerShape(10.dp),
                medium=RoundedCornerShape(16.dp),
                large=RoundedCornerShape(22.dp)
            )
        ){
        if(showSplash){Splash()} else if(!authenticated){PinGate(context,!pinIsSet(context)){authenticated=true}} else {
            Scaffold(containerColor=Bg,topBar={if(tab!=0)SimpleTopBar(title=when(tab){1->"Data Siswa";2->"Pembayaran";3->"Laporan";else->"Lainnya"})},bottomBar={NavigationBar(containerColor=Color.White,tonalElevation=2.dp,modifier=Modifier.height(68.dp)){navItems.forEach{(icon,label,index)->NavigationBarItem(selected=tab==index,onClick={tab=index},icon={Icon(icon,null)},label={Text(label,fontSize=9.sp,fontWeight=FontWeight.SemiBold)},colors=NavigationBarItemDefaults.colors(selectedIconColor=Navy,selectedTextColor=Navy,indicatorColor=SoftBlue))}}}){pad->
                Box(Modifier.padding(pad).fillMaxSize()){
                    when(tab){
                        0->Dashboard(students,payments,expenses,incomes,activeMonth,{activeMonth=it}){status->paymentFilter=status;tab=2}
                        1->StudentsScreen(students,programs,{editing=it;studentDialog=true},{editing=null;studentDialog=true})
                        2->PaymentsScreen(students,payments,paymentFilter,activeMonth,{activeMonth=shiftMonth(activeMonth,-1)},{activeMonth=shiftMonth(activeMonth,1)},{paymentFilter="Semua"},{status->paymentFilter=status},{payStudent=it},{vm.deletePayment(it)})
                        3->ReportsScreen(students,programs,payments,expenses,incomes,vm,activeMonth,{activeMonth=it})
                        else->MoreScreen(programs,vm,activeMonth,{activeMonth=it}){authenticated=false}
                    }
                }
            }
        }
        if(studentDialog)StudentDialog(programs,editing,{studentDialog=false;editing=null}){st->if(st.id==0L)vm.addStudent(st)else vm.updateStudent(st);studentDialog=false;editing=null}
        payStudent?.let{s->PaymentDialog(s,payments.find{it.studentId==s.id&&it.month.equals(activeMonth,true)},activeMonth,{payStudent=null}){amount,method,note->vm.recordPayment(s,activeMonth,amount,method,note){payStudent=null}}}
    }
}

private fun pinPrefs(context:Context)=context.getSharedPreferences("bimbel_security",Context.MODE_PRIVATE)
private fun hashPin(pin:String):String=MessageDigest.getInstance("SHA-256").digest(pin.toByteArray()).joinToString(""){String.format("%02x",it)}
private fun pinIsSet(context:Context)=pinPrefs(context).getString("pin_hash",null)!=null
private fun savePin(context:Context,pin:String){pinPrefs(context).edit().putString("pin_hash",hashPin(pin)).apply()}
private fun checkPin(context:Context,pin:String)=pinPrefs(context).getString("pin_hash","")==hashPin(pin)

@Composable fun PinGate(context:Context,firstSetup:Boolean,onSuccess:()->Unit){
    var pin by remember{mutableStateOf("")};var confirm by remember{mutableStateOf("")};var error by remember{mutableStateOf("")}
    fun addDigit(d:String){if(pin.length<6)pin+=d;error=""}
    fun backspace(){if(pin.isNotEmpty())pin=pin.dropLast(1);error=""}
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFFDFF2FF),Color.White,Color(0xFFEAF9F2)))),contentAlignment=Alignment.Center){
        Card(Modifier.fillMaxWidth().padding(horizontal=24.dp,vertical=20.dp),shape=RoundedCornerShape(32.dp),colors=CardDefaults.cardColors(Color(0xFFF4F8FD)),elevation=CardDefaults.cardElevation(9.dp)){
            Column(Modifier.padding(horizontal=24.dp,vertical=24.dp),horizontalAlignment=Alignment.CenterHorizontally){
                Surface(color=SoftBlue,shape=CircleShape){Icon(Icons.Default.Lock,null,tint=Navy,modifier=Modifier.padding(14.dp).size(34.dp))}
                Spacer(Modifier.height(10.dp));Image(painterResource(R.drawable.logo_bimbel),"Logo",Modifier.size(68.dp))
                Text("Bimbel Smart",fontSize=23.sp,fontWeight=FontWeight.ExtraBold,color=Navy);Text("Kreatif Cemerlang",fontSize=20.sp,fontWeight=FontWeight.ExtraBold,color=Green)
                Spacer(Modifier.height(14.dp));Text(if(firstSetup)"Buat PIN Admin" else "Masukkan PIN Admin",fontSize=21.sp,fontWeight=FontWeight.ExtraBold,color=Navy)
                Text(if(firstSetup)"Buat PIN 6 digit untuk mengamankan data" else "Data siswa dan keuangan dilindungi dengan aman",fontSize=11.sp,color=Color.Gray)
                Spacer(Modifier.height(13.dp));Row(horizontalArrangement=Arrangement.spacedBy(10.dp)){repeat(6){i->Surface(color=if(i<pin.length)Navy else Color.White,shape=CircleShape){Box(Modifier.size(18.dp))}}}
                if(firstSetup){Spacer(Modifier.height(8.dp));Text("PIN Baru",fontSize=10.sp,color=Color.Gray)}
                Spacer(Modifier.height(13.dp));Column(Modifier.fillMaxWidth(),verticalArrangement=Arrangement.spacedBy(8.dp)){
                    listOf(listOf("1","2","3"),listOf("4","5","6"),listOf("7","8","9"),listOf("","0","⌫")).forEach{row->Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){row.forEach{d->if(d.isBlank())Spacer(Modifier.weight(1f))else OutlinedButton(onClick={if(d=="⌫")backspace()else addDigit(d)},modifier=Modifier.weight(1f).height(54.dp),shape=RoundedCornerShape(15.dp),colors=ButtonDefaults.outlinedButtonColors(containerColor=Color.White,contentColor=Navy)){Text(d,fontSize=21.sp,fontWeight=FontWeight.ExtraBold)}}}}
                }
                if(firstSetup){Spacer(Modifier.height(9.dp));OutlinedTextField(confirm,{if(it.length<=6&&it.all(Char::isDigit))confirm=it},label={Text("Ulangi PIN 6 digit")},visualTransformation=androidx.compose.ui.text.input.PasswordVisualTransformation(),keyboardOptions=androidx.compose.foundation.text.KeyboardOptions(keyboardType=androidx.compose.ui.text.input.KeyboardType.NumberPassword),singleLine=true,modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(15.dp))}
                if(error.isNotBlank()){Spacer(Modifier.height(6.dp));Text(error,color=Red,fontSize=11.sp,fontWeight=FontWeight.Bold)}
                Spacer(Modifier.height(11.dp));Button(onClick={if(pin.length!=6)error="PIN harus 6 digit" else if(firstSetup&&pin!=confirm)error="PIN tidak sama" else if(!firstSetup&&!checkPin(context,pin))error="PIN salah" else {if(firstSetup)savePin(context,pin);onSuccess()}},enabled=pin.length==6&&(firstSetup||pin.isNotBlank()),modifier=Modifier.fillMaxWidth().height(48.dp),shape=RoundedCornerShape(15.dp),colors=ButtonDefaults.buttonColors(Navy)){Text(if(firstSetup)"Simpan & Masuk" else "Masuk",fontWeight=FontWeight.ExtraBold,fontSize=15.sp)}
            }
        }
    }
}

@Composable fun Splash(){
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFFC9ECFF),Color(0xFFEAF8FF),Color(0xFFE7F8EF))))) {
        Column(Modifier.fillMaxSize(),horizontalAlignment=Alignment.CenterHorizontally){
            Spacer(Modifier.height(42.dp))
            Text("BIMBEL SMART KREATIF CEMERLANG",fontSize=11.sp,fontWeight=FontWeight.ExtraBold,color=Navy)
            Spacer(Modifier.height(7.dp))
            Image(painterResource(R.drawable.logo_bimbel),"Logo",Modifier.size(142.dp))
            Text("Bimbel Smart",fontSize=27.sp,fontWeight=FontWeight.ExtraBold,color=Navy)
            Text("Kreatif Cemerlang",fontSize=24.sp,fontWeight=FontWeight.ExtraBold,color=Green)
            Spacer(Modifier.height(5.dp))
            Text("Belajar Hari Ini, Masa Depan Lebih Baik",fontSize=13.sp,fontWeight=FontWeight.SemiBold,color=Navy)
            Spacer(Modifier.height(12.dp))
            Image(painterResource(R.drawable.splash_kids),"Ilustrasi siswa",Modifier.fillMaxWidth().weight(1f).padding(horizontal=10.dp),contentScale=androidx.compose.ui.layout.ContentScale.Crop)
            Surface(color=Color.White.copy(alpha=.82f),shape=RoundedCornerShape(topStart=18.dp,topEnd=18.dp),modifier=Modifier.fillMaxWidth()){
                Column(Modifier.fillMaxWidth().padding(vertical=10.dp),horizontalAlignment=Alignment.CenterHorizontally){
                    Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){
                        Surface(color=SoftBlue,shape=RoundedCornerShape(10.dp)){Text("Cerdas",color=Navy,fontSize=9.sp,fontWeight=FontWeight.Bold,modifier=Modifier.padding(horizontal=10.dp,vertical=5.dp))}
                        Surface(color=SoftGreen,shape=RoundedCornerShape(10.dp)){Text("Kreatif",color=Green,fontSize=9.sp,fontWeight=FontWeight.Bold,modifier=Modifier.padding(horizontal=10.dp,vertical=5.dp))}
                        Surface(color=SoftPurple,shape=RoundedCornerShape(10.dp)){Text("Berprestasi",color=Navy,fontSize=9.sp,fontWeight=FontWeight.Bold,modifier=Modifier.padding(horizontal=10.dp,vertical=5.dp))}
                    }
                    Spacer(Modifier.height(8.dp))
                    LinearProgressIndicator(Modifier.width(210.dp).height(5.dp),color=Navy,trackColor=SoftBlue)
                    Spacer(Modifier.height(5.dp))
                    Text("Memuat aplikasi…",fontSize=10.sp,color=Color.Gray)
                }
            }
        }
    }
}

