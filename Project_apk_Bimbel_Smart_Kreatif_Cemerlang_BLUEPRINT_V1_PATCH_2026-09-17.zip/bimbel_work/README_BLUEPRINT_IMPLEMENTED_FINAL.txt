MASTER BLUEPRINT IMPLEMENTED FINAL
Project: Bimbel Smart Kreatif Cemerlang

Applied from the locked user blueprint:
- Splash visual preserved toward reference.
- PIN Admin screen preserved.
- Dashboard visual refined: balanced stat cards, icons and numbers; no Rekap per Program.
- Data Siswa: program groups; tapping a program opens a dedicated page; Add Siswa opens a dedicated form.
- Student form: gallery/file photo, camera capture, male/female built-in avatars.
- Student and payment data remain connected through the same Room student records.
- Bayar: status LUNAS/KURANG BAYAR/BELUM BAYAR; tapping a student opens a dedicated payment detail page; LUNAS remains editable for correction.
- Laporan: Daftar / Pemasukan and Daftar / Pengeluaran heading layout; existing income/expense functions retained.
- Lainnya: Add Program opens form with icon selection, name and monthly fee; saved programs are shared with Data Siswa and Bayar.
- Program iconKey persisted with Room migration 5->6 and JSON backup/restore support.
- Visual system uses the blueprint's navy/green/yellow/red/pastel palette, bold hierarchy, rounded cards and consistent spacing.

Important: Android Gradle compilation should be run in GitHub Actions with `gradle assembleRelease --no-daemon` before installation. This environment does not contain the Android Gradle executable.
