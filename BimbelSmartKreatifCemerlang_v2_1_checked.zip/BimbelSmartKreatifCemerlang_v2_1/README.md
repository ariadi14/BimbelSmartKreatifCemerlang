# Bimbel Smart Kreatif Cemerlang — Android v2.1

Versi ini disiapkan khusus agar lebih mudah dibangun dari HP menggunakan AndroidIDE/AndroidIDE-Fix.

## Fitur
- Data siswa: tambah, edit, cari, hapus
- Program & tarif bulanan
- Pembayaran manual Tunai/Transfer
- Status Belum Bayar / Kurang Bayar / Lunas berdasarkan bulan
- Nomor kuitansi otomatis
- Bagikan kuitansi melalui WhatsApp / aplikasi lain
- Laporan pemasukan per bulan
- Backup data ke file JSON dan restore JSON
- Logo Bimbel Smart Kreatif Cemerlang
- Database lokal Room; data tersimpan di HP

## Pemeriksaan V2.1

V2.1 sudah diperiksa ulang. Perbaikan penting pada pembuatan ViewModel sudah dilakukan agar konteks Android tidak diambil dari fungsi non-Compose. Backup/restore JSON juga sudah terhubung. Proyek tetap berupa source project, bukan APK.

## Build di HP
1. Instal AndroidIDE/AndroidIDE-Fix dari halaman Releases GitHub.
2. Ekstrak ZIP ini ke penyimpanan HP.
3. Buka folder `BimbelSmartKreatifCemerlang_v2_1` dari AndroidIDE.
4. Tunggu Gradle Sync selesai. Jika diminta JDK, pilih JDK 17.
5. Pilih Build > Assemble Debug / Run.
6. APK debug akan berada di `app/build/outputs/apk/debug/app-debug.apk`.

Catatan: proyek ini adalah source project. Lingkungan pembuatan ChatGPT tidak memiliki Android SDK/Gradle sehingga APK tidak diklaim sudah dibuild di sini.
