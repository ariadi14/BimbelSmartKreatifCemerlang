BIMBEL SMART KREATIF CEMERLANG - FINAL BLUEPRINT BUILD FIX

Fix for compileReleaseKotlin unresolved references in MainActivity.kt.
Restored the missing declarations used by the final source:
- MoreScreen
- StudentDialog
- PaymentDialog
- ReportMetric
- PaymentReportRow
- supporting More/Report helpers

The finance module (Pemasukan/Pengeluaran), monthly expenses, receipt PNG, PDF reporting, student/payment features and locked UI structure are retained.

Build command:
gradle assembleRelease --no-daemon

This package has not been claimed as BUILD SUCCESSFUL unless the CI log confirms it.
