# Bimbel Smart Kreatif Cemerlang v2.4 — Blueprint Final

Source ini adalah fondasi project APK yang sebelumnya sudah berhasil build/install. Desain utama mengikuti blueprint final 14 layar yang disetujui.

## Perubahan final v2.4
- Dashboard: Rekap per Program dihapus; ringkasan utama dan ringkasan keuangan dipertahankan.
- Dashboard: angka Sudah Bayar/Kurang Bayar/Belum Bayar mengarahkan langsung ke Tab Bayar dengan filter status.
- Data Siswa: khusus data siswa, tanpa status pembayaran, tetap dikelompokkan berdasarkan program.
- Bayar: siswa dikelompokkan berdasarkan program dan status LUNAS/KURANG/BELUM tampil di sisi kanan; kuitansi tetap bisa dibagikan sebagai gambar PNG.
- Program & Tarif: admin membuat program dan tarif dari Lainnya. Tambah/Edit Siswa memilih program dari daftar dan tarif otomatis mengikuti program.
- Laporan: khusus ringkasan keuangan bulanan (pemasukan, pengeluaran, laba bersih). Rincian pemasukan/pengeluaran bisa dibuka dan memiliki input data.
- Laporan: export/share PDF menggunakan desain laporan keuangan final.
- Semua tampilan yang memiliki kelompok program memakai warna latar pastel yang berbeda per program. Pemetaan utama: Bimbel hijau lembut, Calistung kuning lembut, Iqro/Al-Qur'an biru lembut, English pink lembut, Komputer ungu lembut; program custom mendapat warna pastel deterministik.
- Kuitansi: output PNG dengan desain visual profesional, logo, nomor kuitansi, data siswa, bulan, nominal, status, dan ucapan terima kasih.
- Backup/Restore mencakup students, payments, programs, expenses, dan incomes.

## Build
```bash
gradle assembleRelease --no-daemon
```

Target: `BUILD SUCCESSFUL`, kemudian uji APK di perangkat Android.

## Dokumen referensi
- `docs/blueprint_final_14_layar.png` — blueprint UI final yang disetujui.
- `docs/contoh_laporan_keuangan_final.pdf` — contoh bentuk PDF laporan keuangan yang disetujui.
