BIMBEL SMART KREATIF CEMERLANG — FINAL UI 2.7
================================================

SOURCE BASIS
- Continues from the working feature source FINAL_BLUEPRINT_v2_6_BUILD_FIX3.
- Database, payment logic, month navigation, income/expense CRUD, PDF report, PNG receipt and share flow are preserved.

VISUAL MASTER
- docs/blueprint_final_14_layar.png is the locked 14-screen visual reference.
- The UI pass updates the shared visual system: background, typography hierarchy, spacing, card proportions, rounded shapes, status colors, top bars, bottom navigation, splash and dashboard greeting.
- Program groups retain distinct pastel identities.
- Horizontal program/status filters remain scrollable.

IMPORTANT
- This environment does not contain the Android Gradle toolchain, so the APK cannot be runtime-installed/visually verified here.
- GitHub Actions workflow .github/workflows/build-apk.yml is included to build debug and release APKs with Gradle 8.2/JDK 17.
- Before installing the final artifact, compare the generated APK screen-by-screen against docs/blueprint_final_14_layar.png.

VERSION
- versionCode 27
- versionName 2.7-FINAL-UI
