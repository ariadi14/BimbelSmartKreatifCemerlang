BIMBEL SMART KREATIF CEMERLANG - UI LOCKED FINAL

This build continues from the previously working feature source.
Visual target: docs/blueprint_final_14_layar.png.

UI focus in this revision:
- Splash with branded logo, children illustration, slogan, pastel background and loading indicator.
- Admin PIN screen with six-dot indicator and keypad.
- Dashboard with branded header, active month card, four payment status cards, warning card and finance hero.
- Student program groups with pastel colors, expandable lists, alphabetical numbering and horizontal filters.
- Payment groups with pastel colors, horizontal status filters, payment detail cards and shareable PNG receipt.
- Student/payment dialogs redesigned with rounded cards and visual status summaries.
- Reports organized as Lengkap / Per Program / Keuangan while preserving income/expense CRUD and PDF sharing.
- Lainnya organized into modern rounded sections.
- Existing PIN/security, month navigation, Room data, backup/restore, payment, income/expense, receipt and PDF functionality are preserved.

Do not treat this README as a claim of pixel-perfect equivalence; the Android runtime build should be visually compared screen-by-screen against the blueprint before release.


FINALIZATION 2026-09-16
- Finance/Laporan now exposes Pemasukan and Pengeluaran directly on the Keuangan tab, with active-month navigation, add/edit/delete actions, totals and net income.
- Expense records remain stored per active month and are included in dashboard and PDF calculations.
- Receipt PNG generation/sharing remains enabled.
- Visual implementation continues from this project source and the locked 14-screen blueprint; existing features are preserved.
