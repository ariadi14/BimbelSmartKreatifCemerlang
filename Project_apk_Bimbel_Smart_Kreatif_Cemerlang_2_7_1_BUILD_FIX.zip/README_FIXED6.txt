v2.4 FINAL BLUEPRINT FIXED6

Perubahan:
- Pemasukan dan Pengeluaran memiliki alur yang sama: Tambah, Edit, Hapus, dan Simpan.
- Tombol edit pada kedua jenis transaksi menyimpan perubahan dengan tombol “Simpan”.
- Bulan Aktif di Dashboard sekarang memiliki panah kiri/kanan yang benar-benar berfungsi.
- Pergantian bulan di Dashboard diterapkan ke ringkasan Dashboard, filter Tab Bayar, dan pembayaran siswa.
- Filter status pembayaran tetap menuju Tab Bayar.
- Blueprint visual final tetap dipertahankan.
