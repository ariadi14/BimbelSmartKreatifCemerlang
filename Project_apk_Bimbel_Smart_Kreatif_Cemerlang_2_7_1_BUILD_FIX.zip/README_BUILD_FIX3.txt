BUILD FIX 3: restored all known missing Kotlin symbols as a set.
Verified in MainActivity.kt: MoreScreen, StudentDialog, PaymentDialog, ReportMetric, PaymentReportRow.
