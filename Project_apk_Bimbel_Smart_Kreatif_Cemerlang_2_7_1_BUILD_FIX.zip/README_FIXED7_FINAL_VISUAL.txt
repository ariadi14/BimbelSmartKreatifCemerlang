FIXED7 FINAL VISUAL – Bimbel Smart Kreatif Cemerlang

Fondasi: FIXED6 yang sudah berhasil digunakan.

Perubahan visual/fungsional sebelum GitHub:
- Splash diperbarui agar lebih dekat dengan blueprint final: logo, slogan, pastel background, loading.
- Dashboard: greeting netral “Semangat Mengelola Bimbel! 💪”; Rekap per Program dihapus; statistik tetap clickable; bulan aktif tetap dengan panah; peringatan <= 7 hari sebelum pergantian bulan; ringkasan keuangan.
- Data Siswa: kelompok program collapsible; A-Z + nomor urut per program; warna pastel berbeda; filter program horizontal; form tambah/edit program dari Program & Tarif dan tarif otomatis.
- Bayar: kelompok program collapsible; A-Z + nomor; filter status horizontal; klik kartu siswa membuka detail pembayaran; status LUNAS/KURANG/BELUM BAYAR; kuitansi PNG + share.
- Laporan: tab Laporan Lengkap, Per Program, dan Keuangan; PDF laporan pembayaran/keuangan; Pemasukan & Pengeluaran tetap dapat tambah/edit/hapus/simpan dengan konfirmasi hapus.
- Lainnya: Program & Tarif, Backup/Restore, Bulan Aktif, Keamanan, Tentang Aplikasi.
- Keamanan: PIN Admin 6 digit, setup pertama, login setiap pembukaan aplikasi, hash SHA-256, ganti PIN, kunci aplikasi.

Catatan build:
Source ini perlu dibuild di GitHub Actions/project environment Android. Lingkungan kerja saat penyusunan ini tidak memiliki Gradle Wrapper pada ZIP sehingga assembleRelease tidak dijalankan di sini.
