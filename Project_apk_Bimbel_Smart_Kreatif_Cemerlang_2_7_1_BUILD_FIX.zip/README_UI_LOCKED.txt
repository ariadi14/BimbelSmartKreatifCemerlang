BIMBEL SMART KREATIF CEMERLANG - UI LOCKED BUILD

Visual reference: docs/blueprint_final_14_layar.png

This build keeps the tested application features and restyles the Compose interface toward the locked 14-screen blueprint:
1 Splash, 2 PIN Admin, 3 Dashboard, 4 Data Siswa groups, 5 students per program,
6 Add/Edit Student, 7 Payment groups, 8/9 payment detail states, 10/11/12 reports,
13 PNG receipt, 14 Other/Settings.

Locked visual principles:
- Navy/green brand palette with white surfaces and soft pastel backgrounds.
- Rounded cards, soft elevation, icon badges, clear hierarchy and generous spacing.
- Program groups use distinct pastel colors.
- Status uses green/yellow/red visual language.
- Horizontal filter chips remain scrollable.
- Existing payment, income, expense, backup/restore, PDF and PIN functionality is retained.
- Dashboard greeting is time-neutral: "Semangat Mengelola Bimbel! 💪".
- Dashboard does not show Rekap per Program.
