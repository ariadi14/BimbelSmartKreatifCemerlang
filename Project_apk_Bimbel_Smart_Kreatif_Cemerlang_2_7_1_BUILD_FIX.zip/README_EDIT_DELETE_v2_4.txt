Bimbel Smart Kreatif Cemerlang - v2.4 FINAL BLUEPRINT EDIT/DELETE

Perubahan:
- Tab Laporan > Pemasukan: setiap data memiliki tombol Edit dan Hapus.
- Tab Laporan > Pengeluaran: setiap data memiliki tombol Edit dan Hapus.
- Edit dapat mengubah nama/keterangan, kategori, tanggal, jumlah, dan catatan.
- Hapus meminta konfirmasi sebelum menghapus data.
- Perubahan tersimpan ke database Room dan langsung tercermin pada ringkasan laporan.
- Blueprint dan desain utama aplikasi tidak diubah.
