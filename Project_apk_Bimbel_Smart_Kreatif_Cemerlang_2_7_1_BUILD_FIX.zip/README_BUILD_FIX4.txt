BUILD FIX 4 - FINAL UI

Fixed MainActivity.kt compilation error at BlueprintTypography.

Cause:
MaterialTheme.typography was referenced in a top-level property initializer. MaterialTheme is a @Composable API and cannot be called there.

Fix:
BlueprintTypography now starts from Typography() and copies its text styles without calling MaterialTheme from a non-composable context.

The existing functional/database/UI implementation is otherwise preserved.
