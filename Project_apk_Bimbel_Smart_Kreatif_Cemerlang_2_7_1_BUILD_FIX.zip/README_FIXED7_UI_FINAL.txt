FIXED7 UI FINAL — Bimbel Smart Kreatif Cemerlang

Fondasi: source FIXED6 yang sudah berhasil berjalan.
Tujuan versi ini: redesign UI agar lebih dekat dengan blueprint_final_14_layar.png tanpa menghapus fitur yang sudah berjalan.

UI: splash bergambar, PIN Admin, dashboard kartu pastel, kelompok program buka/tutup, filter horizontal, detail pembayaran status, kuitansi PNG, laporan lengkap/per program/keuangan, pemasukan-pengeluaran edit/hapus, dan tab Lainnya.
Keamanan: PIN Admin 6 digit + kunci aplikasi.
Versi aplikasi: 2.5 (versionCode 25).
