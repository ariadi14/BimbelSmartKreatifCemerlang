package com.bimbelsmartkreatifcemerlang

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.room.*
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.*

@Entity(tableName = "students")
data class Student(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val className: String,
    val parentPhone: String,
    val program: String,
    val monthlyFee: Long,
    val active: Boolean = true
)

@Entity(
    tableName = "payments",
    indices = [Index(value = ["studentId", "month"], unique = true)]
)
data class Payment(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val studentId: Long,
    val month: String,
    val amount: Long,
    val method: String,
    val date: String,
    val note: String,
    val receiptNo: String = ""
)

@Entity(tableName = "programs")
data class Program(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val fee: Long
)

@Entity(tableName = "expenses")
data class Expense(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val month: String,
    val date: String,
    val title: String,
    val category: String,
    val amount: Long,
    val note: String = ""
)

@Dao
interface StudentDao {
    @Query("SELECT * FROM students WHERE active = 1 ORDER BY program, name") fun active(): Flow<List<Student>>
    @Insert suspend fun insert(s: Student): Long
    @Update suspend fun update(s: Student)
    @Delete suspend fun delete(s: Student)
}

@Dao
interface PaymentDao {
    @Query("SELECT * FROM payments ORDER BY id DESC") fun all(): Flow<List<Payment>>
    @Query("SELECT * FROM payments WHERE studentId = :studentId AND month = :month LIMIT 1") suspend fun find(studentId: Long, month: String): Payment?
    @Insert suspend fun insert(p: Payment): Long
    @Update suspend fun update(p: Payment)
    @Delete suspend fun delete(p: Payment)
}

@Dao
interface ProgramDao {
    @Query("SELECT * FROM programs ORDER BY name") fun all(): Flow<List<Program>>
    @Insert suspend fun insert(p: Program)
    @Delete suspend fun delete(p: Program)
}

@Dao
interface ExpenseDao {
    @Query("SELECT * FROM expenses ORDER BY id DESC") fun all(): Flow<List<Expense>>
    @Insert suspend fun insert(e: Expense): Long
    @Delete suspend fun delete(e: Expense)
}

@Database(entities = [Student::class, Payment::class, Program::class, Expense::class], version = 3, exportSchema = false)
val MIGRATION_2_3 = object : Migration(2, 3) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS expenses (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, month TEXT NOT NULL, date TEXT NOT NULL, title TEXT NOT NULL, category TEXT NOT NULL, amount INTEGER NOT NULL, note TEXT NOT NULL)")
        // Merge duplicate payment rows per student/month before enforcing the new lock.
        db.execSQL("CREATE TEMP TABLE payment_keep AS SELECT MIN(p.id) AS id, p.studentId, p.month, CASE WHEN SUM(p.amount) > COALESCE(s.monthlyFee, SUM(p.amount)) THEN COALESCE(s.monthlyFee, SUM(p.amount)) ELSE SUM(p.amount) END AS amount, MAX(p.method) AS method, MAX(p.date) AS date, MAX(p.note) AS note, MAX(p.receiptNo) AS receiptNo FROM payments p LEFT JOIN students s ON s.id = p.studentId GROUP BY p.studentId, p.month")
        db.execSQL("DELETE FROM payments")
        db.execSQL("INSERT INTO payments(id,studentId,month,amount,method,date,note,receiptNo) SELECT id,studentId,month,amount,method,date,note,receiptNo FROM payment_keep")
        db.execSQL("DROP TABLE payment_keep")
        db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_payments_studentId_month ON payments(studentId, month)")
    }
}

abstract class AppDb : RoomDatabase() {
    abstract fun students(): StudentDao
    abstract fun payments(): PaymentDao
    abstract fun programs(): ProgramDao
    abstract fun expenses(): ExpenseDao
    companion object {
        @Volatile private var INSTANCE: AppDb? = null
        fun get(c: Context): AppDb = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(c.applicationContext, AppDb::class.java, "bimbel.db")
                .addMigrations(MIGRATION_2_3).build().also { INSTANCE = it }
        }
    }
}

fun rupiah(n: Long): String = NumberFormat.getCurrencyInstance(Locale("id", "ID")).format(n).replace(",00", "")
fun monthNow(): String = SimpleDateFormat("MMMM yyyy", Locale("id", "ID")).format(Date())
fun today(): String = SimpleDateFormat("dd/MM/yyyy", Locale("id", "ID")).format(Date())
fun normalizePhone(raw: String): String {
    val p = raw.filter(Char::isDigit)
    return when {
        p.startsWith("62") -> p
        p.startsWith("0") -> "62" + p.drop(1)
        else -> p
    }
}

fun daysRemainingInMonth(): Int {
    val c = Calendar.getInstance()
    val max = c.getActualMaximum(Calendar.DAY_OF_MONTH)
    return max - c.get(Calendar.DAY_OF_MONTH)
}

fun isMonthWarning(): Boolean = daysRemainingInMonth() in 0..7

class MainVm(ctx: Context) : ViewModel() {
    private val db = AppDb.get(ctx)
    val students = db.students().active()
    val payments = db.payments().all()
    val programs = db.programs().all()
    val expenses = db.expenses().all()

    init { viewModelScope.launch {
        if (db.programs().all().first().isEmpty()) listOf(
            Program(name = "Calistung", fee = 150000),
            Program(name = "Calistung 2", fee = 150000),
            Program(name = "Iqro / Al-Qur'an", fee = 100000),
            Program(name = "Bimbel", fee = 150000),
            Program(name = "English", fee = 150000)
        ).forEach { db.programs().insert(it) }
    } }

    fun addStudent(s: Student) = viewModelScope.launch { db.students().insert(s) }
    fun updateStudent(s: Student) = viewModelScope.launch { db.students().update(s) }
    fun deleteStudent(s: Student) = viewModelScope.launch { db.students().delete(s) }

    fun recordPayment(student: Student, month: String, amount: Long, method: String, note: String, onDone: () -> Unit = {}) = viewModelScope.launch {
        val old = db.payments().find(student.id, month)
        if (old == null) {
            val no = "KW-${SimpleDateFormat("yyyyMMddHHmmss", Locale.US).format(Date())}"
            db.payments().insert(Payment(studentId = student.id, month = month, amount = amount, method = method, date = today(), note = note, receiptNo = no))
        } else {
            val total = old.amount + amount
            if (total <= old.amount || old.amount >= student.monthlyFee) return@launch
            db.payments().update(old.copy(amount = total, method = method, date = today(), note = note))
        }
        onDone()
    }

    fun deletePayment(p: Payment) = viewModelScope.launch { db.payments().delete(p) }
    fun addProgram(p: Program) = viewModelScope.launch { db.programs().insert(p) }
    fun deleteProgram(p: Program) = viewModelScope.launch { db.programs().delete(p) }
    fun addExpense(e: Expense) = viewModelScope.launch { db.expenses().insert(e) }
    fun deleteExpense(e: Expense) = viewModelScope.launch { db.expenses().delete(e) }

    fun exportJson(onDone: (String) -> Unit) = viewModelScope.launch {
        val ss = db.students().activeOnce(); val ps = db.payments().allOnce(); val gs = db.programs().allOnce(); val es = db.expenses().allOnce()
        val o = JSONObject().put("version", 3).put("exportedAt", today())
        o.put("students", JSONArray().apply { ss.forEach { put(JSONObject().put("id",it.id).put("name",it.name).put("className",it.className).put("parentPhone",it.parentPhone).put("program",it.program).put("monthlyFee",it.monthlyFee).put("active",it.active)) } })
        o.put("payments", JSONArray().apply { ps.forEach { put(JSONObject().put("id",it.id).put("studentId",it.studentId).put("month",it.month).put("amount",it.amount).put("method",it.method).put("date",it.date).put("note",it.note).put("receiptNo",it.receiptNo)) } })
        o.put("programs", JSONArray().apply { gs.forEach { put(JSONObject().put("id",it.id).put("name",it.name).put("fee",it.fee)) } })
        o.put("expenses", JSONArray().apply { es.forEach { put(JSONObject().put("id",it.id).put("month",it.month).put("date",it.date).put("title",it.title).put("category",it.category).put("amount",it.amount).put("note",it.note)) } })
        onDone(o.toString(2))
    }

    suspend fun restoreJson(text: String) {
        val o = JSONObject(text)
        val ss = o.optJSONArray("students") ?: JSONArray(); val gs = o.optJSONArray("programs") ?: JSONArray(); val ps = o.optJSONArray("payments") ?: JSONArray(); val es = o.optJSONArray("expenses") ?: JSONArray()
        for (i in 0 until gs.length()) { val x=gs.getJSONObject(i); db.programs().insert(Program(x.optLong("id",0),x.optString("name"),x.optLong("fee"))) }
        for (i in 0 until ss.length()) { val x=ss.getJSONObject(i); db.students().insert(Student(x.optLong("id",0),x.optString("name"),x.optString("className"),x.optString("parentPhone"),x.optString("program"),x.optLong("monthlyFee"),x.optBoolean("active",true))) }
        for (i in 0 until ps.length()) { val x=ps.getJSONObject(i); runCatching { db.payments().insert(Payment(x.optLong("id",0),x.optLong("studentId"),x.optString("month"),x.optLong("amount"),x.optString("method"),x.optString("date"),x.optString("note"),x.optString("receiptNo"))) } }
        for (i in 0 until es.length()) { val x=es.getJSONObject(i); db.expenses().insert(Expense(x.optLong("id",0),x.optString("month"),x.optString("date"),x.optString("title"),x.optString("category"),x.optLong("amount"),x.optString("note"))) }
    }
}

suspend fun StudentDao.activeOnce(): List<Student> = active().first()
suspend fun PaymentDao.allOnce(): List<Payment> = all().first()
suspend fun ProgramDao.allOnce(): List<Program> = all().first()
suspend fun ExpenseDao.allOnce(): List<Expense> = all().first()

private val Navy = Color(0xFF174A82)
private val Green = Color(0xFF159A67)
private val Yellow = Color(0xFFF2B735)
private val Red = Color(0xFFE34D4D)
private val Bg = Color(0xFFF4F7FC)
private val Purple = Color(0xFFEDE3F5)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun App() {
    val context = androidx.compose.ui.platform.LocalContext.current.applicationContext
    val vm: MainVm = viewModel(factory = object : androidx.lifecycle.ViewModelProvider.Factory {
        override fun <T : ViewModel> create(modelClass: Class<T>): T = MainVm(context) as T
    })
    var tab by remember { mutableIntStateOf(0) }
    var studentDialog by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<Student?>(null) }
    var payStudent by remember { mutableStateOf<Student?>(null) }
    var reportFilter by remember { mutableStateOf("Semua") }
    val students by vm.students.collectAsState(emptyList())
    val payments by vm.payments.collectAsState(emptyList())
    val programs by vm.programs.collectAsState(emptyList())
    val expenses by vm.expenses.collectAsState(emptyList())

    Scaffold(
        containerColor = Bg,
        topBar = { TopAppBar(
            title = { Row(verticalAlignment = Alignment.CenterVertically) {
                Image(painterResource(R.drawable.logo_bimbel), "Logo", Modifier.size(48.dp).clip(RoundedCornerShape(12.dp)))
                Spacer(Modifier.width(10.dp)); Column { Text("Bimbel Smart Kreatif", fontWeight = FontWeight.Bold, color = Navy); Text("Cemerlang", fontWeight = FontWeight.Bold, color = Navy) }
            } },
            actions = { IconButton(onClick = {}) { Icon(Icons.Default.Notifications, "Notifikasi", tint = Navy) } }
        )},
        bottomBar = { NavigationBar(containerColor = Color(0xFFEAF0F8)) {
            val nav = listOf(Triple(Icons.Default.Home,"Beranda",0),Triple(Icons.Default.People,"Siswa",1),Triple(Icons.Default.ReceiptLong,"Bayar",2),Triple(Icons.Default.BarChart,"Laporan",3),Triple(Icons.Default.Payments,"Pengeluaran",4),Triple(Icons.Default.Settings,"Lainnya",5))
            nav.forEach { (icon,label,index) -> NavigationBarItem(selected=tab==index,onClick={tab=index},icon={Icon(icon,null)},label={Text(label, fontSize=11.sp)}) }
        }}
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when(tab) {
                0 -> Dashboard(students,payments,expenses) { status -> reportFilter=status; tab=3 }
                1 -> StudentsScreen(students,payments,{payStudent=it},{editing=it;studentDialog=true},{studentDialog=true})
                2 -> PaymentsScreen(students,payments) { vm.deletePayment(it) }
                3 -> ReportsScreen(students,payments,expenses,reportFilter)
                4 -> ExpensesScreen(expenses, vm)
                else -> SettingsScreen(programs,vm)
            }
        }
    }
    if(studentDialog) StudentDialog(programs,editing,{studentDialog=false;editing=null}) { s -> if(s.id==0L) vm.addStudent(s) else vm.updateStudent(s); studentDialog=false;editing=null }
    payStudent?.let { s -> PaymentDialog(s,payments.find { it.studentId==s.id && it.month.equals(monthNow(),true) },{payStudent=null}) { amount,method,note -> vm.recordPayment(s,monthNow(),amount,method,note){payStudent=null} } }
}

@Composable fun Header(title:String, subtitle:String?=null) { Column(Modifier.padding(horizontal=18.dp, vertical=12.dp)) { Text(title, style=MaterialTheme.typography.headlineSmall, fontWeight=FontWeight.Bold, color=Navy); subtitle?.let { Text(it, color=Color.Gray, style=MaterialTheme.typography.bodyLarge) } } }

@Composable fun StatCard(title:String,value:String,accent:Color,onClick:()->Unit) { Card(Modifier.padding(5.dp).clickable(onClick=onClick),shape=RoundedCornerShape(22.dp),colors=CardDefaults.cardColors(Color.White)) { Column(Modifier.padding(16.dp).fillMaxWidth()) { Text(title,color=Color.Gray); Text(value,fontSize=28.sp,fontWeight=FontWeight.Bold,color=accent) } } }

@Composable
fun Dashboard(students:List<Student>,payments:List<Payment>,expenses:List<Expense>,onStatus:(String)->Unit) {
    val m=monthNow(); val mp=payments.filter{it.month.equals(m,true)}; val me=expenses.filter{it.month.equals(m,true)}
    fun paid(id:Long)=mp.filter{it.studentId==id}.sumOf{it.amount}
    val lunas=students.count{paid(it.id)>=it.monthlyFee}; val kurang=students.count{paid(it.id) in 1 until it.monthlyFee}; val belum=students.count{paid(it.id)==0L}
    val income=mp.sumOf{it.amount}; val expense=me.sumOf{it.amount}; val net=income-expense
    LazyColumn(Modifier.fillMaxSize()) {
        item { Header("Selamat datang 👋","Dashboard keuangan • $m") }
        if(isMonthWarning()) item { WarningCard(students,lunas,kurang,belum,onStatus) }
        item { Card(Modifier.padding(horizontal=12.dp),shape=RoundedCornerShape(22.dp),colors=CardDefaults.cardColors(Navy)) { Column(Modifier.padding(18.dp)) { Text("Keuangan bulan ini",color=Color.White,fontWeight=FontWeight.Bold,fontSize=19.sp); Spacer(Modifier.height(8.dp)); Text("Pemasukan  ${rupiah(income)}",color=Color.White); Text("Pengeluaran ${rupiah(expense)}",color=Color.White); Spacer(Modifier.height(6.dp)); Text("Pendapatan bersih ${rupiah(net)}",color=Color.White,fontSize=23.sp,fontWeight=FontWeight.Bold) } } }
        item { Row(Modifier.fillMaxWidth().padding(10.dp)) { StatCard("Total Siswa",students.size.toString(),Color(0xFF2578C7),{}); StatCard("Sudah Bayar",lunas.toString(),Green){onStatus("Lunas")} } }
        item { Row(Modifier.fillMaxWidth().padding(horizontal=10.dp)) { StatCard("Kurang Bayar",kurang.toString(),Yellow){onStatus("Kurang Bayar")}; StatCard("Belum Bayar",belum.toString(),Red){onStatus("Belum Bayar")} } }
        item { Header("Rekap per Program","Tekan program untuk melihat detail") }
        val grouped=students.groupBy{it.program}
        items(grouped.entries.toList()){ e -> val gl=e.value; val lp=gl.count{paid(it.id)>=it.monthlyFee}; val kp=gl.count{paid(it.id) in 1 until it.monthlyFee}; val bp=gl.count{paid(it.id)==0L}; Card(Modifier.padding(horizontal=12.dp,vertical=5.dp).fillMaxWidth(),shape=RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(Color.White)){ListItem(headlineContent={Text(e.key,fontWeight=FontWeight.Bold,color=Navy)},supportingContent={Text("${gl.size} siswa • ${lp} lunas • ${kp} kurang • ${bp} belum")},trailingContent={Icon(Icons.Default.ChevronRight,null)})} }
    }
}

@Composable fun WarningCard(students:List<Student>,lunas:Int,kurang:Int,belum:Int,onStatus:(String)->Unit){ Card(Modifier.padding(12.dp).fillMaxWidth(),shape=RoundedCornerShape(22.dp),colors=CardDefaults.cardColors(Color(0xFFFFF4D9))){Column(Modifier.padding(17.dp)){Text("⚠️ ${daysRemainingInMonth()} hari lagi bulan berganti",fontWeight=FontWeight.Bold,color=Color(0xFF9A6800),fontSize=18.sp); Text("Masih ada $belum siswa belum bayar dan $kurang siswa kurang bayar.",color=Color(0xFF6D5A34)); Spacer(Modifier.height(10.dp)); Button(onClick={onStatus("Belum Bayar")},colors=ButtonDefaults.buttonColors(containerColor=Navy)){Text("Lihat siswa yang belum bayar")}}}}

@Composable
fun StudentsScreen(students:List<Student>,payments:List<Payment>,onPay:(Student)->Unit,onEdit:(Student)->Unit,onAdd:()->Unit){
    var q by remember{mutableStateOf("")}; val list=students.filter{it.name.contains(q,true)||it.className.contains(q,true)||it.program.contains(q,true)}; val m=monthNow()
    fun status(s:Student):String{val p=payments.firstOrNull{it.studentId==s.id&&it.month.equals(m,true)}?.amount?:0;return when{p>=s.monthlyFee->"LUNAS";p>0->"KURANG";else->"BELUM"}}
    LazyColumn(Modifier.fillMaxSize()){item{Row(Modifier.fillMaxWidth().padding(18.dp),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text("Data Siswa",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold,color=Navy);Text("${students.size} siswa aktif",color=Color.Gray)};Button(onClick=onAdd,colors=ButtonDefaults.buttonColors(Navy)){Icon(Icons.Default.Add,null);Spacer(Modifier.width(4.dp));Text("Tambah")}};OutlinedTextField(q,{q=it},Modifier.fillMaxWidth().padding(horizontal=14.dp),placeholder={Text("Cari nama, kelas, atau program")},leadingIcon={Icon(Icons.Default.Search,null)},singleLine=true)}
        students.groupBy{it.program}.filterKeys{key->list.any{it.program==key}}.forEach{(program,_)->item{Text(program,Modifier.padding(start=18.dp,top=14.dp,bottom=5.dp),fontWeight=FontWeight.Bold,color=Navy,fontSize=19.sp)};items(list.filter{it.program==program}){s->val st=status(s);Card(Modifier.fillMaxWidth().padding(horizontal=12.dp,vertical=5.dp),shape=RoundedCornerShape(20.dp),colors=CardDefaults.cardColors(Color.White)){ListItem(headlineContent={Text(s.name,fontWeight=FontWeight.Bold,color=Navy)},supportingContent={Text("${s.className} • ${rupiah(s.monthlyFee)} / bulan")},trailingContent={Row(verticalAlignment=Alignment.CenterVertically){StatusChip(st);Spacer(Modifier.width(5.dp));TextButton(onClick={onEdit(s)}){Text("Edit")};if(st!="LUNAS")Button(onClick={onPay(s)},colors=ButtonDefaults.buttonColors(Navy)){Text(if(st=="KURANG")"Bayar Sisa" else "Bayar")}})}}}}}
}

@Composable fun StatusChip(status:String){val (c,t)=when(status){"LUNAS"->Green to "LUNAS";"KURANG"->Yellow to "KURANG";else->Red to "BELUM"};Surface(color=c.copy(alpha=.15f),shape=RoundedCornerShape(50)){Text(t,color=c,fontWeight=FontWeight.Bold,fontSize=11.sp,modifier=Modifier.padding(horizontal=9.dp,vertical=5.dp))}}

@Composable fun PaymentsScreen(students:List<Student>,payments:List<Payment>,onDelete:(Payment)->Unit){val ctx=androidx.compose.ui.platform.LocalContext.current;LazyColumn(Modifier.fillMaxSize()){item{Header("Pembayaran","Riwayat transaksi")};items(payments){p->val s=students.firstOrNull{it.id==p.studentId};ListItem(headlineContent={Text(s?.name?:"Siswa dihapus",fontWeight=FontWeight.Bold)},supportingContent={Text("${p.month} • ${p.date} • ${p.method}")},trailingContent={Row(verticalAlignment=Alignment.CenterVertically){Text(rupiah(p.amount),fontWeight=FontWeight.Bold);if(s!=null)IconButton(onClick={shareReceipt(ctx,p,s)}){Icon(Icons.Default.Share,"Bagikan")};IconButton(onClick={onDelete.bind(p)}){Icon(Icons.Default.Delete,"Hapus")}})};HorizontalDivider()}}}

private fun <T> ((T)->Unit).bind(value:T):()->Unit={ { this(value) } }

@Composable
fun ReportsScreen(students:List<Student>,payments:List<Payment>,expenses:List<Expense>,initialFilter:String){
    var status by remember(initialFilter){mutableStateOf(initialFilter)}; var program by remember{mutableStateOf("Semua Program")}; var month by remember{mutableStateOf(monthNow())};
    val mp=payments.filter{it.month.equals(month,true)}; val me=expenses.filter{it.month.equals(month,true)}; val filteredStudents=students.filter{program=="Semua Program"||it.program==program}.filter{val p=mp.firstOrNull{p->p.studentId==it.id}?.amount?:0;when(status){"Lunas"->p>=it.monthlyFee;"Kurang Bayar"->p in 1 until it.monthlyFee;"Belum Bayar"->p==0L;else->true}}
    val income=mp.sumOf{it.amount}; val expense=me.sumOf{it.amount}; val net=income-expense
    LazyColumn(Modifier.fillMaxSize()){item{Header("Laporan Pembayaran","$month")};item{Row(Modifier.fillMaxWidth().padding(horizontal=10.dp)){FilterBox("Status",status,listOf("Semua","Lunas","Kurang Bayar","Belum Bayar")){status=it};FilterBox("Program",program,listOf("Semua Program")+students.map{it.program}.distinct()){program=it}}};item{Card(Modifier.padding(12.dp).fillMaxWidth(),shape=RoundedCornerShape(20.dp),colors=CardDefaults.cardColors(Color.White)){Column(Modifier.padding(16.dp)){Text("Ringkasan keuangan",fontWeight=FontWeight.Bold,color=Navy,fontSize=18.sp);Text("Pemasukan  ${rupiah(income)}",color=Green);Text("Pengeluaran ${rupiah(expense)}",color=Red);Text("Pendapatan bersih ${rupiah(net)}",fontWeight=FontWeight.Bold,color=Navy,fontSize=22.sp)}}};item{Text("${filteredStudents.size} siswa ditampilkan",Modifier.padding(18.dp,4.dp),color=Color.Gray)};itemsIndexed(filteredStudents){idx,s->val p=mp.firstOrNull{it.studentId==s.id}?.amount?:0;Card(Modifier.fillMaxWidth().padding(horizontal=12.dp,vertical=4.dp),shape=RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(Color.White)){ListItem(headlineContent={Text("${idx+1}. ${s.name}",fontWeight=FontWeight.Bold)},supportingContent={Text("${s.program} • Tagihan ${rupiah(s.monthlyFee)} • Dibayar ${rupiah(p)}")},trailingContent={StatusChip(when{p>=s.monthlyFee->"LUNAS";p>0->"KURANG";else->"BELUM"})})}};item{Spacer(Modifier.height(18.dp));Text("Pengeluaran $month",Modifier.padding(18.dp,4.dp),fontWeight=FontWeight.Bold,color=Navy);if(me.isEmpty())Text("Belum ada pengeluaran.",Modifier.padding(18.dp),color=Color.Gray)};items(me){e->ListItem(headlineContent={Text(e.title,fontWeight=FontWeight.Bold)},supportingContent={Text("${e.category} • ${e.date}" )},trailingContent={Text(rupiah(e.amount),fontWeight=FontWeight.Bold,color=Red)})}}}

@Composable fun FilterBox(label:String,value:String,options:List<String>,onSelect:(String)->Unit){var open by remember{mutableStateOf(false)};Box(Modifier.weight(1f).padding(4.dp)){OutlinedButton(onClick={open=true},Modifier.fillMaxWidth()){Text(value, maxLines=1,overflow=TextOverflow.Ellipsis)};DropdownMenu(open,{open=false}){options.forEach{DropdownMenuItem(text={Text(it)},onClick={onSelect(it);open=false})}}}}

@Composable
fun ExpensesScreen(expenses:List<Expense>,vm:MainVm){var add by remember{mutableStateOf(false)};val m=monthNow();val current=expenses.filter{it.month.equals(m,true)};val total=current.sumOf{it.amount};LazyColumn(Modifier.fillMaxSize()){item{Row(Modifier.fillMaxWidth().padding(18.dp),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text("Pengeluaran",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold,color=Navy);Text("$m • ${rupiah(total)}",color=Color.Gray)};Button(onClick={add=true},colors=ButtonDefaults.buttonColors(Navy)){Icon(Icons.Default.Add,null);Text(" Tambah")}}};if(current.isEmpty())item{Card(Modifier.padding(18.dp).fillMaxWidth(),colors=CardDefaults.cardColors(Color.White)){Text("Belum ada pengeluaran bulan ini.",Modifier.padding(20.dp),color=Color.Gray)}};items(current){e->Card(Modifier.fillMaxWidth().padding(horizontal=12.dp,vertical=5.dp),shape=RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(Color.White)){ListItem(headlineContent={Text(e.title,fontWeight=FontWeight.Bold)},supportingContent={Text("${e.category} • ${e.date}${if(e.note.isNotBlank())"\n${e.note}" else ""}")},trailingContent={Row(verticalAlignment=Alignment.CenterVertically){Text(rupiah(e.amount),fontWeight=FontWeight.Bold,color=Red);IconButton(onClick={vm.deleteExpense(e)}){Icon(Icons.Default.Delete,"Hapus")}})}}}};if(add)ExpenseDialog({add=false}){title,cat,amount,note->vm.addExpense(Expense(month=m,date=today(),title=title,category=cat,amount=amount,note=note));add=false}}

@Composable
fun SettingsScreen(programs:List<Program>,vm:MainVm){val ctx=androidx.compose.ui.platform.LocalContext.current;var add by remember{mutableStateOf(false)};var showBackup by remember{mutableStateOf(false)};var backupText by remember{mutableStateOf("")};val create=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")){uri->if(uri!=null)ctx.contentResolver.openOutputStream(uri)?.use{it.write(backupText.toByteArray())}};val open=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){uri->if(uri!=null){val text=ctx.contentResolver.openInputStream(uri)?.bufferedReader()?.use{it.readText()};if(!text.isNullOrBlank())vm.viewModelScope.launch{vm.restoreJson(text)}}};LazyColumn(Modifier.fillMaxSize()){item{Header("Pengaturan","Program, tarif, backup data")};item{Row(Modifier.fillMaxWidth().padding(16.dp),verticalAlignment=Alignment.CenterVertically){Text("Program & Tarif",fontWeight=FontWeight.Bold,fontSize=20.sp,modifier=Modifier.weight(1f));Button(onClick={add=true},colors=ButtonDefaults.buttonColors(Navy)){Text("+ Program")}}};items(programs){p->ListItem(headlineContent={Text(p.name,fontWeight=FontWeight.Bold)},supportingContent={Text("${rupiah(p.fee)} / bulan")},trailingContent={IconButton(onClick={vm::deleteProgram.bind(p)}){Icon(Icons.Default.Delete,"Hapus")}})};item{Spacer(Modifier.height(10.dp));Button(onClick={vm.exportJson{backupText=it;showBackup=true}},Modifier.fillMaxWidth().padding(horizontal=16.dp),colors=ButtonDefaults.buttonColors(Navy)){Text("Backup Data JSON")};OutlinedButton(onClick={open.launch(arrayOf("application/json","text/plain"))},Modifier.fillMaxWidth().padding(16.dp)){Text("Restore Data JSON")}}};if(add)ProgramDialog({add=false}){n,f->vm.addProgram(Program(name=n,fee=f));add=false};if(showBackup)AlertDialog(onDismissRequest={showBackup=false},title={Text("Backup siap")},text={Text("Simpan data siswa, pembayaran, program, dan pengeluaran ke file JSON.")},confirmButton={Button(onClick={showBackup=false;create.launch("backup_bimbel_${today().replace('/','-')}.json")}){Text("Simpan")}},dismissButton={TextButton(onClick={showBackup=false}){Text("Batal")}})}

@Composable
fun StudentDialog(programs:List<Program>,existing:Student?,onDismiss:()->Unit,onSave:(Student)->Unit){var name by remember{mutableStateOf(existing?.name?:"")};var cls by remember{mutableStateOf(existing?.className?:"")};var phone by remember{mutableStateOf(existing?.parentPhone?:"")};var program by remember{mutableStateOf(existing?.program?:programs.firstOrNull()?.name?:"Bimbel")};var fee by remember{mutableStateOf(existing?.monthlyFee?.toString()?:programs.firstOrNull()?.fee?.toString() ?: "150000")};AlertDialog(onDismissRequest=onDismiss,title={Text(if(existing==null)"Tambah Siswa" else "Edit Siswa")},text={Column(verticalArrangement=Arrangement.spacedBy(7.dp)){OutlinedTextField(name,{name=it},label={Text("Nama lengkap")},singleLine=true);OutlinedTextField(cls,{cls=it},label={Text("Kelas")},singleLine=true);OutlinedTextField(phone,{phone=it},label={Text("No. HP (opsional)")},singleLine=true);OutlinedTextField(program,{program=it},label={Text("Program")},singleLine=true);OutlinedTextField(fee,{fee=it.filter(Char::isDigit)},label={Text("Tarif per bulan")},singleLine=true)}},confirmButton={Button(enabled=name.isNotBlank()&&fee.isNotBlank(),onClick={onSave(Student(existing?.id?:0,name,cls,phone,program,fee.toLong()))},colors=ButtonDefaults.buttonColors(Navy)){Text("Simpan")}},dismissButton={TextButton(onClick=onDismiss){Text("Batal")}})}

@Composable
fun PaymentDialog(s:Student,existing:Payment?,onDismiss:()->Unit,onSave:(Long,String,String)->Unit){val remaining=(s.monthlyFee-(existing?.amount?:0)).coerceAtLeast(0);var amount by remember{mutableStateOf(remaining.toString())};var method by remember{mutableStateOf(existing?.method?:"Tunai")};var note by remember{mutableStateOf("")};AlertDialog(onDismissRequest=onDismiss,title={Text("Pembayaran • ${monthNow()}")},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){Text(s.name,fontWeight=FontWeight.Bold,color=Navy);Text("Tagihan: ${rupiah(s.monthlyFee)}");Text("Sudah dibayar: ${rupiah(existing?.amount?:0)}");Text("Sisa: ${rupiah(remaining)}",fontWeight=FontWeight.Bold);OutlinedTextField(amount,{amount=it.filter(Char::isDigit)},label={Text(if(existing==null)"Nominal pembayaran" else "Bayar sisa")},singleLine=true);OutlinedTextField(method,{method=it},label={Text("Metode")},singleLine=true);OutlinedTextField(note,{note=it},label={Text("Catatan")})}},confirmButton={Button(enabled=remaining>0&&amount.toLongOrNull()?.let{it>0&&it<=remaining}==true,onClick={onSave(amount.toLong(),method,note)},colors=ButtonDefaults.buttonColors(Navy)){Text(if(existing==null)"Simpan Pembayaran" else "Bayar Sisa")}},dismissButton={TextButton(onClick=onDismiss){Text("Batal")}})}

@Composable fun ExpenseDialog(onDismiss:()->Unit,onSave:(String,String,Long,String)->Unit){var title by remember{mutableStateOf("")};var cat by remember{mutableStateOf("Operasional")};var amount by remember{mutableStateOf("")};var note by remember{mutableStateOf("")};AlertDialog(onDismissRequest=onDismiss,title={Text("Tambah Pengeluaran")},text={Column(verticalArrangement=Arrangement.spacedBy(7.dp)){OutlinedTextField(title,{title=it},label={Text("Nama pengeluaran")},singleLine=true);OutlinedTextField(cat,{cat=it},label={Text("Kategori")},singleLine=true);OutlinedTextField(amount,{amount=it.filter(Char::isDigit)},label={Text("Jumlah")},singleLine=true);OutlinedTextField(note,{note=it},label={Text("Keterangan")})}},confirmButton={Button(enabled=title.isNotBlank()&&amount.toLongOrNull()?.let{it>0}==true,onClick={onSave(title,cat,amount.toLong(),note)},colors=ButtonDefaults.buttonColors(Navy)){Text("Simpan")}},dismissButton={TextButton(onClick=onDismiss){Text("Batal")}})}

@Composable fun ProgramDialog(onDismiss:()->Unit,onSave:(String,Long)->Unit){var n by remember{mutableStateOf("")};var f by remember{mutableStateOf("")};AlertDialog(onDismissRequest=onDismiss,title={Text("Tambah Program")},text={Column{OutlinedTextField(n,{n=it},label={Text("Nama program")});OutlinedTextField(f,{f=it.filter(Char::isDigit)},label={Text("Tarif bulanan")})}},confirmButton={Button(enabled=n.isNotBlank()&&f.toLongOrNull()?.let{it>0}==true,onClick={onSave(n,f.toLong())},colors=ButtonDefaults.buttonColors(Navy)){Text("Simpan")}},dismissButton={TextButton(onClick=onDismiss){Text("Batal")}})}

fun shareReceipt(context:Context,p:Payment,s:Student){val text="KUITANSI PEMBAYARAN\nBimbel Smart Kreatif Cemerlang\nNo: ${p.receiptNo}\nSiswa: ${s.name}\nProgram: ${s.program}\nBulan: ${p.month}\nNominal: ${rupiah(p.amount)}\nMetode: ${p.method}\nTanggal: ${p.date}";val phone=normalizePhone(s.parentPhone);val intent=if(phone.isNotBlank())Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$phone?text="+Uri.encode(text))) else Intent.createChooser(Intent(Intent.ACTION_SEND).apply{type="text/plain";putExtra(Intent.EXTRA_TEXT,text)},"Bagikan kuitansi");try{context.startActivity(intent)}catch(_:Exception){context.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply{type="text/plain";putExtra(Intent.EXTRA_TEXT,text)},"Bagikan kuitansi"))}}

class MainActivity:ComponentActivity(){override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);setContent{MaterialTheme(colorScheme=lightColorScheme(primary=Navy,secondary=Green,background=Bg,surface=Color.White,error=Red)){App()}}}}
